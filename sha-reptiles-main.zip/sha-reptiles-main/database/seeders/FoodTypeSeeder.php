<?php

namespace Database\Seeders;

use App\Models\FoodType;
use Illuminate\Database\Seeder;

class FoodTypeSeeder extends Seeder
{
    /**
     * Top-level categories, each with an optional list of sub-type/variant names
     * and the default feeding unit for those (leaf) sub-types.
     *
     * @var array<int, array{name: string, children: array<int, string>, default_unit: ?string}>
     */
    protected array $foodTypes = [
        ['name' => 'Mouse', 'children' => ['Pinky', 'Fuzzy', 'Adult'], 'default_unit' => 'piece'],
        ['name' => 'Rat', 'children' => ['Pup', 'Small', 'Medium', 'Large'], 'default_unit' => 'piece'],
        ['name' => 'Cricket', 'children' => [], 'default_unit' => 'piece'],
        ['name' => 'Mealworm', 'children' => [], 'default_unit' => 'gram'],
        ['name' => 'Dubia Roach', 'children' => [], 'default_unit' => 'piece'],
        ['name' => 'Leafy Greens', 'children' => [], 'default_unit' => 'gram'],
        ['name' => 'Other', 'children' => [], 'default_unit' => null],
    ];

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        foreach ($this->foodTypes as $entry) {
            $isLeafCategory = empty($entry['children']);

            $category = FoodType::firstOrCreate(
                ['name' => $entry['name'], 'parent_id' => null],
                [
                    'status' => true,
                    // Only set on a top-level entry when it's also a leaf (e.g. "Cricket");
                    // a category with children (e.g. "Mouse") is never itself selectable.
                    'default_unit' => $isLeafCategory ? $entry['default_unit'] : null,
                ]
            );

            foreach ($entry['children'] as $childName) {
                FoodType::firstOrCreate(
                    ['name' => $childName, 'parent_id' => $category->id],
                    ['status' => true, 'default_unit' => $entry['default_unit']]
                );
            }
        }
    }
}
