<?php

namespace Database\Seeders;

use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesVariety;
use Illuminate\Database\Seeder;

class ReptileSeeder extends Seeder
{
    /**
     * A small, deterministic set of development reptiles. Requires SpeciesSeeder
     * to have run first; any species not found is skipped rather than guessed at.
     * `variety` is optional and, when present, must match a name seeded by
     * SpeciesVarietySeeder under that same species.
     *
     * @var array<int, array{name: string, species: string, sex: string, variety?: string}>
     */
    protected array $reptiles = [
        ['name' => 'Rocky', 'species' => 'Ball Python', 'sex' => 'male'],
        ['name' => 'Luna', 'species' => 'Green Iguana', 'sex' => 'female'],
        ['name' => 'Spike', 'species' => 'Corn Snake', 'sex' => 'unknown'],
        // Demonstrates the full hierarchy end to end: Snake > Python Snake > Royal Python.
        ['name' => 'Royal Python 001', 'species' => 'Python Snake', 'variety' => 'Royal Python', 'sex' => 'male'],
        ['name' => 'Royal Python 002', 'species' => 'Python Snake', 'variety' => 'Royal Python', 'sex' => 'female'],
        // Demonstrates: Snake > Corn Snake > Albino Corn Snake.
        ['name' => 'Albino Corn Snake 001', 'species' => 'Corn Snake', 'variety' => 'Albino Corn Snake', 'sex' => 'female'],
    ];

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        foreach ($this->reptiles as $entry) {
            $species = Species::where('name', $entry['species'])->first();

            if (! $species) {
                continue;
            }

            $variety = null;

            if (isset($entry['variety'])) {
                $variety = SpeciesVariety::where('species_id', $species->id)
                    ->where('name', $entry['variety'])
                    ->first();
            }

            $reptile = Reptile::firstOrCreate(
                ['name' => $entry['name'], 'species_id' => $species->id],
                [
                    'species_variety_id' => $variety?->id,
                    'sex' => $entry['sex'],
                    'status' => 'active',
                    'weight_unit' => 'g',
                    'length_unit' => 'cm',
                ]
            );

            if (! $reptile->reptile_code) {
                $reptile->update(['reptile_code' => 'REP-'.str_pad((string) $reptile->id, 6, '0', STR_PAD_LEFT)]);
            }
        }
    }
}
