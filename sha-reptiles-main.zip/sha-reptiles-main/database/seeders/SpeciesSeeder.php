<?php

namespace Database\Seeders;

use App\Models\Species;
use App\Models\SpeciesCategory;
use Illuminate\Database\Seeder;

class SpeciesSeeder extends Seeder
{
    /**
     * A small, deterministic set of common reptile species for local development.
     *
     * `category` is optional and, when present, must match a name seeded by
     * SpeciesCategorySeeder (which runs first — see DatabaseSeeder). It is
     * only ever used to fill in a currently-null category_id (see run()) —
     * never to overwrite a category an admin has already assigned — so this
     * stays safe to re-run against a database that already has real data.
     *
     * @var array<int, array{name: string, scientific_name?: string, category?: string}>
     */
    protected array $species = [
        ['name' => 'Ball Python', 'scientific_name' => 'Python regius'],
        ['name' => 'Corn Snake', 'scientific_name' => 'Pantherophis guttatus', 'category' => 'Snake'],
        ['name' => 'Python Snake', 'scientific_name' => 'Python regius', 'category' => 'Snake'],
        ['name' => 'King Snake', 'scientific_name' => 'Lampropeltis getula', 'category' => 'Snake'],
        ['name' => 'Green Iguana', 'scientific_name' => 'Iguana iguana', 'category' => 'Iguana'],
        ['name' => 'Red Iguana', 'scientific_name' => 'Iguana iguana', 'category' => 'Iguana'],
        ['name' => 'Blue Iguana', 'scientific_name' => 'Iguana iguana', 'category' => 'Iguana'],
        ['name' => 'White Dragon', 'scientific_name' => 'Pogona vitticeps', 'category' => 'Bearded Dragon'],
        ['name' => 'Creamino Dragon', 'scientific_name' => 'Pogona vitticeps', 'category' => 'Bearded Dragon'],
        ['name' => 'Bearded Dragon', 'scientific_name' => 'Pogona vitticeps'],
        ['name' => 'Leopard Gecko', 'scientific_name' => 'Eublepharis macularius'],
        ['name' => 'Sulcata Tortoise', 'scientific_name' => 'Centrochelys sulcata'],
    ];

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        foreach ($this->species as $species) {
            $record = Species::firstOrCreate(
                ['name' => $species['name']],
                [
                    'scientific_name' => $species['scientific_name'],
                    'status' => true,
                ]
            );

            if (isset($species['category']) && $record->category_id === null) {
                $category = SpeciesCategory::where('name', $species['category'])->first();

                if ($category) {
                    $record->update(['category_id' => $category->id]);
                }
            }
        }
    }
}
