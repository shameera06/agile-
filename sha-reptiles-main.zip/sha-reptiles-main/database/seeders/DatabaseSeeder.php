<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Development admin account. Credentials are read from .env so no
        // real password is ever committed; the default below is for local
        // use only and must be changed before any shared/production use.
        User::firstOrCreate(
            ['email' => env('ADMIN_EMAIL', 'admin@example.com')],
            [
                'name' => env('ADMIN_NAME', 'System Admin'),
                'password' => Hash::make(env('ADMIN_PASSWORD', 'ChangeMe123!')),
                'email_verified_at' => now(),
                'role' => 'admin',
            ]
        );

        // Top level of the Species → Category → Type → Variety hierarchy.
        $this->call(SpeciesCategorySeeder::class);

        // Small, deterministic set of common species (the "Species Type"
        // level) for local development.
        $this->call(SpeciesSeeder::class);

        // Varieties/Morphs under some of the species types above.
        $this->call(SpeciesVarietySeeder::class);

        // A handful of development reptiles referencing the species above.
        $this->call(ReptileSeeder::class);

        // The standard set of feeding food types (categories + sub-types).
        $this->call(FoodTypeSeeder::class);
    }
}
