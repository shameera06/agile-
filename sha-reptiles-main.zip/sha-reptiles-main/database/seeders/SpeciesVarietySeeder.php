<?php

namespace Database\Seeders;

use App\Models\Species;
use App\Models\SpeciesVariety;
use Illuminate\Database\Seeder;

class SpeciesVarietySeeder extends Seeder
{
    /**
     * Varieties/Morphs for local development, keyed by their species type's
     * name (must match SpeciesSeeder). Any species type not found is
     * skipped rather than guessed at. Purely additive (firstOrCreate).
     *
     * @var array<string, array<int, string>>
     */
    protected array $varieties = [
        'Corn Snake' => ['Albino Corn Snake', 'Tessera Corn Snake', 'Creamino Corn Snake'],
        'Python Snake' => ['Royal Python', 'Albino Python', 'Banana Python'],
        'Red Iguana' => ['Standard Red Iguana'],
        'White Dragon' => ['Standard White Dragon'],
    ];

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        foreach ($this->varieties as $speciesName => $names) {
            $species = Species::where('name', $speciesName)->first();

            if (! $species) {
                continue;
            }

            foreach ($names as $name) {
                SpeciesVariety::firstOrCreate(
                    ['species_id' => $species->id, 'name' => $name],
                    ['status' => true]
                );
            }
        }
    }
}
