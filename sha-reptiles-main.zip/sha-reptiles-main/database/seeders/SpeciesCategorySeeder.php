<?php

namespace Database\Seeders;

use App\Models\SpeciesCategory;
use Illuminate\Database\Seeder;

class SpeciesCategorySeeder extends Seeder
{
    /**
     * Top level of the Species → Category → Type → Variety hierarchy, for
     * local development. Purely additive (firstOrCreate) — safe to re-run.
     *
     * @var array<int, string>
     */
    protected array $categories = ['Snake', 'Iguana', 'Bearded Dragon'];

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        foreach ($this->categories as $name) {
            SpeciesCategory::firstOrCreate(['name' => $name], ['status' => true]);
        }
    }
}
