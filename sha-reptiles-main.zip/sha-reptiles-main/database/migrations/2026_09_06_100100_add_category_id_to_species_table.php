<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Additive only: `category_id` is nullable so every existing `species`
     * row keeps working unchanged. Existing rows cannot be auto-mapped to a
     * category without guessing, so they are left null — an admin assigns
     * a category via the (already existing) Species edit form. Deleting a
     * category never deletes species: it just clears their category_id.
     */
    public function up(): void
    {
        Schema::table('species', function (Blueprint $table) {
            $table->foreignId('category_id')
                ->nullable()
                ->after('id')
                ->constrained('species_categories')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('species', function (Blueprint $table) {
            $table->dropConstrainedForeignId('category_id');
        });
    }
};
