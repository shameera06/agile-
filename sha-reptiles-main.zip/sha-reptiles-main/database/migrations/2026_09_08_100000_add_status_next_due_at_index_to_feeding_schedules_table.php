<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Adds a composite (status, next_due_at) index for feeding_schedules.
     *
     * feeding_schedules already has single-column indexes on `status` and
     * `next_due_at` individually, but every one of FeedingSchedule's due-date
     * scopes (scopeOverdue/scopeDueToday/scopeUpcoming — see the model) always
     * filters on BOTH columns together: `where('status', 'active')` plus a
     * `next_due_at` comparison. Those scopes back the Dashboard's overdue/due-
     * today/upcoming counts (every dashboard load) and the Feeding Schedules
     * index page's due-bucket filter and default `orderBy('next_due_at')` — a
     * composite index lets the database satisfy the whole "active schedules
     * ordered by/filtered on next_due_at" query from one index instead of
     * intersecting two single-column indexes.
     */
    public function up(): void
    {
        Schema::table('feeding_schedules', function (Blueprint $table) {
            $table->index(['status', 'next_due_at']);
        });
    }

    public function down(): void
    {
        Schema::table('feeding_schedules', function (Blueprint $table) {
            $table->dropIndex(['status', 'next_due_at']);
        });
    }
};
