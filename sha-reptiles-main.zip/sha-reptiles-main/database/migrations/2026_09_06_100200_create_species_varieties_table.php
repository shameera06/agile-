<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Third level of the hierarchy (Variety/Morph, e.g. "Royal Python" under
     * the "Python Snake" species type). Restrict (not cascade) on delete —
     * same guard style as `reptiles.species_id` — so a variety referenced by
     * a reptile can't be deleted out from under it.
     */
    public function up(): void
    {
        Schema::create('species_varieties', function (Blueprint $table) {
            $table->id();
            $table->foreignId('species_id')->constrained('species')->restrictOnDelete();
            $table->string('name');
            $table->boolean('status')->default(true)->index();
            $table->timestamps();

            $table->unique(['species_id', 'name']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('species_varieties');
    }
};
