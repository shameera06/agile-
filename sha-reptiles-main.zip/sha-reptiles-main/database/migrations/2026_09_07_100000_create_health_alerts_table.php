<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Health Alerts are derived, historical records generated around the
     * existing Module 7 weight-monitoring result (see WeightMonitoringService
     * / HealthAlertService) — this table never duplicates or recalculates
     * weight data, it only records that an alert condition was observed.
     */
    public function up(): void
    {
        Schema::create('health_alerts', function (Blueprint $table) {
            $table->id();

            // Restrict (not cascade): a reptile referenced by a health alert
            // can't be deleted out from under it — same guard style used by
            // feeding_records/shedding_records/medical_records.reptile_id.
            $table->foreignId('reptile_id')->constrained('reptiles')->restrictOnDelete();

            // Which specific feeding record triggered this alert, when the
            // source is 'feeding_record' — nullable for a future/manual alert.
            // The unique index is what makes alert creation idempotent: at
            // most one HealthAlert can ever exist per triggering feeding
            // record (MySQL/SQLite both allow multiple NULLs through a
            // unique index, so manual alerts are unaffected).
            $table->foreignId('feeding_record_id')->nullable()->constrained('feeding_records')->nullOnDelete()->unique();

            $table->string('alert_type')->default('weight')->index();
            $table->string('title');
            $table->text('message');

            // warning | critical
            $table->string('severity')->default('warning')->index();

            // active | resolved | dismissed
            $table->string('status')->default('active')->index();

            // feeding_record | manual
            $table->string('source')->default('feeding_record');

            $table->dateTime('triggered_at')->index();
            $table->dateTime('resolved_at')->nullable();
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();

            $table->text('notes')->nullable();

            $table->timestamps();

            $table->index(['reptile_id', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('health_alerts');
    }
};
