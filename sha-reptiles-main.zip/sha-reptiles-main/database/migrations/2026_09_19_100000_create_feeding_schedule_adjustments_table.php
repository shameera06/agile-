<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('feeding_schedule_adjustments', function (Blueprint $table) {
            $table->id();

            // Restrict (not cascade): an adjustment is an audit record and must
            // survive for as long as the schedule/reptile it refers to does —
            // matching feeding_schedules/feeding_records' own FK style.
            $table->foreignId('feeding_schedule_id')->constrained('feeding_schedules')->restrictOnDelete();

            // Denormalized, same as feeding_records.reptile_id — keeps history
            // scoped/queryable per reptile even if the schedule is later reused.
            $table->foreignId('reptile_id')->constrained('reptiles')->restrictOnDelete();

            $table->dateTime('original_next_due_at');
            $table->dateTime('adjusted_next_due_at');

            $table->string('reason');
            $table->text('notes')->nullable();

            $table->foreignId('adjusted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->dateTime('adjusted_at')->index();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('feeding_schedule_adjustments');
    }
};
