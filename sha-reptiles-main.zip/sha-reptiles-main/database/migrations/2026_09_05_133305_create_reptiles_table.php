<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reptiles', function (Blueprint $table) {
            $table->id();

            // Restrict (not cascade) so a species referenced by a reptile cannot be deleted.
            $table->foreignId('species_id')->constrained('species')->restrictOnDelete();

            $table->string('name');

            // Nullable at the DB level only because it's generated from the row's own id
            // right after insert (see ReptileController::store()); it is never left null
            // once creation completes, and the unique index protects against duplicates.
            $table->string('reptile_code')->nullable()->unique();

            $table->string('sex')->default('unknown')->index(); // male | female | unknown
            $table->date('date_of_birth')->nullable();
            $table->date('acquisition_date')->nullable();
            $table->string('acquisition_source')->nullable();

            $table->decimal('current_weight', 8, 2)->nullable();
            $table->string('weight_unit')->default('g');
            $table->decimal('length', 8, 2)->nullable();
            $table->string('length_unit')->default('cm');

            // active | inactive | transferred | sold | deceased
            $table->string('status')->default('active')->index();

            $table->string('photo')->nullable();
            $table->text('notes')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reptiles');
    }
};
