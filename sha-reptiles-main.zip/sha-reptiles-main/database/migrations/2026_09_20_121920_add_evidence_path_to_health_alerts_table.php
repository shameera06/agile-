<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Supporting evidence (a photo, a vet note scan, ...) a user attaches when
     * documenting the action taken on a Weight Concern — same private-disk,
     * generated-filename pattern as medical_records.prescription_path.
     */
    public function up(): void
    {
        Schema::table('health_alerts', function (Blueprint $table) {
            $table->string('evidence_path')->nullable()->after('notes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('health_alerts', function (Blueprint $table) {
            $table->dropColumn('evidence_path');
        });
    }
};
