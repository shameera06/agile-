<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('shedding_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reptile_id')->constrained('reptiles')->restrictOnDelete();
            $table->date('shedding_date');
            $table->string('status')->index(); // complete | partial | incomplete | problematic
            $table->text('notes')->nullable();
            $table->text('observations')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index('shedding_date');
            $table->index(['reptile_id', 'shedding_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('shedding_records');
    }
};
