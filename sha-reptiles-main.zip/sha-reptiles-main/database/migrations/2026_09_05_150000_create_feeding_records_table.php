<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('feeding_records', function (Blueprint $table) {
            $table->id();

            // Stored alongside feeding_schedule_id (not derived from it alone) so
            // this record remains a reliable historical snapshot even if the
            // schedule is later edited or deactivated.
            $table->foreignId('reptile_id')->constrained('reptiles')->restrictOnDelete();
            $table->foreignId('feeding_schedule_id')->constrained('feeding_schedules')->restrictOnDelete();
            $table->foreignId('food_type_id')->constrained('food_types')->restrictOnDelete();

            $table->dateTime('feeding_date');

            $table->decimal('quantity', 10, 2);
            $table->string('quantity_unit');

            $table->decimal('weight_before', 10, 2);
            $table->decimal('weight_after', 10, 2);
            $table->decimal('weight_after_defecation', 10, 2)->nullable();
            $table->decimal('weight_change', 10, 2)->nullable();
            $table->string('weight_trend')->nullable()->index(); // gain | no_gain | loss

            $table->boolean('weight_alert_triggered')->default(false)->index();
            $table->text('weight_alert_message')->nullable();

            $table->text('notes')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();

            $table->timestamps();

            $table->index('feeding_date');
            $table->index(['reptile_id', 'feeding_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('feeding_records');
    }
};
