<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Top level of the Species → Category → Type → Variety hierarchy
     * (e.g. Snake, Iguana, Bearded Dragon). The existing `species` table
     * becomes the "Species Type" level and gets a nullable `category_id`
     * pointing here (see the next migration) — nothing about `species` or
     * `reptiles` is replaced.
     */
    public function up(): void
    {
        Schema::create('species_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->boolean('status')->default(true)->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('species_categories');
    }
};
