<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('feeding_schedules', function (Blueprint $table) {
            $table->id();

            // Restrict (not cascade): historical schedules must survive even if a
            // reptile or food type is later deactivated or (in future modules) removed.
            $table->foreignId('reptile_id')->constrained('reptiles')->restrictOnDelete();
            $table->foreignId('food_type_id')->constrained('food_types')->restrictOnDelete();

            $table->decimal('quantity', 10, 2);
            $table->string('quantity_unit');
            $table->unsignedInteger('interval_days');

            $table->dateTime('first_due_at');
            $table->dateTime('next_due_at')->index();

            $table->date('start_date')->index();
            $table->date('end_date')->nullable()->index();

            // active | inactive | completed
            $table->string('status')->default('active')->index();

            $table->text('notes')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('feeding_schedules');
    }
};
