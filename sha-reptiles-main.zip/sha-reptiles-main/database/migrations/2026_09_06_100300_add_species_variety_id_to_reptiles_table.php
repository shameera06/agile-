<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Additive only: nullable, so every existing reptile keeps working
     * unchanged via its existing `species_id`. Existing reptiles cannot be
     * auto-mapped to a specific variety without guessing, so this is left
     * null until an admin assigns one from the reptile form or the new
     * Species → Category → Type → Variety browse pages. `species_id` and
     * its constraint are untouched.
     */
    public function up(): void
    {
        Schema::table('reptiles', function (Blueprint $table) {
            $table->foreignId('species_variety_id')
                ->nullable()
                ->after('species_id')
                ->constrained('species_varieties')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('reptiles', function (Blueprint $table) {
            $table->dropConstrainedForeignId('species_variety_id');
        });
    }
};
