<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('medical_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reptile_id')->constrained('reptiles')->restrictOnDelete();
            $table->date('treatment_date');
            $table->text('symptoms_or_condition');
            $table->string('medicine_name')->nullable();
            $table->string('dosage')->nullable();
            $table->text('treatment_details')->nullable();
            $table->string('veterinarian_name')->nullable();
            $table->string('veterinarian_contact')->nullable();
            $table->text('notes')->nullable();

            // Path on the private disk (never the public one) — served only
            // through the authenticated prescription-download controller action.
            $table->string('prescription_path')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index('treatment_date');
            $table->index(['reptile_id', 'treatment_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('medical_records');
    }
};
