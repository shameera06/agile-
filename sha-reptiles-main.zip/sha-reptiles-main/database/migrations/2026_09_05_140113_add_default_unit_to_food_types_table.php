<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('food_types', function (Blueprint $table) {
            // Drives the default Quantity Unit shown when this food type is selected
            // on a feeding schedule (Module 06). Only meaningful for leaf food types;
            // nullable so existing rows and top-level categories are unaffected.
            $table->string('default_unit')->nullable()->after('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('food_types', function (Blueprint $table) {
            $table->dropColumn('default_unit');
        });
    }
};
