<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Feeding records can now be added directly against a reptile without
     * going through a Feeding Schedule first, so feeding_schedule_id must be
     * optional. This only relaxes the NOT NULL constraint — the column, its
     * foreign key, and all existing values are left untouched.
     */
    public function up(): void
    {
        Schema::table('feeding_records', function (Blueprint $table) {
            $table->unsignedBigInteger('feeding_schedule_id')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('feeding_records', function (Blueprint $table) {
            $table->unsignedBigInteger('feeding_schedule_id')->nullable(false)->change();
        });
    }
};
