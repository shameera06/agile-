<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('food_types', function (Blueprint $table) {
            $table->id();

            // Self-referencing: null for a top-level category (e.g. "Mouse"), set for
            // a sub-type/variant (e.g. "Pinky" under "Mouse"). Restrict (not cascade)
            // so a category cannot be deleted out from under its own sub-types.
            $table->foreignId('parent_id')->nullable()->constrained('food_types')->restrictOnDelete();

            $table->string('name');
            $table->text('description')->nullable();
            $table->boolean('status')->default(true)->index();
            $table->timestamps();

            // Best-effort DB safety net for "unique name within the same parent"; the
            // authoritative check (including the null-parent/top-level case, where a
            // composite unique index can't fully protect against duplicates) is done
            // in the Form Requests.
            $table->unique(['parent_id', 'name']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('food_types');
    }
};
