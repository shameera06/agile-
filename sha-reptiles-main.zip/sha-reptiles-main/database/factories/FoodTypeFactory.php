<?php

namespace Database\Factories;

use App\Models\FoodType;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<FoodType>
 */
class FoodTypeFactory extends Factory
{
    /**
     * A small pool of realistic top-level food categories.
     *
     * @var array<int, string>
     */
    protected static array $categories = [
        'Mouse', 'Rat', 'Cricket', 'Mealworm', 'Dubia Roach', 'Leafy Greens', 'Other',
    ];

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $category = fake()->randomElement(static::$categories);

        return [
            'parent_id' => null,
            // A numeric suffix guarantees uniqueness against the (parent_id, name)
            // constraint, the same way SpeciesFactory does. Callers that care about
            // a specific name (e.g. an exact "Mouse") override it directly.
            'name' => $category.' '.fake()->unique()->numerify('####'),
            'description' => fake()->optional()->sentence(),
            'status' => true,
        ];
    }

    /**
     * Indicate that this food type is inactive.
     */
    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => false,
        ]);
    }
}
