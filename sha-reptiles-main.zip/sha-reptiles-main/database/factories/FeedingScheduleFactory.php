<?php

namespace Database\Factories;

use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

/**
 * @extends Factory<FeedingSchedule>
 */
class FeedingScheduleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * A plain FoodType::factory() row (no children ever attached to it) is
     * already a leaf by definition — the same way a real standalone food like
     * "Cricket" is both top-level and a leaf — so no special construction is
     * needed here to satisfy the "must be a leaf" rule.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        // Seconds zeroed out: a real schedule's first_due_at can never carry seconds
        // either, since it's always built from an <input type="time"> (minute
        // precision only) — matching that shape here keeps equalTo() comparisons
        // against a re-submitted, unchanged date/time meaningful in tests.
        $firstDueAt = Carbon::instance(fake()->dateTimeBetween('now', '+30 days'))->second(0);

        return [
            'reptile_id' => Reptile::factory(),
            'food_type_id' => FoodType::factory(),
            'quantity' => fake()->randomElement([1, 2, 5, 25, 50]),
            'quantity_unit' => fake()->randomElement(array_keys(FeedingSchedule::QUANTITY_UNITS)),
            'interval_days' => fake()->randomElement([1, 3, 7, 14, 30]),
            'first_due_at' => $firstDueAt,
            'next_due_at' => $firstDueAt,
            'start_date' => now(config('app.timezone'))->toDateString(),
            'end_date' => null,
            'status' => 'active',
            'notes' => fake()->optional()->sentence(),
        ];
    }

    /**
     * Indicate that this schedule has been deactivated.
     */
    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => 'inactive',
        ]);
    }
}
