<?php

namespace Database\Factories;

use App\Models\Reptile;
use App\Models\SheddingRecord;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<SheddingRecord>
 */
class SheddingRecordFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'reptile_id' => Reptile::factory(),
            'shedding_date' => fake()->dateTimeBetween('-6 months', 'now'),
            'status' => fake()->randomElement(array_keys(SheddingRecord::STATUSES)),
            'notes' => fake()->optional()->sentence(),
            'observations' => fake()->optional()->sentence(),
            'created_by' => null,
        ];
    }
}
