<?php

namespace Database\Factories;

use App\Models\Species;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Species>
 */
class SpeciesFactory extends Factory
{
    /**
     * A small pool of realistic reptile species to draw from in tests.
     *
     * @var array<int, array{name: string, scientific_name: string}>
     */
    protected static array $species = [
        ['name' => 'Ball Python', 'scientific_name' => 'Python regius'],
        ['name' => 'Corn Snake', 'scientific_name' => 'Pantherophis guttatus'],
        ['name' => 'Boa Constrictor', 'scientific_name' => 'Boa constrictor'],
        ['name' => 'Green Iguana', 'scientific_name' => 'Iguana iguana'],
        ['name' => 'Bearded Dragon', 'scientific_name' => 'Pogona vitticeps'],
        ['name' => 'Leopard Gecko', 'scientific_name' => 'Eublepharis macularius'],
        ['name' => 'Red-Eared Slider', 'scientific_name' => 'Trachemys scripta elegans'],
        ['name' => 'Sulcata Tortoise', 'scientific_name' => 'Centrochelys sulcata'],
    ];

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $species = fake()->randomElement(static::$species);

        return [
            // A numeric suffix guarantees uniqueness against the `name` column even
            // though the realistic-name pool above is small: fake()->unique() alone
            // over just 8 entries would (and did) throw an OverflowException once
            // exhausted, and plain randomElement() alone risks colliding with itself.
            // Callers that care about a specific display name override it directly.
            'name' => $species['name'].' '.fake()->unique()->numerify('####'),
            'scientific_name' => $species['scientific_name'],
            'description' => fake()->optional()->sentence(),
            'status' => true,
        ];
    }

    /**
     * Indicate that the species is inactive.
     */
    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => false,
        ]);
    }
}
