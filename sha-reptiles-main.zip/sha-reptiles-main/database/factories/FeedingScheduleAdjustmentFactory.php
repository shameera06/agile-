<?php

namespace Database\Factories;

use App\Models\FeedingSchedule;
use App\Models\FeedingScheduleAdjustment;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<FeedingScheduleAdjustment>
 */
class FeedingScheduleAdjustmentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $originalNextDueAt = fake()->dateTimeBetween('now', '+7 days');

        return [
            'feeding_schedule_id' => FeedingSchedule::factory(),
            'reptile_id' => function (array $attributes) {
                return FeedingSchedule::find($attributes['feeding_schedule_id'])->reptile_id;
            },
            'original_next_due_at' => $originalNextDueAt,
            'adjusted_next_due_at' => (clone $originalNextDueAt)->modify('+3 days'),
            'reason' => fake()->randomElement(array_keys(FeedingScheduleAdjustment::REASONS)),
            'notes' => fake()->optional()->sentence(),
            'adjusted_by' => User::factory(),
            'adjusted_at' => now(),
        ];
    }
}
