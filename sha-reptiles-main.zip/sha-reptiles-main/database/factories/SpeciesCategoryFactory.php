<?php

namespace Database\Factories;

use App\Models\SpeciesCategory;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<SpeciesCategory>
 */
class SpeciesCategoryFactory extends Factory
{
    /**
     * A small pool of realistic category names to draw from in tests.
     *
     * @var array<int, string>
     */
    protected static array $names = ['Snake', 'Iguana', 'Bearded Dragon', 'Gecko', 'Tortoise'];

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            // A numeric suffix guarantees uniqueness against the `name` column
            // even though the realistic-name pool above is small — same
            // approach as SpeciesFactory.
            'name' => fake()->randomElement(static::$names).' '.fake()->unique()->numerify('####'),
            'status' => true,
        ];
    }

    /**
     * Indicate that the category is inactive.
     */
    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => false,
        ]);
    }
}
