<?php

namespace Database\Factories;

use App\Models\MedicalRecord;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<MedicalRecord>
 */
class MedicalRecordFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'reptile_id' => Reptile::factory(),
            'treatment_date' => fake()->dateTimeBetween('-6 months', 'now'),
            'symptoms_or_condition' => fake()->randomElement([
                'Lethargy and reduced appetite.',
                'Mild respiratory infection symptoms.',
                'Minor skin abrasion on the tail.',
                'Routine wellness check.',
            ]),
            'medicine_name' => fake()->optional()->randomElement(['Baytril', 'Panacur', 'Metacam']),
            'dosage' => fake()->optional()->randomElement(['5mg/kg once daily', '2mg/kg twice daily']),
            'treatment_details' => fake()->optional()->sentence(),
            'veterinarian_name' => fake()->optional()->name(),
            'veterinarian_contact' => fake()->optional()->phoneNumber(),
            'notes' => fake()->optional()->sentence(),
            'prescription_path' => null,
            'created_by' => null,
        ];
    }
}
