<?php

namespace Database\Factories;

use App\Models\Reptile;
use App\Models\Species;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Reptile>
 */
class ReptileFactory extends Factory
{
    /**
     * A small pool of realistic reptile names.
     *
     * @var array<int, string>
     */
    protected static array $names = ['Rocky', 'Luna', 'Spike', 'Monty', 'Zeus', 'Daisy', 'Kaa', 'Ziggy'];

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'species_id' => Species::factory(),
            'name' => fake()->randomElement(static::$names),
            // A realistic-looking placeholder; real reptiles get their code generated
            // from their own id by ReptileController::store() after creation.
            'reptile_code' => 'REP-'.str_pad((string) fake()->unique()->numberBetween(1, 999999), 6, '0', STR_PAD_LEFT),
            'sex' => fake()->randomElement(array_keys(Reptile::SEXES)),
            'date_of_birth' => fake()->optional()->dateTimeBetween('-10 years', '-1 month'),
            'acquisition_date' => fake()->optional()->dateTimeBetween('-5 years', 'now'),
            'acquisition_source' => fake()->optional()->randomElement(['Breeder', 'Pet Store', 'Rescue', 'Private Owner', 'Born Here']),
            'current_weight' => fake()->randomFloat(2, 10, 5000),
            'weight_unit' => 'g',
            'length' => fake()->randomFloat(2, 5, 200),
            'length_unit' => 'cm',
            'status' => 'active',
            'photo' => null,
            'notes' => fake()->optional()->sentence(),
        ];
    }

    /**
     * Indicate that the reptile has been archived (inactive).
     */
    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => 'inactive',
        ]);
    }
}
