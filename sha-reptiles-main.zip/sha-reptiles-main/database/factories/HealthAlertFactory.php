<?php

namespace Database\Factories;

use App\Models\HealthAlert;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<HealthAlert>
 */
class HealthAlertFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'reptile_id' => Reptile::factory(),
            'feeding_record_id' => null,
            'alert_type' => 'weight',
            'title' => HealthAlert::WEIGHT_ALERT_TITLE,
            'message' => \App\Models\FeedingRecord::ALERT_MESSAGE,
            'severity' => 'warning',
            'status' => 'active',
            'source' => 'feeding_record',
            'triggered_at' => fake()->dateTimeBetween('-3 months', 'now'),
            'resolved_at' => null,
            'resolved_by' => null,
            'notes' => null,
        ];
    }

    /**
     * Indicate that the alert has been resolved.
     */
    public function resolved(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => 'resolved',
            'resolved_at' => now(),
        ]);
    }

    /**
     * Indicate that the alert has been dismissed.
     */
    public function dismissed(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => 'dismissed',
            'resolved_at' => now(),
        ]);
    }
}
