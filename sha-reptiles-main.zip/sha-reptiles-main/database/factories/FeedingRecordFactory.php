<?php

namespace Database\Factories;

use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<FeedingRecord>
 */
class FeedingRecordFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * By default this builds its own active Reptile, leaf FoodType, and a
     * FeedingSchedule that ties the two together, so a bare
     * FeedingRecord::factory()->create() is always internally consistent
     * (the schedule's reptile_id/food_type_id match the record's).
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $foodType = FoodType::factory()->create(['status' => true]);
        $feedingSchedule = FeedingSchedule::factory()->create([
            'reptile_id' => $reptile->id,
            'food_type_id' => $foodType->id,
        ]);

        $weightBefore = fake()->randomFloat(2, 100, 500);
        $weightAfter = $weightBefore + fake()->randomFloat(2, 5, 20);

        return [
            'reptile_id' => $reptile->id,
            'feeding_schedule_id' => $feedingSchedule->id,
            'food_type_id' => $foodType->id,
            'feeding_date' => now(config('app.timezone')),
            'quantity' => $feedingSchedule->quantity,
            'quantity_unit' => $feedingSchedule->quantity_unit,
            'weight_before' => $weightBefore,
            'weight_after' => $weightAfter,
            'weight_after_defecation' => null,
            'weight_change' => null,
            'weight_trend' => null,
            'weight_alert_triggered' => false,
            'weight_alert_message' => null,
            'notes' => fake()->optional()->sentence(),
            'created_by' => null,
        ];
    }

    /**
     * A feeding record added directly against a reptile, independent of any
     * Feeding Schedule — the app's normal feeding-entry workflow.
     */
    public function withoutSchedule(): static
    {
        return $this->state(fn (array $attributes) => [
            'feeding_schedule_id' => null,
        ]);
    }
}
