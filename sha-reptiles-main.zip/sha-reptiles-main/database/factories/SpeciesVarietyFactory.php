<?php

namespace Database\Factories;

use App\Models\Species;
use App\Models\SpeciesVariety;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<SpeciesVariety>
 */
class SpeciesVarietyFactory extends Factory
{
    /**
     * A small pool of realistic variety/morph names to draw from in tests.
     *
     * @var array<int, string>
     */
    protected static array $names = ['Albino', 'Royal', 'Banana', 'Tessera', 'Creamino', 'Standard'];

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'species_id' => Species::factory(),
            // A numeric suffix guarantees uniqueness against the (species_id,
            // name) unique index even though the realistic-name pool above is
            // small — same approach as SpeciesFactory.
            'name' => fake()->randomElement(static::$names).' '.fake()->unique()->numerify('####'),
            'status' => true,
        ];
    }

    /**
     * Indicate that the variety is inactive.
     */
    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => false,
        ]);
    }
}
