<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreSpeciesCategoryRequest;
use App\Http\Requests\Admin\UpdateSpeciesCategoryRequest;
use App\Models\SpeciesCategory;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

/**
 * CRUD for the top level of the Species → Category → Type → Variety
 * hierarchy. There is no index/show here — browsing categories is handled
 * by SpeciesController::browse(); this controller only manages them.
 */
class SpeciesCategoryController extends Controller
{
    public function create(): View
    {
        return view('admin.species-categories.create', [
            'category' => new SpeciesCategory(['status' => true]),
        ]);
    }

    public function store(StoreSpeciesCategoryRequest $request): RedirectResponse
    {
        SpeciesCategory::create($request->validated());

        return redirect()
            ->route('admin.species.browse')
            ->with('success', 'Category created successfully.');
    }

    public function edit(SpeciesCategory $speciesCategory): View
    {
        return view('admin.species-categories.edit', [
            'category' => $speciesCategory,
        ]);
    }

    public function update(UpdateSpeciesCategoryRequest $request, SpeciesCategory $speciesCategory): RedirectResponse
    {
        $speciesCategory->update($request->validated());

        return redirect()
            ->route('admin.species.browse')
            ->with('success', 'Category updated successfully.');
    }

    /**
     * A category that has species types registered under it must not be
     * deleted, since `species.category_id` depends on it. Checked up front
     * for a friendly error message; the database's own null-on-delete
     * foreign key would otherwise silently orphan those species types.
     */
    public function destroy(SpeciesCategory $speciesCategory): RedirectResponse
    {
        if ($speciesCategory->speciesTypes()->exists()) {
            return redirect()
                ->route('admin.species.browse')
                ->with('error', 'This category cannot be deleted because it has species types registered under it. Deactivate it instead.');
        }

        try {
            $speciesCategory->delete();
        } catch (QueryException) {
            return redirect()
                ->route('admin.species.browse')
                ->with('error', 'This category cannot be deleted because it has species types registered under it. Deactivate it instead.');
        }

        return redirect()
            ->route('admin.species.browse')
            ->with('success', 'Category deleted successfully.');
    }
}
