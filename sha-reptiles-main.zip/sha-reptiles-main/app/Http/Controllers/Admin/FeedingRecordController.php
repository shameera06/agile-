<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreFeedingRecordRequest;
use App\Http\Requests\Admin\UpdateFeedingRecordRequest;
use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use App\Services\HealthAlertService;
use App\Services\WeightMonitoringService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class FeedingRecordController extends Controller
{
    public function __construct(
        protected WeightMonitoringService $weightMonitoring,
        protected HealthAlertService $healthAlerts,
    ) {}

    public function index(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $reptileId = $request->integer('reptile_id') ?: null;
        $foodTypeId = $request->integer('food_type_id') ?: null;
        $trend = $request->string('trend')->toString();
        $alert = $request->string('alert')->toString();
        $dateFrom = $request->string('date_from')->toString();
        $dateTo = $request->string('date_to')->toString();

        $feedingRecords = FeedingRecord::query()
            ->with(['reptile.species', 'foodType.parent', 'feedingSchedule'])
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->whereHas('reptile', function ($query) use ($search) {
                        $query->where('name', 'like', "%{$search}%")
                            ->orWhere('reptile_code', 'like', "%{$search}%");
                    })->orWhereHas('foodType', function ($query) use ($search) {
                        $query->where('name', 'like', "%{$search}%");
                    });
                });
            })
            ->when($reptileId, fn ($query) => $query->where('reptile_id', $reptileId))
            ->when($foodTypeId, fn ($query) => $query->where('food_type_id', $foodTypeId))
            ->when(array_key_exists($trend, FeedingRecord::WEIGHT_TRENDS), fn ($query) => $query->where('weight_trend', $trend))
            ->when($alert === 'alerts', fn ($query) => $query->where('weight_alert_triggered', true))
            ->when($alert === 'none', fn ($query) => $query->where('weight_alert_triggered', false))
            ->when($dateFrom !== '', fn ($query) => $query->whereDate('feeding_date', '>=', $dateFrom))
            ->when($dateTo !== '', fn ($query) => $query->whereDate('feeding_date', '<=', $dateTo))
            ->orderByDesc('feeding_date')
            ->paginate(15)
            ->withQueryString();

        return view('admin.feeding-records.index', [
            'feedingRecords' => $feedingRecords,
            // Filter dropdowns only ever render id/name(/parent name) — see
            // admin.feeding-records.index — so only those columns are selected.
            'reptileOptions' => Reptile::orderBy('name')->get(['id', 'name']),
            'foodTypeOptions' => FoodType::query()->leaf()->with('parent:id,name')->orderBy('name')->get(['id', 'name', 'parent_id']),
            'search' => $search,
            'reptileId' => $reptileId,
            'foodTypeId' => $foodTypeId,
            'trend' => $trend,
            'alert' => $alert,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
        ]);
    }

    /**
     * Normally a Feeding Record is added directly against a reptile
     * (reptile_id given, no schedule involved). feeding_schedule_id is only
     * present for the legacy "Record Feeding" action still reachable from a
     * Feeding Schedule, in which case the schedule determines the reptile
     * and food type, neither of which can be changed through this form.
     */
    public function create(Request $request): View
    {
        $feedingScheduleId = $request->integer('feeding_schedule_id') ?: null;

        if ($feedingScheduleId) {
            $feedingSchedule = FeedingSchedule::with(['reptile.species', 'foodType.parent'])
                ->where('status', 'active')
                ->findOrFail($feedingScheduleId);

            return view('admin.feeding-records.create', [
                'feedingSchedule' => $feedingSchedule,
                'reptile' => $feedingSchedule->reptile,
                'foodTypeOptions' => collect(),
                'feedingRecord' => new FeedingRecord([
                    'feeding_schedule_id' => $feedingSchedule->id,
                    'feeding_date' => now(config('app.timezone')),
                    'quantity' => $feedingSchedule->quantity,
                    'quantity_unit' => $feedingSchedule->quantity_unit,
                    'weight_before' => $feedingSchedule->reptile->current_weight,
                ]),
            ]);
        }

        $reptile = Reptile::with('species')->findOrFail($request->integer('reptile_id'));

        return view('admin.feeding-records.create', [
            'feedingSchedule' => null,
            'reptile' => $reptile,
            'foodTypeOptions' => FoodType::query()->leaf()->with('parent:id,name')->orderBy('name')->get(['id', 'name', 'parent_id']),
            'feedingRecord' => new FeedingRecord([
                'reptile_id' => $reptile->id,
                'feeding_date' => now(config('app.timezone')),
                'weight_before' => $reptile->current_weight,
            ]),
        ]);
    }

    public function store(StoreFeedingRecordRequest $request): RedirectResponse
    {
        $feedingScheduleId = $request->validated('feeding_schedule_id');
        $feedingSchedule = $feedingScheduleId ? FeedingSchedule::with('reptile')->findOrFail($feedingScheduleId) : null;

        $reptileId = $feedingSchedule ? $feedingSchedule->reptile_id : $request->validated('reptile_id');

        $newAlerts = DB::transaction(function () use ($request, $feedingSchedule, $reptileId) {
            $feedingDate = Carbon::parse($request->validated('feeding_date'), config('app.timezone'));

            $foodTypeId = $feedingSchedule ? $feedingSchedule->food_type_id : $request->validated('food_type_id');

            FeedingRecord::create([
                'reptile_id' => $reptileId,
                'feeding_schedule_id' => $feedingSchedule?->id,
                'food_type_id' => $foodTypeId,
                'feeding_date' => $feedingDate,
                'quantity' => $request->validated('quantity'),
                'quantity_unit' => $request->validated('quantity_unit'),
                'weight_before' => $request->validated('weight_before'),
                'weight_after' => $request->validated('weight_after'),
                'weight_after_defecation' => $request->validated('weight_after_defecation'),
                'notes' => $request->validated('notes'),
                'created_by' => $request->user()?->id,
            ]);

            // Weight change/trend/alert and current_weight all depend on the
            // reptile's full feeding history, not just the row just inserted.
            $this->weightMonitoring->recalculateReptileWeightHistory($reptileId);

            // Module 10: turn any resulting weight_alert_triggered = true
            // into a persisted, auditable HealthAlert. Idempotent — see
            // HealthAlertService — so this never duplicates. Committed in
            // the same transaction as the feeding record itself.
            $newAlerts = $this->healthAlerts->syncWeightAlertsForReptile($reptileId);

            if ($feedingSchedule) {
                $this->advanceSchedule($feedingSchedule, $feedingDate);
            }

            return $newAlerts;
        });

        // Sent after the transaction commits — a mail failure/slowness must
        // never affect whether the feeding record itself gets saved.
        $this->healthAlerts->notifyNewAlerts($newAlerts);

        return redirect()
            ->route('admin.reptiles.show', $reptileId)
            ->with('success', 'Feeding record saved successfully.');
    }

    public function edit(FeedingRecord $feedingRecord): View
    {
        return view('admin.feeding-records.edit', [
            'feedingRecord' => $feedingRecord->load(['reptile.species', 'foodType.parent', 'feedingSchedule']),
            'feedingSchedule' => $feedingRecord->feedingSchedule,
        ]);
    }

    /**
     * The reptile, feeding schedule, and food type are never touched here —
     * only what actually happened during the feeding can be corrected. An
     * edit can still change this record's (and later records') trend/alert
     * state, so the reptile's whole weight history is recalculated.
     */
    public function update(UpdateFeedingRecordRequest $request, FeedingRecord $feedingRecord): RedirectResponse
    {
        $newAlerts = DB::transaction(function () use ($request, $feedingRecord) {
            $feedingRecord->update([
                'feeding_date' => Carbon::parse($request->validated('feeding_date'), config('app.timezone')),
                'quantity' => $request->validated('quantity'),
                'quantity_unit' => $request->validated('quantity_unit'),
                'weight_before' => $request->validated('weight_before'),
                'weight_after' => $request->validated('weight_after'),
                'weight_after_defecation' => $request->validated('weight_after_defecation'),
                'notes' => $request->validated('notes'),
            ]);

            $this->weightMonitoring->recalculateReptileWeightHistory($feedingRecord->reptile_id);

            // Module 10: an edit can newly trigger (or stop triggering) the
            // alert condition for this or any later record of the same
            // reptile — resync rather than checking just this one record.
            return $this->healthAlerts->syncWeightAlertsForReptile($feedingRecord->reptile_id);
        });

        $this->healthAlerts->notifyNewAlerts($newAlerts);

        return redirect()
            ->route('admin.feeding-records.index')
            ->with('success', 'Feeding record updated successfully.');
    }

    /**
     * Advance the schedule to its next occurrence from the ACTUAL feeding
     * date/time (not the old scheduled date). A schedule whose next
     * occurrence would fall after its end_date is marked completed instead
     * of staying active indefinitely.
     */
    protected function advanceSchedule(FeedingSchedule $feedingSchedule, Carbon $feedingDate): void
    {
        $nextDueAt = $feedingDate->copy()->addDays($feedingSchedule->interval_days);

        $isPastEndDate = $feedingSchedule->end_date && $nextDueAt->toDateString() > $feedingSchedule->end_date->toDateString();

        $feedingSchedule->update([
            'next_due_at' => $nextDueAt,
            'status' => $isPastEndDate ? 'completed' : $feedingSchedule->status,
        ]);
    }
}
