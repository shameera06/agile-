<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\HealthAlertDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ResolveHealthAlertRequest;
use App\Http\Requests\Admin\UpdateHealthAlertRequest;
use App\Http\Requests\Admin\UpdateHealthAlertStatusRequest;
use App\Models\HealthAlert;
use App\Services\HealthAlertService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Admin/Staff can both view and document action taken on a Weight Concern
 * (see update()/evidence()); only Admin can resolve/dismiss (see the `admin`
 * route middleware on those two actions in routes/web.php) — the same
 * convention already established for Medical Records' destroy action.
 */
class HealthAlertController extends Controller
{
    /**
     * Evidence uploads live on a disk never symlinked into public/ — only
     * this controller's evidence() action can ever serve one.
     */
    protected const EVIDENCE_DISK = 'private';

    protected const EVIDENCE_DIRECTORY = 'weight-concern-evidence';

    public function __construct(protected HealthAlertService $healthAlerts) {}

    public function index(Request $request, HealthAlertDataTable $dataTable): mixed
    {
        if ($request->ajax()) {
            return $dataTable->ajax();
        }

        return view('admin.health-alerts.index', [
            'dataTable' => $dataTable->html(),
        ]);
    }

    public function show(HealthAlert $healthAlert): View
    {
        return view('admin.health-alerts.show', [
            'healthAlert' => $healthAlert->load([
                'reptile.species.category',
                'reptile.variety',
                'feedingRecord',
                'resolvedBy',
            ]),
        ]);
    }

    /**
     * Admin only (route middleware). status/resolved_at/resolved_by are
     * never accepted from the request — HealthAlertService determines them.
     * ResolveHealthAlertRequest requires documentation (existing or
     * submitted here) to already exist before this can succeed.
     */
    public function resolve(ResolveHealthAlertRequest $request, HealthAlert $healthAlert): RedirectResponse
    {
        $evidencePath = $request->hasFile('evidence') ? $this->storeEvidence($request->file('evidence')) : null;

        $this->healthAlerts->resolveAlert($healthAlert, $request->user(), $request->validated('notes'), $evidencePath);

        return redirect()
            ->route('admin.health-alerts.show', $healthAlert)
            ->with('success', 'Health alert resolved successfully.');
    }

    /**
     * Admin only (route middleware). The alert is never deleted — only its
     * status changes — so it stays in the auditable history.
     */
    public function dismiss(UpdateHealthAlertStatusRequest $request, HealthAlert $healthAlert): RedirectResponse
    {
        $this->healthAlerts->dismissAlert($healthAlert, $request->user(), $request->validated('notes'));

        return redirect()
            ->route('admin.health-alerts.show', $healthAlert)
            ->with('success', 'Health alert dismissed successfully.');
    }

    /**
     * "Document action taken" on a still-open concern — any authenticated
     * user (Admin or Staff), not just Admin. Never changes status.
     */
    public function update(UpdateHealthAlertRequest $request, HealthAlert $healthAlert): RedirectResponse
    {
        $evidencePath = $request->hasFile('evidence') ? $this->storeEvidence($request->file('evidence')) : null;

        $this->healthAlerts->recordAction($healthAlert, $request->validated('notes'), $evidencePath);

        return redirect()
            ->route('admin.health-alerts.show', $healthAlert)
            ->with('success', 'Action notes saved.');
    }

    /**
     * Securely stream a weight concern's supporting evidence file. Any
     * authenticated user may view it (no per-role restriction, same as
     * MedicalRecordController::prescription()) — the private storage path
     * is never exposed, only this action can serve the file.
     */
    public function evidence(HealthAlert $healthAlert): StreamedResponse
    {
        abort_unless($healthAlert->hasEvidence(), 404);
        abort_unless(Storage::disk(self::EVIDENCE_DISK)->exists($healthAlert->evidence_path), 404);

        return Storage::disk(self::EVIDENCE_DISK)->response($healthAlert->evidence_path);
    }

    /**
     * Store an uploaded evidence file under a generated (never
     * client-supplied) filename, on the private disk.
     */
    protected function storeEvidence(UploadedFile $file): string
    {
        // extension() guesses from the file's actual content, not the
        // client-supplied name — consistent with the 'mimes' validation rule.
        $filename = (string) Str::uuid().'.'.$file->extension();

        return $file->storeAs(self::EVIDENCE_DIRECTORY, $filename, self::EVIDENCE_DISK);
    }
}
