<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\ReptileByVarietyDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreSpeciesRequest;
use App\Http\Requests\Admin\UpdateSpeciesRequest;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\SpeciesVariety;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SpeciesController extends Controller
{
    /**
     * Display a listing of the species.
     */
    public function index(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $status = $request->string('status')->toString();

        $species = Species::query()
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('scientific_name', 'like', "%{$search}%");
                });
            })
            ->when($status === 'active', fn ($query) => $query->where('status', true))
            ->when($status === 'inactive', fn ($query) => $query->where('status', false))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.species.index', [
            'species' => $species,
            'search' => $search,
            'status' => $status,
        ]);
    }

    /**
     * Show the form for creating a new species.
     *
     * When arriving from a Category page's "Add Species Type" button
     * (?category_id=...), that category is pre-selected — same convention
     * as the "locked from query param" pattern used elsewhere (e.g.
     * MedicalRecordController::create()'s ?reptile_id=...).
     */
    public function create(Request $request): View
    {
        return view('admin.species.create', [
            'species' => new Species(['status' => true, 'category_id' => $request->integer('category_id') ?: null]),
            // admin.species._form renders only id/name per option.
            'categoryOptions' => SpeciesCategory::orderBy('name')->get(['id', 'name']),
        ]);
    }

    /**
     * Store a newly created species.
     */
    public function store(StoreSpeciesRequest $request): RedirectResponse
    {
        Species::create($request->validated());

        return redirect()
            ->route('admin.species.index')
            ->with('success', 'Species created successfully.');
    }

    /**
     * Show the form for editing the given species.
     */
    public function edit(Species $species): View
    {
        return view('admin.species.edit', [
            'species' => $species,
            // admin.species._form renders only id/name per option.
            'categoryOptions' => SpeciesCategory::orderBy('name')->get(['id', 'name']),
        ]);
    }

    /**
     * Update the given species.
     */
    public function update(UpdateSpeciesRequest $request, Species $species): RedirectResponse
    {
        $species->update($request->validated());

        return redirect()
            ->route('admin.species.index')
            ->with('success', 'Species updated successfully.');
    }

    /**
     * Remove the given species.
     *
     * A species that is assigned to one or more reptiles must not be deleted,
     * since reptiles.species_id depends on it. That is checked up front for a
     * friendly error message; the database's own restrict-on-delete foreign
     * key is the safety net if a reptile is assigned in between the check and
     * the delete.
     */
    public function destroy(Species $species): RedirectResponse
    {
        if ($species->reptiles()->exists()) {
            return redirect()
                ->route('admin.species.index')
                ->with('error', 'This species cannot be deleted because it is assigned to one or more reptiles. Deactivate it instead.');
        }

        try {
            $species->delete();
        } catch (QueryException) {
            return redirect()
                ->route('admin.species.index')
                ->with('error', 'This species cannot be deleted because it is assigned to one or more reptiles. Deactivate it instead.');
        }

        return redirect()
            ->route('admin.species.index')
            ->with('success', 'Species deleted successfully.');
    }

    /*
    |--------------------------------------------------------------------------
    | Species → Category → Type → Variety browse hierarchy
    |--------------------------------------------------------------------------
    |
    | This is the navigation layer the sidebar's "Species" link now enters
    | (see admin.species.browse below). It is purely additive: the CRUD
    | actions above (index/create/edit/update/destroy) are untouched and
    | keep working exactly as they did before this hierarchy existed.
    */

    /**
     * Top of the hierarchy: Category cards (Snake, Iguana, Bearded Dragon...).
     */
    public function browse(): View
    {
        return view('admin.species.browse', [
            'categories' => SpeciesCategory::withCount('speciesTypes')->orderBy('name')->get(),
        ]);
    }

    /**
     * Species Types registered under one Category.
     */
    public function category(SpeciesCategory $category): View
    {
        return view('admin.species.category', [
            'category' => $category,
            'speciesTypes' => $category->speciesTypes()->withCount('varieties')->orderBy('name')->get(),
        ]);
    }

    /**
     * Varieties/Morphs registered under one Species Type, plus a count of
     * reptiles on this species type that aren't assigned to a variety yet
     * (pre-existing reptiles, or ones an admin hasn't sorted into a variety)
     * so they stay discoverable instead of silently disappearing.
     */
    public function type(Species $species): View
    {
        return view('admin.species.type', [
            'species' => $species->load('category'),
            'varieties' => $species->varieties()->withCount('reptiles')->orderBy('name')->get(),
            'unassignedReptileCount' => $species->reptiles()->whereNull('species_variety_id')->count(),
        ]);
    }

    /**
     * Individual reptiles registered under one Variety/Morph — the bottom
     * of the hierarchy. `$variety` must actually belong to `$species`
     * (route-nested, checked explicitly) so a mismatched URL never leaks
     * another variety's reptiles: prevents IDOR-style access.
     */
    public function variety(Request $request, Species $species, SpeciesVariety $variety, ReptileByVarietyDataTable $dataTable): mixed
    {
        abort_unless($variety->species_id === $species->id, 404);

        $dataTable->forVariety($variety);

        if ($request->ajax()) {
            return $dataTable->ajax();
        }

        return view('admin.species.variety', [
            'species' => $species->load('category'),
            'variety' => $variety,
            'dataTable' => $dataTable->html(),
        ]);
    }
}
