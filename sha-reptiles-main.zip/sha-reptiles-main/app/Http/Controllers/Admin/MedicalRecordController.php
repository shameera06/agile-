<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\MedicalRecordDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreMedicalRecordRequest;
use App\Http\Requests\Admin\UpdateMedicalRecordRequest;
use App\Models\MedicalRecord;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class MedicalRecordController extends Controller
{
    /**
     * Prescription uploads live on a disk never symlinked into public/ —
     * only this controller's prescription() action can ever serve one.
     */
    protected const PRESCRIPTION_DISK = 'private';

    protected const PRESCRIPTION_DIRECTORY = 'medical-prescriptions';

    public function index(Request $request, MedicalRecordDataTable $dataTable): mixed
    {
        if ($request->ajax()) {
            return $dataTable->ajax();
        }

        return view('admin.medical-records.index', [
            'dataTable' => $dataTable->html(),
        ]);
    }

    /**
     * When arriving from a Reptile Profile's "Add Medical Record" button
     * (?reptile_id=...), that reptile is fixed — Staff/Admin never has to
     * (and cannot accidentally) pick a different one. Arriving from the
     * Medical Records index instead shows an active-reptile dropdown.
     */
    public function create(Request $request): View
    {
        $lockedReptile = null;

        if ($reptileId = $request->integer('reptile_id')) {
            $lockedReptile = Reptile::with('species')->findOrFail($reptileId);
        }

        return view('admin.medical-records.create', [
            'medicalRecord' => new MedicalRecord([
                'reptile_id' => $lockedReptile?->id,
                'treatment_date' => now(config('app.timezone'))->toDateString(),
            ]),
            'lockedReptile' => $lockedReptile,
            'reptileOptions' => $this->activeReptiles(),
        ]);
    }

    public function store(StoreMedicalRecordRequest $request): RedirectResponse
    {
        $medicalRecord = DB::transaction(function () use ($request) {
            $attributes = collect($request->validated())->except('prescription')->all();
            // Never trust a submitted created_by — always the authenticated user.
            $attributes['created_by'] = $request->user()?->id;

            if ($request->hasFile('prescription')) {
                $attributes['prescription_path'] = $this->storePrescription($request->file('prescription'));
            }

            return MedicalRecord::create($attributes);
        });

        return redirect()
            ->route('admin.medical-records.show', $medicalRecord)
            ->with('success', 'Medical record created successfully.');
    }

    public function show(MedicalRecord $medicalRecord): View
    {
        return view('admin.medical-records.show', [
            'medicalRecord' => $medicalRecord->load(['reptile.species', 'createdBy']),
        ]);
    }

    public function edit(MedicalRecord $medicalRecord): View
    {
        return view('admin.medical-records.edit', [
            'medicalRecord' => $medicalRecord,
            'lockedReptile' => null,
            'reptileOptions' => $this->reptileOptionsFor($medicalRecord),
        ]);
    }

    /**
     * The reptile, symptoms, medicine, etc. can all be corrected here.
     * A replacement prescription is optional — the existing one is left
     * untouched when no new file is uploaded.
     */
    public function update(UpdateMedicalRecordRequest $request, MedicalRecord $medicalRecord): RedirectResponse
    {
        DB::transaction(function () use ($request, $medicalRecord) {
            $attributes = collect($request->validated())->except('prescription')->all();
            $oldPrescriptionPath = $medicalRecord->prescription_path;

            if ($request->hasFile('prescription')) {
                // Store the new file (and point the record at it) before
                // removing the old one, so a failed upload/update never
                // leaves the record without its existing prescription.
                $attributes['prescription_path'] = $this->storePrescription($request->file('prescription'));
            }

            $medicalRecord->update($attributes);

            if ($request->hasFile('prescription') && $oldPrescriptionPath) {
                Storage::disk(self::PRESCRIPTION_DISK)->delete($oldPrescriptionPath);
            }
        });

        return redirect()
            ->route('admin.medical-records.show', $medicalRecord)
            ->with('success', 'Medical record updated successfully.');
    }

    /**
     * Admin only — the `admin` route middleware keeps Staff from ever
     * reaching this action.
     */
    public function destroy(MedicalRecord $medicalRecord): RedirectResponse
    {
        DB::transaction(function () use ($medicalRecord) {
            if ($medicalRecord->hasPrescription()) {
                Storage::disk(self::PRESCRIPTION_DISK)->delete($medicalRecord->prescription_path);
            }

            $medicalRecord->delete();
        });

        return redirect()
            ->route('admin.medical-records.index')
            ->with('success', 'Medical record deleted successfully.');
    }

    /**
     * Securely stream a medical record's prescription file.
     *
     * Authentication is enforced by the route's `auth` middleware; both
     * Admin and Staff may view any record's prescription (there is no
     * per-user ownership restriction in this admin panel). The private
     * storage path is never exposed — only this action can serve the file.
     */
    public function prescription(MedicalRecord $medicalRecord): StreamedResponse
    {
        abort_unless($medicalRecord->hasPrescription(), 404);
        abort_unless($medicalRecord->reptile, 404);
        abort_unless(Storage::disk(self::PRESCRIPTION_DISK)->exists($medicalRecord->prescription_path), 404);

        return Storage::disk(self::PRESCRIPTION_DISK)->response($medicalRecord->prescription_path);
    }

    /**
     * Store an uploaded prescription under a generated (never
     * client-supplied) filename, on the private disk.
     */
    protected function storePrescription(UploadedFile $file): string
    {
        // extension() guesses from the file's actual content, not the
        // client-supplied name — consistent with the 'mimes' validation rule.
        $filename = (string) Str::uuid().'.'.$file->extension();

        return $file->storeAs(self::PRESCRIPTION_DIRECTORY, $filename, self::PRESCRIPTION_DISK);
    }

    /**
     * Active reptiles, ordered by name. Used to populate reptile dropdowns.
     *
     * @return Collection<int, Reptile>
     */
    protected function activeReptiles(): Collection
    {
        // admin.medical-records._form renders id/name/reptile_code/status
        // plus the reptile's species name — nothing else — for each option.
        return Reptile::with('species:id,name')
            ->where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'reptile_code', 'status', 'species_id']);
    }

    /**
     * Active reptiles, plus this record's current reptile even if it has
     * since gone inactive, so the existing relationship stays selectable.
     *
     * @return Collection<int, Reptile>
     */
    protected function reptileOptionsFor(MedicalRecord $medicalRecord): Collection
    {
        $options = $this->activeReptiles();

        if (! $options->contains('id', $medicalRecord->reptile_id)) {
            $options = $options->push($medicalRecord->reptile)->sortBy('name')->values();
        }

        return $options;
    }
}
