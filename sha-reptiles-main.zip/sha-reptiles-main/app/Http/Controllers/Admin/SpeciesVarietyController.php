<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreSpeciesVarietyRequest;
use App\Http\Requests\Admin\UpdateSpeciesVarietyRequest;
use App\Models\Species;
use App\Models\SpeciesVariety;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * CRUD for the third level of the Species → Category → Type → Variety
 * hierarchy (e.g. "Royal Python" under the "Python Snake" species type).
 * There is no index/show here — browsing varieties is handled by
 * SpeciesController::type(); this controller only manages them.
 */
class SpeciesVarietyController extends Controller
{
    /**
     * When arriving from a Species Type's "Add Variety" button
     * (?species_id=...), that species type is fixed and pre-selected.
     */
    public function create(Request $request): View
    {
        $species = null;

        if ($speciesId = $request->integer('species_id')) {
            $species = Species::find($speciesId);
        }

        return view('admin.species-varieties.create', [
            'variety' => new SpeciesVariety(['status' => true, 'species_id' => $species?->id]),
            'lockedSpecies' => $species,
            // admin.species-varieties._form renders only id/name per option.
            'speciesOptions' => Species::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function store(StoreSpeciesVarietyRequest $request): RedirectResponse
    {
        $variety = SpeciesVariety::create($request->validated());

        return redirect()
            ->route('admin.species.type', $variety->species_id)
            ->with('success', 'Variety created successfully.');
    }

    public function edit(SpeciesVariety $speciesVariety): View
    {
        return view('admin.species-varieties.edit', [
            'variety' => $speciesVariety,
            'lockedSpecies' => $speciesVariety->species,
            'speciesOptions' => Species::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function update(UpdateSpeciesVarietyRequest $request, SpeciesVariety $speciesVariety): RedirectResponse
    {
        $speciesVariety->update($request->validated());

        return redirect()
            ->route('admin.species.type', $speciesVariety->species_id)
            ->with('success', 'Variety updated successfully.');
    }

    /**
     * A variety that has reptiles registered under it must not be deleted,
     * since `reptiles.species_variety_id` depends on it.
     */
    public function destroy(SpeciesVariety $speciesVariety): RedirectResponse
    {
        $redirect = redirect()->route('admin.species.type', $speciesVariety->species_id);

        if ($speciesVariety->reptiles()->exists()) {
            return $redirect->with('error', 'This variety cannot be deleted because it has reptiles registered under it. Deactivate it instead.');
        }

        try {
            $speciesVariety->delete();
        } catch (QueryException) {
            return $redirect->with('error', 'This variety cannot be deleted because it has reptiles registered under it. Deactivate it instead.');
        }

        return $redirect->with('success', 'Variety deleted successfully.');
    }
}
