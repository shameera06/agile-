<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\AdjustFeedingScheduleRequest;
use App\Http\Requests\Admin\StoreFeedingScheduleRequest;
use App\Http\Requests\Admin\UpdateFeedingScheduleRequest;
use App\Models\FeedingSchedule;
use App\Models\FeedingScheduleAdjustment;
use App\Models\FoodType;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class FeedingScheduleController extends Controller
{
    /**
     * Display a listing of the feeding schedules.
     */
    public function index(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $reptileId = $request->integer('reptile_id') ?: null;
        $foodTypeId = $request->integer('food_type_id') ?: null;
        $status = $request->string('status')->toString();
        $due = $request->string('due')->toString();

        $feedingSchedules = FeedingSchedule::query()
            ->with(['reptile.species', 'foodType.parent'])
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->whereHas('reptile', function ($query) use ($search) {
                        $query->where('name', 'like', "%{$search}%")
                            ->orWhere('reptile_code', 'like', "%{$search}%");
                    })->orWhereHas('foodType', function ($query) use ($search) {
                        $query->where('name', 'like', "%{$search}%");
                    });
                });
            })
            ->when($reptileId, fn ($query) => $query->where('reptile_id', $reptileId))
            ->when($foodTypeId, fn ($query) => $query->where('food_type_id', $foodTypeId))
            ->when(array_key_exists($status, FeedingSchedule::STATUSES), fn ($query) => $query->where('status', $status))
            ->when($due === 'overdue', fn ($query) => $query->overdue())
            ->when($due === 'due_today', fn ($query) => $query->dueToday())
            ->when($due === 'upcoming', fn ($query) => $query->upcoming())
            ->orderBy('next_due_at')
            ->paginate(15)
            ->withQueryString();

        return view('admin.feeding-schedules.index', [
            'feedingSchedules' => $feedingSchedules,
            // Filter dropdowns only ever render id/name(/parent name) — see
            // admin.feeding-schedules.index — so only those columns are selected.
            'reptileOptions' => Reptile::orderBy('name')->get(['id', 'name']),
            // Active leaf food types, plus any (possibly now inactive) food type
            // already referenced by a schedule, so historical records stay findable.
            'foodTypeOptions' => FoodType::query()
                ->where(fn ($query) => $query->leaf()->where('status', true))
                ->orWhereHas('feedingSchedules')
                ->with('parent:id,name')
                ->orderBy('name')
                ->get(['id', 'name', 'parent_id']),
            'search' => $search,
            'reptileId' => $reptileId,
            'foodTypeId' => $foodTypeId,
            'status' => $status,
            'due' => $due,
        ]);
    }

    /**
     * Show the form for creating a new feeding schedule.
     */
    public function create(): View
    {
        return view('admin.feeding-schedules.create', [
            'feedingSchedule' => new FeedingSchedule([
                'quantity_unit' => 'piece',
                'interval_days' => 7,
                'start_date' => now(config('app.timezone'))->toDateString(),
                'status' => 'active',
            ]),
            'reptileOptions' => $this->activeReptiles(),
            'foodTypeOptions' => $this->activeLeafFoodTypes(),
        ]);
    }

    /**
     * Store a newly created feeding schedule.
     */
    public function store(StoreFeedingScheduleRequest $request): RedirectResponse
    {
        $firstDueAt = $request->firstDueAt();

        $attributes = collect($request->validated())
            ->except(['first_due_date', 'first_due_time'])
            ->merge([
                'first_due_at' => $firstDueAt,
                // Always equal to first_due_at for a brand-new schedule — never
                // derived from the interval; the admin/staff picked this date explicitly.
                'next_due_at' => $firstDueAt,
            ])
            ->all();

        DB::transaction(fn () => FeedingSchedule::create($attributes));

        return redirect()
            ->route('admin.feeding-schedules.index')
            ->with('success', 'Feeding schedule created successfully.');
    }

    /**
     * Show the form for editing the given feeding schedule.
     */
    public function edit(FeedingSchedule $feedingSchedule): View
    {
        $reptileOptions = $this->activeReptiles();

        if (! $reptileOptions->contains('id', $feedingSchedule->reptile_id)) {
            $reptileOptions = $reptileOptions->push($feedingSchedule->reptile)->sortBy('name')->values();
        }

        $foodTypeOptions = $this->activeLeafFoodTypes();

        if (! $foodTypeOptions->contains('id', $feedingSchedule->food_type_id)) {
            $foodTypeOptions = $foodTypeOptions->push($feedingSchedule->foodType)->sortBy('name')->values();
        }

        return view('admin.feeding-schedules.edit', [
            'feedingSchedule' => $feedingSchedule,
            'reptileOptions' => $reptileOptions,
            'foodTypeOptions' => $foodTypeOptions,
            'latestAdjustment' => $feedingSchedule->adjustments()->with('adjustedBy')->first(),
        ]);
    }

    /**
     * Update the given feeding schedule.
     */
    public function update(UpdateFeedingScheduleRequest $request, FeedingSchedule $feedingSchedule): RedirectResponse
    {
        $newFirstDueAt = $request->firstDueAt();

        $attributes = collect($request->validated())
            ->except(['first_due_date', 'first_due_time'])
            ->put('first_due_at', $newFirstDueAt)
            ->all();

        // Editing unrelated fields (quantity, notes, ...) must never move
        // next_due_at. It only follows first_due_at when that date/time is
        // itself deliberately changed — and only as long as no feeding has
        // ever actually been recorded against this schedule yet. Once a real
        // Feeding Record exists, next_due_at is owned by that history (it
        // advances from the actual feeding date, per Module 07) and must no
        // longer reset just because first_due_at was edited.
        if (! $newFirstDueAt->equalTo($feedingSchedule->first_due_at) && ! $feedingSchedule->feedingRecords()->exists()) {
            $attributes['next_due_at'] = $newFirstDueAt;
        }

        DB::transaction(fn () => $feedingSchedule->update($attributes));

        return redirect()
            ->route('admin.feeding-schedules.index')
            ->with('success', 'Feeding schedule updated successfully.');
    }

    /**
     * Show the form for temporarily adjusting the given schedule's next
     * feeding occurrence, without touching its recurring interval.
     */
    public function adjustNextFeeding(FeedingSchedule $feedingSchedule): View
    {
        return view('admin.feeding-schedules.adjust', [
            'feedingSchedule' => $feedingSchedule->load(['reptile', 'foodType.parent', 'adjustments.adjustedBy']),
        ]);
    }

    /**
     * Save a temporary override of the schedule's next feeding date/time.
     *
     * This only ever changes `next_due_at` — `interval_days` (the permanent
     * recurring pattern) is never touched. The previous `next_due_at` and the
     * new one are both preserved as a FeedingScheduleAdjustment audit row, so
     * repeated adjustments never overwrite each other's history. Once the
     * (possibly adjusted) feeding actually happens, FeedingRecordController::
     * advanceSchedule() takes back over and recalculates next_due_at from the
     * actual feeding date + interval_days, exactly as it already does today —
     * this feature never creates a FeedingRecord, HealthAlert, or weight change.
     */
    public function storeAdjustment(AdjustFeedingScheduleRequest $request, FeedingSchedule $feedingSchedule): RedirectResponse
    {
        $adjustedNextDueAt = Carbon::parse(
            $request->validated('adjusted_next_due_date').' '.$request->validated('adjusted_next_due_time'),
            config('app.timezone')
        );

        DB::transaction(function () use ($request, $feedingSchedule, $adjustedNextDueAt) {
            FeedingScheduleAdjustment::create([
                'feeding_schedule_id' => $feedingSchedule->id,
                'reptile_id' => $feedingSchedule->reptile_id,
                'original_next_due_at' => $feedingSchedule->next_due_at,
                'adjusted_next_due_at' => $adjustedNextDueAt,
                'reason' => $request->validated('reason'),
                'notes' => $request->validated('notes'),
                'adjusted_by' => $request->user()?->id,
                'adjusted_at' => now(config('app.timezone')),
            ]);

            $feedingSchedule->update(['next_due_at' => $adjustedNextDueAt]);
        });

        return redirect()
            ->route('admin.feeding-schedules.index')
            ->with('success', 'Next feeding adjusted successfully.');
    }

    /**
     * Active reptiles, ordered by name. Used to populate reptile dropdowns.
     *
     * @return Collection<int, Reptile>
     */
    protected function activeReptiles(): Collection
    {
        // admin.feeding-schedules._form renders id/name/reptile_code/status
        // plus the reptile's species name — nothing else — for each option.
        return Reptile::with('species:id,name')
            ->where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'reptile_code', 'status', 'species_id']);
    }

    /**
     * Active leaf food types, ordered by name. Used to populate food dropdowns.
     *
     * @return Collection<int, FoodType>
     */
    protected function activeLeafFoodTypes(): Collection
    {
        // admin.feeding-schedules._form renders id/name/status/default_unit
        // plus the parent's name — nothing else — for each option.
        return FoodType::with('parent:id,name')
            ->leaf()
            ->where('status', true)
            ->orderBy('name')
            ->get(['id', 'name', 'parent_id', 'status', 'default_unit']);
    }
}
