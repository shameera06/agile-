<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Reptile;
use App\Services\AiReptileAssistantService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Read-only AI Reptile Assistant — explains one reptile's own existing
 * records via the Google Gemini API. Never modifies the database; see
 * AiReptileAssistantService for how the reptile-scoped context is built and
 * sent, and GeminiService for the underlying HTTP call.
 */
class ReptileAiAssistantController extends Controller
{
    public function __construct(protected AiReptileAssistantService $assistant) {}

    /**
     * The dedicated AI Assistant page for one reptile.
     */
    public function show(Reptile $reptile): View
    {
        $reptile->load(['species.category', 'variety']);

        return view('admin.reptiles.ai-assistant', ['reptile' => $reptile]);
    }

    /**
     * Answer one question about the route-bound reptile only. The reptile's
     * identity always comes from route-model binding, never from the
     * request body, so the question text can never be used to pull another
     * reptile's data (see AiReptileAssistantService::buildContext()).
     */
    public function ask(Request $request, Reptile $reptile): JsonResponse
    {
        $validated = $request->validate([
            'question' => ['required', 'string', 'max:1000'],
        ]);

        $result = $this->assistant->ask($reptile, $validated['question']);

        if (! $result['success']) {
            return response()->json([
                'message' => $this->friendlyErrorMessage($result['error']),
            ], 503);
        }

        return response()->json(['answer' => $result['answer']]);
    }

    protected function friendlyErrorMessage(string $error): string
    {
        return match ($error) {
            'timeout' => 'The AI Assistant took too long to respond. Please try again.',
            'rate_limited' => 'The AI Assistant has temporarily reached its usage limit. Please try again later.',
            'not_configured' => 'AI Assistant is not currently configured.',
            default => 'AI Assistant is currently unavailable. Please try again later.',
        };
    }
}
