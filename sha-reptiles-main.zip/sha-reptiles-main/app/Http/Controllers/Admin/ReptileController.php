<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\FeedingHistoryDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreReptileRequest;
use App\Http\Requests\Admin\UpdateReptileRequest;
use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesVariety;
use App\Services\ReptileHistoryService;
use App\Services\WeightMonitoringService;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ReptileController extends Controller
{
    public function __construct(
        protected WeightMonitoringService $weightMonitoring,
        protected ReptileHistoryService $history,
    ) {}

    /**
     * Display a listing of the reptiles.
     */
    public function index(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $speciesId = $request->integer('species_id') ?: null;
        $status = $request->string('status')->toString();
        $sex = $request->string('sex')->toString();

        $reptiles = Reptile::query()
            ->with('species')
            // Module 10: "Attention" health-status column — a single boolean
            // subquery per row (no N+1), sourced from the same active
            // HealthAlert data that is the sole source of truth everywhere
            // else (see HealthAlertService::getAttentionRequiredReptileCount()).
            ->withExists(['healthAlerts as has_active_health_alert' => fn ($query) => $query->where('status', 'active')])
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('reptile_code', 'like', "%{$search}%");
                });
            })
            ->when($speciesId, fn ($query) => $query->where('species_id', $speciesId))
            ->when(array_key_exists($status, Reptile::STATUSES), fn ($query) => $query->where('status', $status))
            ->when(array_key_exists($sex, Reptile::SEXES), fn ($query) => $query->where('sex', $sex))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.reptiles.index', [
            'reptiles' => $reptiles,
            // All species currently in use (active, or already assigned to a reptile) so
            // historical/inactive species remain findable in the filter.
            'speciesOptions' => Species::query()
                ->where('status', true)
                ->orWhereHas('reptiles')
                ->orderBy('name')
                ->get(['id', 'name']),
            'search' => $search,
            'speciesId' => $speciesId,
            'status' => $status,
            'sex' => $sex,
        ]);
    }

    /**
     * Show the form for creating a new reptile.
     *
     * When arriving from a Variety page's "Add Reptile" button
     * (?species_id=...&species_variety_id=...), both are pre-selected —
     * same "locked from query param" convention used elsewhere (e.g.
     * MedicalRecordController::create()'s ?reptile_id=...).
     */
    public function create(Request $request): View
    {
        return view('admin.reptiles.create', [
            'reptile' => new Reptile([
                'status' => 'active',
                'weight_unit' => 'g',
                'length_unit' => 'cm',
                'species_id' => $request->integer('species_id') ?: null,
                'species_variety_id' => $request->integer('species_variety_id') ?: null,
            ]),
            'speciesOptions' => $this->activeSpecies(),
            'varietyOptions' => $this->activeVarieties(),
        ]);
    }

    /**
     * Store a newly created reptile.
     */
    public function store(StoreReptileRequest $request): RedirectResponse
    {
        $reptile = DB::transaction(function () use ($request) {
            $reptile = Reptile::create($request->safe()->except('photo'));

            // The row's own id is unique and already committed once create() runs
            // inside this transaction, so deriving the code from it can never collide.
            $reptile->update(['reptile_code' => $this->generateReptileCode($reptile)]);

            return $reptile;
        });

        // Only touch the filesystem after the reptile record safely exists, so a
        // failed database operation can never leave an orphaned uploaded file.
        if ($request->hasFile('photo')) {
            $reptile->update(['photo' => $request->file('photo')->store('reptiles', 'public')]);
        }

        return redirect()
            ->route('admin.reptiles.show', $reptile)
            ->with('success', 'Reptile created successfully.');
    }

    /**
     * Display the given reptile, including its feeding/weight history.
     */
    public function show(Reptile $reptile): View
    {
        $reptile->load(['species.category', 'variety']);

        // Most recent feedings first, scoped to this reptile only — never mixed
        // with another reptile's history.
        $feedingRecords = $reptile->feedingRecords()
            ->with('foodType.parent')
            ->orderByDesc('feeding_date')
            ->orderByDesc('id')
            ->limit(15)
            ->get();

        // The latest three records (if there are at least three) are highlighted
        // red on the profile when all three show no_gain/loss — a display concern,
        // distinct from the alert stored on a record when it was created (see
        // WeightMonitoringService).
        $highlightPoorGainIds = $this->weightMonitoring->hasThreeConsecutivePoorGainRecords($feedingRecords->take(3))
            ? $feedingRecords->take(3)->pluck('id')
            : collect();

        // Most recent sheddings first, scoped to this reptile only — never mixed
        // with another reptile's history.
        $sheddingRecords = $reptile->sheddingRecords()
            ->orderByDesc('shedding_date')
            ->orderByDesc('id')
            ->limit(15)
            ->get();

        // Most recent treatments first, scoped to this reptile only — never
        // mixed with another reptile's history.
        $medicalRecords = $reptile->medicalRecords()
            ->with('createdBy')
            ->orderByDesc('treatment_date')
            ->orderByDesc('id')
            ->limit(15)
            ->get();

        // Most recent alerts first, scoped to this reptile only — never mixed
        // with another reptile's alerts (see HealthAlertService).
        $healthAlerts = $reptile->healthAlerts()
            ->orderByDesc('triggered_at')
            ->orderByDesc('id')
            ->limit(15)
            ->get();

        return view('admin.reptiles.show', [
            'reptile' => $reptile,
            'feedingRecords' => $feedingRecords,
            'highlightPoorGainIds' => $highlightPoorGainIds,
            'activeFeedingSchedule' => $reptile->feedingSchedules()->where('status', 'active')->first(),
            'sheddingRecords' => $sheddingRecords,
            'medicalRecords' => $medicalRecords,
            'healthAlerts' => $healthAlerts,
        ]);
    }

    /**
     * Show the form for editing the given reptile.
     */
    public function edit(Reptile $reptile): View
    {
        return view('admin.reptiles.edit', [
            'reptile' => $reptile,
            // The reptile's current species stays selectable even if it is now
            // inactive, alongside every other currently-active species.
            'speciesOptions' => $this->activeSpecies()->push($reptile->species)->unique('id')->sortBy('name'),
            // Same for its current variety, if any, even if it has since gone inactive.
            'varietyOptions' => $this->activeVarieties()
                ->when($reptile->variety, fn ($options) => $options->push($reptile->variety))
                ->unique('id')
                ->sortBy('name'),
        ]);
    }

    /**
     * Update the given reptile.
     */
    public function update(UpdateReptileRequest $request, Reptile $reptile): RedirectResponse
    {
        $reptile->update($request->safe()->except('photo'));

        if ($request->hasFile('photo')) {
            $oldPhoto = $reptile->photo;

            // Store the new photo (and point the record at it) before removing the
            // old one, so a failed upload never leaves the reptile without a photo.
            $reptile->update(['photo' => $request->file('photo')->store('reptiles', 'public')]);

            if ($oldPhoto) {
                Storage::disk('public')->delete($oldPhoto);
            }
        }

        return redirect()
            ->route('admin.reptiles.show', $reptile)
            ->with('success', 'Reptile updated successfully.');
    }

    /**
     * Archive the given reptile (set its status to inactive).
     *
     * A dedicated, single-purpose action rather than routing this through
     * update(), so a one-click archive from the index page doesn't need to
     * resubmit every other required field (name, species, sex, ...) just to
     * flip the status.
     */
    public function archive(Reptile $reptile): RedirectResponse
    {
        $reptile->update(['status' => 'inactive']);

        return redirect()
            ->route('admin.reptiles.index')
            ->with('success', 'Reptile archived successfully.');
    }

    /**
     * A dedicated, read-only Weight History page for one reptile.
     *
     * Deliberately reuses, rather than reimplements, everything Module 11's
     * Complete History page already built for the exact same data:
     * FeedingHistoryDataTable (server-side, scoped to this reptile, with the
     * same columns/effective-weight/trend it already renders) and
     * ReptileHistoryService::getHighlightedFeedingRecordIds() (the same
     * "latest three poor-gain" rule, computed once). No new table, no new
     * ajax route, no second weight calculation — the DataTable's own
     * minifiedAjax() already points at the existing
     * admin.reptiles.history.feeding-data endpoint, which is itself already
     * scoped to whichever {reptile} the URL names.
     */
    public function weightHistory(Reptile $reptile, FeedingHistoryDataTable $dataTable): View
    {
        $reptile->load(['species.category', 'variety']);

        $highlightedFeedingIds = $this->history->getHighlightedFeedingRecordIds($reptile);

        return view('admin.reptiles.weight-history', [
            'reptile' => $reptile,
            'highlightedFeedingIds' => $highlightedFeedingIds,
            'feedingDataTable' => $dataTable->forReptile($reptile)->highlightIds($highlightedFeedingIds)->html(),
        ]);
    }

    /**
     * Active species, ordered by name. Used to populate species dropdowns.
     *
     * @return Collection<int, Species>
     */
    protected function activeSpecies(): Collection
    {
        return Species::where('status', true)->orderBy('name')->get(['id', 'name', 'status']);
    }

    /**
     * Active varieties, ordered by name. Used to populate the (optional)
     * Variety dropdown, client-side filtered to the selected species — see
     * the script at the bottom of admin.reptiles._form.
     *
     * @return Collection<int, SpeciesVariety>
     */
    protected function activeVarieties(): Collection
    {
        return SpeciesVariety::where('status', true)->orderBy('name')->get(['id', 'name', 'status', 'species_id']);
    }

    /**
     * Generate this reptile's unique code from its own (already unique) id.
     *
     * Deliberately not count()+1 or MAX(id)+1, which can collide under
     * concurrent inserts or after deletions — the row's own id can't.
     */
    protected function generateReptileCode(Reptile $reptile): string
    {
        return 'REP-'.str_pad((string) $reptile->id, 6, '0', STR_PAD_LEFT);
    }
}
