<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreSheddingRecordRequest;
use App\Http\Requests\Admin\UpdateSheddingRecordRequest;
use App\Models\Reptile;
use App\Models\SheddingRecord;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SheddingRecordController extends Controller
{
    public function index(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $reptileId = $request->integer('reptile_id') ?: null;
        $status = $request->string('status')->toString();
        $dateFrom = $request->string('from')->toString();
        $dateTo = $request->string('to')->toString();

        $sheddingRecords = SheddingRecord::query()
            ->with(['reptile.species', 'createdBy'])
            ->when($search !== '', function ($query) use ($search) {
                $query->whereHas('reptile', function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('reptile_code', 'like', "%{$search}%")
                        ->orWhereHas('species', function ($query) use ($search) {
                            $query->where('name', 'like', "%{$search}%");
                        });
                });
            })
            ->when($reptileId, fn ($query) => $query->where('reptile_id', $reptileId))
            ->when(array_key_exists($status, SheddingRecord::STATUSES), fn ($query) => $query->where('status', $status))
            ->when($dateFrom !== '', fn ($query) => $query->whereDate('shedding_date', '>=', $dateFrom))
            ->when($dateTo !== '', fn ($query) => $query->whereDate('shedding_date', '<=', $dateTo))
            ->orderByDesc('shedding_date')
            ->paginate(15)
            ->withQueryString();

        return view('admin.shedding-records.index', [
            'sheddingRecords' => $sheddingRecords,
            // The filter dropdown only ever renders id/name — see
            // admin.shedding-records.index — so only those columns are selected.
            'reptileOptions' => Reptile::orderBy('name')->get(['id', 'name']),
            'search' => $search,
            'reptileId' => $reptileId,
            'status' => $status,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
        ]);
    }

    /**
     * When arriving from a Reptile Profile's "Add Shedding Record" button
     * (?reptile_id=...), that reptile is fixed — Staff/Admin never has to
     * (and cannot accidentally) pick a different one. Arriving from the
     * Shedding Records index instead shows an active-reptile dropdown.
     */
    public function create(Request $request): View
    {
        $lockedReptile = null;

        if ($reptileId = $request->integer('reptile_id')) {
            $lockedReptile = Reptile::with('species')->findOrFail($reptileId);
        }

        return view('admin.shedding-records.create', [
            'sheddingRecord' => new SheddingRecord([
                'reptile_id' => $lockedReptile?->id,
                'shedding_date' => now(config('app.timezone'))->toDateString(),
                'status' => 'complete',
            ]),
            'lockedReptile' => $lockedReptile,
            'reptileOptions' => $this->activeReptiles(),
        ]);
    }

    public function store(StoreSheddingRecordRequest $request): RedirectResponse
    {
        SheddingRecord::create(array_merge($request->validated(), [
            // Never trust a submitted created_by — always the authenticated user.
            'created_by' => $request->user()?->id,
        ]));

        return redirect()
            ->route('admin.shedding-records.index')
            ->with('success', 'Shedding record created successfully.');
    }

    public function edit(SheddingRecord $sheddingRecord): View
    {
        $reptileOptions = $this->activeReptiles();

        if (! $reptileOptions->contains('id', $sheddingRecord->reptile_id)) {
            $reptileOptions = $reptileOptions->push($sheddingRecord->reptile)->sortBy('name')->values();
        }

        return view('admin.shedding-records.edit', [
            'sheddingRecord' => $sheddingRecord,
            'lockedReptile' => null,
            'reptileOptions' => $reptileOptions,
        ]);
    }

    /**
     * created_by is never modified here — the original creator is kept.
     */
    public function update(UpdateSheddingRecordRequest $request, SheddingRecord $sheddingRecord): RedirectResponse
    {
        $sheddingRecord->update($request->validated());

        return redirect()
            ->route('admin.shedding-records.index')
            ->with('success', 'Shedding record updated successfully.');
    }

    /**
     * Active reptiles, ordered by name. Used to populate reptile dropdowns.
     *
     * @return Collection<int, Reptile>
     */
    protected function activeReptiles(): Collection
    {
        // admin.shedding-records._form renders id/name/reptile_code/status
        // plus the reptile's species name — nothing else — for each option.
        return Reptile::with('species:id,name')
            ->where('status', 'active')
            ->orderBy('name')
            ->get(['id', 'name', 'reptile_code', 'status', 'species_id']);
    }
}
