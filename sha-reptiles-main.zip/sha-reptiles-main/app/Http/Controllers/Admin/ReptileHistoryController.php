<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\FeedingHistoryDataTable;
use App\DataTables\HealthAlertDataTable;
use App\DataTables\MedicalRecordDataTable;
use App\DataTables\SheddingHistoryDataTable;
use App\Http\Controllers\Controller;
use App\Models\FeedingRecord;
use App\Models\Reptile;
use App\Services\ReptileHistoryService;
use App\Services\WeightMonitoringService;
use Barryvdh\DomPDF\Facade\Pdf;
use Barryvdh\DomPDF\PDF as DomPdfDocument;
use Illuminate\Http\Response;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Throwable;

/**
 * Module 11 — Complete (read-only) History for one individual reptile.
 * Purely an aggregation/view layer over Modules 7-10's existing tables —
 * this controller never creates, edits, or deletes a single record. Kept
 * thin: all summarizing logic lives in ReptileHistoryService, all listing
 * logic in the existing/new DataTable classes.
 *
 * Four small ajax actions below (one per embedded Yajra DataTable) because
 * this single page hosts four separate server-side tables, each of which
 * needs its own distinct ajax endpoint — see routes/web.php.
 */
class ReptileHistoryController extends Controller
{
    public function __construct(
        protected ReptileHistoryService $history,
        protected WeightMonitoringService $weightMonitoring,
    ) {}

    public function index(
        Reptile $reptile,
        FeedingHistoryDataTable $feedingDataTable,
        SheddingHistoryDataTable $sheddingDataTable,
        MedicalRecordDataTable $medicalDataTable,
        HealthAlertDataTable $healthAlertDataTable,
    ): View {
        $reptile->load(['species.category', 'variety']);

        $highlightedFeedingIds = $this->history->getHighlightedFeedingRecordIds($reptile);
        $latestRecords = $this->history->getLatestRecords($reptile);

        return view('admin.reptiles.history', [
            'reptile' => $reptile,
            'counts' => $this->history->getHistoryCounts($reptile),
            'latestRecords' => $latestRecords,
            'activeHealthAlerts' => $this->history->getActiveHealthAlerts($reptile),
            'currentHealthStatus' => $this->history->getCurrentHealthStatus($reptile, $latestRecords['feeding']),
            'highlightedFeedingIds' => $highlightedFeedingIds,
            'feedingDataTable' => $feedingDataTable->forReptile($reptile)->highlightIds($highlightedFeedingIds)->html(),
            'sheddingDataTable' => $sheddingDataTable->forReptile($reptile)->html(),
            'medicalDataTable' => $medicalDataTable->forReptile($reptile)->html(),
            'healthAlertDataTable' => $healthAlertDataTable->forReptile($reptile)->html(),
        ]);
    }

    /**
     * Each of the four ajax actions below re-validates the reptile via the
     * exact same route-model-bound {reptile} the page itself used, then
     * scopes its DataTable to it explicitly (forReptile()) — a mismatched
     * or forged reptile id in the URL simply gets that reptile's own (still
     * correctly isolated) data, never another reptile's.
     */
    public function feedingData(Reptile $reptile, FeedingHistoryDataTable $dataTable): mixed
    {
        return $dataTable
            ->forReptile($reptile)
            ->highlightIds($this->history->getHighlightedFeedingRecordIds($reptile))
            ->ajax();
    }

    public function sheddingData(Reptile $reptile, SheddingHistoryDataTable $dataTable): mixed
    {
        return $dataTable->forReptile($reptile)->ajax();
    }

    public function medicalData(Reptile $reptile, MedicalRecordDataTable $dataTable): mixed
    {
        return $dataTable->forReptile($reptile)->ajax();
    }

    public function healthAlertsData(Reptile $reptile, HealthAlertDataTable $dataTable): mixed
    {
        return $dataTable->forReptile($reptile)->ajax();
    }

    /**
     * Module 12 — server-generated PDF of one reptile's Complete History.
     * Entirely read-only: every value below comes from the exact same
     * ReptileHistoryService methods (plus the four full-collection getters
     * added for this module) that build the on-screen page above, so the
     * PDF and the page can never disagree. Every query those methods run is
     * scoped by reptile_id from this route-model-bound {reptile} — a forged
     * id in the URL still only ever resolves that reptile's own row (404s
     * otherwise) and its own records, never another reptile's.
     */
    public function pdf(Reptile $reptile): Response
    {
        $reptile->load(['species.category', 'variety']);

        // The PDF (unlike the on-screen History page) needs every record of
        // each type anyway, so each full collection is loaded exactly once
        // here and reused below — "latest record"/"latest three" are derived
        // from these same collections (each already ordered newest-first,
        // identically to how getLatestRecords()/getHighlightedFeedingRecordIds()
        // would query them) rather than re-querying the database a second
        // time for data already in hand.
        $feedingHistory = $this->history->getFeedingHistory($reptile);
        $sheddingHistory = $this->history->getSheddingHistory($reptile);
        $medicalHistory = $this->history->getMedicalHistory($reptile);
        $healthAlertHistory = $this->history->getHealthAlertHistory($reptile);

        $latestRecords = [
            'feeding' => $feedingHistory->first(),
            'shedding' => $sheddingHistory->first(),
            'medical' => $medicalHistory->first(),
            'healthAlert' => $healthAlertHistory->first(),
        ];

        $highlightedFeedingIds = $this->highlightedFeedingIds($feedingHistory);

        $pdf = Pdf::loadView('admin.reptiles.pdf.history', [
            'reptile' => $reptile,
            'history' => $this->history,
            'counts' => $this->history->getHistoryCounts($reptile),
            'latestRecords' => $latestRecords,
            'currentHealthStatus' => $this->history->getCurrentHealthStatus($reptile, $latestRecords['feeding']),
            'activeHealthAlerts' => $this->history->getActiveHealthAlerts($reptile),
            'highlightedFeedingIds' => $highlightedFeedingIds,
            'feedingHistory' => $feedingHistory,
            'sheddingHistory' => $sheddingHistory,
            'medicalHistory' => $medicalHistory,
            'healthAlertHistory' => $healthAlertHistory,
            'photoDataUri' => $this->reptilePhotoDataUri($reptile),
            'generatedAt' => now(),
        ])
            // Landscape: the widest section (Weight & Feeding History, ~11
            // columns — see the PDF view) would otherwise overflow a
            // portrait A4 page; every section renders on this one paper
            // size rather than mixing orientations mid-document.
            ->setPaper('a4', 'landscape');

        $this->addFooter($pdf, $reptile, now());

        return $pdf->download($this->pdfFilename($reptile));
    }

    /**
     * "Page X of Y" cannot be done in the Blade view itself: dompdf does not
     * resolve CSS's `counter(pages)` to a real total (it always renders as
     * 0), so the footer is instead drawn directly on the canvas via dompdf's
     * own page_text() — the documented way to get a live, per-page {PAGE_NUM}
     * / {PAGE_COUNT} substitution, filled in only once the whole PDF has been
     * laid out.
     */
    protected function addFooter(DomPdfDocument $pdf, Reptile $reptile, Carbon $generatedAt): void
    {
        $canvas = $pdf->getCanvas();
        $font = $pdf->getFontMetrics()->getFont('helvetica', 'normal');
        $text = sprintf(
            'Reptile Management System   |   Animal: %s   |   Generated: %s   |   Page {PAGE_NUM} of {PAGE_COUNT}',
            $reptile->name,
            $generatedAt->format('M d, Y g:i A'),
        );

        $canvas->page_text(36, $canvas->get_height() - 30, $text, $font, 8, [0.4, 0.44, 0.52]);
    }

    /**
     * The feeding_record ids that must render with a red "poor gain"
     * highlight, derived from an already-fetched (newest-first) feeding
     * history collection instead of re-querying the database — same
     * Module 7 rule as ReptileHistoryService::getHighlightedFeedingRecordIds(),
     * just applied to data already in hand for the PDF.
     *
     * @param  Collection<int, FeedingRecord>  $feedingHistory
     * @return Collection<int, int>
     */
    protected function highlightedFeedingIds(Collection $feedingHistory): Collection
    {
        $latestThree = $feedingHistory->take(3);

        return $this->weightMonitoring->hasThreeConsecutivePoorGainRecords($latestThree)
            ? $latestThree->pluck('id')
            : collect();
    }

    /**
     * A safe, meaningful filename built only from the reptile's own name/
     * code — never from arbitrary user input — e.g.
     * "royal-python-001-complete-history.pdf".
     */
    protected function pdfFilename(Reptile $reptile): string
    {
        $base = Str::slug($reptile->name ?: $reptile->reptile_code ?: 'reptile-'.$reptile->id);

        return ($base !== '' ? $base : 'reptile-'.$reptile->id).'-complete-history.pdf';
    }

    /**
     * The reptile's own photo, embedded as a base64 data URI so dompdf never
     * has to fetch a URL (private/public disk access, network, etc.). Purely
     * optional and best-effort: any failure (no photo, missing file, unreadable
     * disk) simply omits the image — it must never fail PDF generation.
     */
    protected function reptilePhotoDataUri(Reptile $reptile): ?string
    {
        if (! $reptile->photo) {
            return null;
        }

        try {
            $disk = Storage::disk('public');

            if (! $disk->exists($reptile->photo)) {
                return null;
            }

            $mime = $disk->mimeType($reptile->photo) ?: 'image/jpeg';

            return 'data:'.$mime.';base64,'.base64_encode($disk->get($reptile->photo));
        } catch (Throwable) {
            return null;
        }
    }
}
