<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\DashboardService;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __construct(protected DashboardService $dashboard) {}

    /**
     * Display the admin dashboard.
     */
    public function index(): View
    {
        return view('admin.dashboard', array_merge(
            $this->dashboard->getSummaryStatistics(),
            [
                'statusOverview' => $this->dashboard->getReptileStatusOverview(),
                'growthSummary' => $this->dashboard->getGrowthSummary(),
                'weightTrend' => $this->dashboard->getWeightTrend(),
                'recentActivity' => $this->dashboard->getRecentActivity(),
                'alerts' => $this->dashboard->getAlerts(),
            ]
        ));
    }
}
