<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreFoodTypeRequest;
use App\Http\Requests\Admin\UpdateFoodTypeRequest;
use App\Models\FoodType;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class FoodTypeController extends Controller
{
    /**
     * Display a listing of the food types.
     */
    public function index(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $status = $request->string('status')->toString();
        $parentFilter = $request->string('parent_id')->toString();

        $foodTypes = FoodType::query()
            ->with('parent')
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('description', 'like', "%{$search}%");
                });
            })
            ->when($status === 'active', fn ($query) => $query->where('status', true))
            ->when($status === 'inactive', fn ($query) => $query->where('status', false))
            ->when($parentFilter === 'top-level', fn ($query) => $query->whereNull('parent_id'))
            ->when(is_numeric($parentFilter), fn ($query) => $query->where('parent_id', (int) $parentFilter))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.food-types.index', [
            'foodTypes' => $foodTypes,
            'topLevelOptions' => $this->activeTopLevel(),
            'search' => $search,
            'status' => $status,
            'parentFilter' => $parentFilter,
        ]);
    }

    /**
     * Show the form for creating a new food type.
     */
    public function create(): View
    {
        return view('admin.food-types.create', [
            'foodType' => new FoodType(['status' => true]),
            'parentOptions' => $this->activeTopLevel(),
        ]);
    }

    /**
     * Store a newly created food type.
     */
    public function store(StoreFoodTypeRequest $request): RedirectResponse
    {
        FoodType::create($request->validated());

        return redirect()
            ->route('admin.food-types.index')
            ->with('success', 'Food type created successfully.');
    }

    /**
     * Show the form for editing the given food type.
     */
    public function edit(FoodType $foodType): View
    {
        $parentOptions = $this->activeTopLevel($foodType);

        // Grandfather in its current parent even if that parent has since gone
        // inactive, so the existing relationship stays visible/selectable.
        if ($foodType->parent && ! $parentOptions->contains('id', $foodType->parent_id)) {
            $parentOptions = $parentOptions->push($foodType->parent)->sortBy('name')->values();
        }

        return view('admin.food-types.edit', [
            'foodType' => $foodType,
            'parentOptions' => $parentOptions,
        ]);
    }

    /**
     * Update the given food type.
     */
    public function update(UpdateFoodTypeRequest $request, FoodType $foodType): RedirectResponse
    {
        $foodType->update($request->validated());

        return redirect()
            ->route('admin.food-types.index')
            ->with('success', 'Food type updated successfully.');
    }

    /**
     * Remove the given food type.
     *
     * A category that still has sub-types must not be deleted (the database's
     * own restrict-on-delete foreign key is the safety net if one is added in
     * between the check and the delete).
     */
    public function destroy(FoodType $foodType): RedirectResponse
    {
        if ($foodType->children()->exists()) {
            return redirect()
                ->route('admin.food-types.index')
                ->with('error', 'This food type cannot be deleted because it has sub-types. Delete or reassign them first, or deactivate it instead.');
        }

        try {
            $foodType->delete();
        } catch (QueryException) {
            return redirect()
                ->route('admin.food-types.index')
                ->with('error', 'This food type cannot be deleted because it has sub-types. Delete or reassign them first, or deactivate it instead.');
        }

        return redirect()
            ->route('admin.food-types.index')
            ->with('success', 'Food type deleted successfully.');
    }

    /**
     * Active top-level categories, ordered by name. Used to populate parent dropdowns.
     *
     * @return Collection<int, FoodType>
     */
    protected function activeTopLevel(?FoodType $except = null): Collection
    {
        // Every parent/category dropdown (index filter, create/edit form)
        // renders only id/name(/status) — see admin.food-types.index and
        // admin.food-types._form.
        return FoodType::whereNull('parent_id')
            ->where('status', true)
            ->when($except?->exists, fn ($query) => $query->where('id', '!=', $except->id))
            ->orderBy('name')
            ->get(['id', 'name', 'status']);
    }
}
