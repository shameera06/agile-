<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

/**
 * "Document action taken" on a still-open Weight Concern — open to any
 * authenticated user (not just Admin). Never accepts status/resolved_*; see
 * HealthAlertController::resolve()/dismiss() for closing a concern.
 */
class UpdateHealthAlertRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'notes' => ['nullable', 'string'],
            // Content-sniffed mime, same rule as StoreMedicalRecordRequest::prescription.
            'evidence' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,pdf', 'max:5120'],
        ];
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            $alert = $this->route('health_alert');

            if ($alert && ! $alert->isActive()) {
                $validator->errors()->add('status', 'Only an active weight concern can be updated.');
            }
        });
    }
}
