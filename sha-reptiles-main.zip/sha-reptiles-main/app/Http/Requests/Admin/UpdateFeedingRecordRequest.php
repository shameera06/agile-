<?php

namespace App\Http\Requests\Admin;

use App\Models\FeedingSchedule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateFeedingRecordRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Only what actually happened during the feeding may be corrected: the
     * reptile, feeding schedule, and food type are a historical snapshot and
     * are never editable here.
     */
    public function rules(): array
    {
        return [
            'feeding_date' => ['required', 'date'],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'quantity_unit' => ['required', Rule::in(array_keys(FeedingSchedule::QUANTITY_UNITS))],
            'weight_before' => ['required', 'numeric', 'gt:0'],
            'weight_after' => ['required', 'numeric', 'gt:0'],
            'weight_after_defecation' => ['nullable', 'numeric', 'gt:0'],
            'notes' => ['nullable', 'string'],
        ];
    }
}
