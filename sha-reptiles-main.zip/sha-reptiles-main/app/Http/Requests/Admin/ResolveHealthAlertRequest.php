<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

/**
 * Resolving a Weight Concern requires documentation to already exist — either
 * already stored on the alert (from a prior "document action taken" step) or
 * submitted with this same request. status/resolved_at/resolved_by are always
 * determined by the server (see HealthAlertService::resolveAlert()) — never
 * accepted from the request.
 */
class ResolveHealthAlertRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'notes' => ['nullable', 'string'],
            'evidence' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,pdf', 'max:5120'],
        ];
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            $alert = $this->route('health_alert');
            $hasDocumentation = filled($this->input('notes')) || filled($alert?->notes);

            if (! $hasDocumentation) {
                $validator->errors()->add('notes', 'Please document the action taken before resolving this weight concern.');
            }
        });
    }
}
