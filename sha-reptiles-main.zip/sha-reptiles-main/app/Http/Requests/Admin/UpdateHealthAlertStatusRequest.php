<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

/**
 * Used by both HealthAlertController::resolve() and ::dismiss(). The
 * resulting status/resolved_at/resolved_by are always determined by the
 * server (see HealthAlertService::resolveAlert()/dismissAlert()) — never
 * accepted from the request — so the only user-supplied field is an
 * optional note.
 */
class UpdateHealthAlertStatusRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'notes' => ['nullable', 'string'],
        ];
    }
}
