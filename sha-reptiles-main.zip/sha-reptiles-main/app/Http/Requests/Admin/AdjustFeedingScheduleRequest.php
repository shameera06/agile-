<?php

namespace App\Http\Requests\Admin;

use App\Models\FeedingScheduleAdjustment;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AdjustFeedingScheduleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * Same as Store/UpdateFeedingScheduleRequest: authorization for this
     * module is enforced at the route-middleware level (currently: any
     * authenticated user), not per-request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'adjusted_next_due_date' => ['required', 'date'],
            'adjusted_next_due_time' => ['required', 'date_format:H:i'],
            'reason' => ['required', Rule::in(array_keys(FeedingScheduleAdjustment::REASONS))],
            'notes' => ['nullable', 'string'],
        ];
    }
}
