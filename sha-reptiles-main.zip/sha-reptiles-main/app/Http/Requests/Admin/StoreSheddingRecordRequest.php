<?php

namespace App\Http\Requests\Admin;

use App\Models\Reptile;
use App\Models\SheddingRecord;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreSheddingRecordRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'reptile_id' => ['required', Rule::exists('reptiles', 'id')],
            'shedding_date' => ['required', 'date'],
            'status' => ['required', Rule::in(array_keys(SheddingRecord::STATUSES))],
            'notes' => ['nullable', 'string'],
            'observations' => ['nullable', 'string'],
        ];
    }

    /**
     * A brand-new shedding record may only be logged for a currently active
     * reptile. Historical records for a reptile that has since gone
     * inactive/sold/transferred/deceased are preserved (never deleted) but
     * are not created after the fact through this check.
     */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            $reptile = Reptile::find($this->input('reptile_id'));

            if ($reptile && $reptile->status !== 'active') {
                $validator->errors()->add('reptile_id', 'Only an active reptile can receive a new shedding record.');
            }
        });
    }
}
