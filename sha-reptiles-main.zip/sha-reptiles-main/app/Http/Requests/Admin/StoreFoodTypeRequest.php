<?php

namespace App\Http\Requests\Admin;

use App\Models\FeedingSchedule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreFoodTypeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            // Only an active top-level category may be chosen as a parent.
            'parent_id' => [
                'nullable',
                Rule::exists('food_types', 'id')->where(fn ($query) => $query->whereNull('parent_id')->where('status', true)),
            ],
            'name' => [
                'required', 'string', 'max:255',
                Rule::unique('food_types', 'name')->where(fn ($query) => $this->scopeToSameParent($query)),
            ],
            'description' => ['nullable', 'string'],
            'status' => ['required', 'boolean'],
            // Drives the default Quantity Unit on a feeding schedule (Module 06);
            // only meaningful for leaf food types, but harmless to set on any row.
            'default_unit' => ['nullable', Rule::in(array_keys(FeedingSchedule::QUANTITY_UNITS))],
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
        ]);
    }

    /**
     * Scope a uniqueness query to the same parent group (top-level items count as
     * their own group), correctly handling the null-parent case via whereNull().
     */
    protected function scopeToSameParent($query)
    {
        $parentId = $this->input('parent_id');

        return $parentId ? $query->where('parent_id', $parentId) : $query->whereNull('parent_id');
    }
}
