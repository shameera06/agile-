<?php

namespace App\Http\Requests\Admin;

use App\Models\Reptile;
use App\Models\Species;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateReptileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            // Either the reptile's current species (even if it has since gone inactive)
            // or any active species — never a *different* inactive species.
            'species_id' => ['required', 'integer', $this->currentOrActiveSpecies()],
            // Optional; when provided it must belong to the submitted species_id.
            'species_variety_id' => [
                'nullable',
                Rule::exists('species_varieties', 'id')->where(
                    fn ($query) => $query->where('species_id', $this->input('species_id'))
                ),
            ],
            'name' => ['required', 'string', 'max:255'],
            'sex' => ['required', Rule::in(array_keys(Reptile::SEXES))],
            'date_of_birth' => ['nullable', 'date', 'before_or_equal:today'],
            'acquisition_date' => ['nullable', 'date', 'before_or_equal:today'],
            'acquisition_source' => ['nullable', 'string', 'max:255'],
            'current_weight' => ['nullable', 'numeric', 'min:0'],
            'weight_unit' => ['nullable', Rule::in(array_keys(Reptile::WEIGHT_UNITS))],
            'length' => ['nullable', 'numeric', 'min:0'],
            'length_unit' => ['nullable', Rule::in(array_keys(Reptile::LENGTH_UNITS))],
            'status' => ['required', Rule::in(array_keys(Reptile::STATUSES))],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'notes' => ['nullable', 'string'],
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
        ]);
    }

    /**
     * A closure rule accepting the reptile's current species id, or any active species id.
     */
    protected function currentOrActiveSpecies(): \Closure
    {
        return function (string $attribute, mixed $value, \Closure $fail) {
            $reptile = $this->route('reptile');

            if ($reptile && (int) $value === $reptile->species_id) {
                return;
            }

            if (! Species::where('id', $value)->where('status', true)->exists()) {
                $fail('The selected species is invalid or inactive.');
            }
        };
    }
}
