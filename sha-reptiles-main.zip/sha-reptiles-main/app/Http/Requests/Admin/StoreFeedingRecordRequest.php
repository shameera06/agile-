<?php

namespace App\Http\Requests\Admin;

use App\Models\FeedingSchedule;
use App\Models\Reptile;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreFeedingRecordRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * A feeding record is normally added directly against a reptile
     * (feeding_schedule_id absent), in which case reptile_id/food_type_id
     * come straight from the request. When feeding_schedule_id is given
     * instead (the legacy "Record Feeding" action from a Feeding Schedule),
     * the reptile/food type are derived from that schedule and reptile_id/
     * food_type_id are ignored — see FeedingRecordController::store().
     */
    public function rules(): array
    {
        return [
            'feeding_schedule_id' => ['nullable', Rule::exists('feeding_schedules', 'id')],
            'reptile_id' => ['required_without:feeding_schedule_id', 'nullable', Rule::exists('reptiles', 'id')],
            'food_type_id' => ['required_without:feeding_schedule_id', 'nullable', Rule::exists('food_types', 'id')],
            'feeding_date' => ['required', 'date'],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'quantity_unit' => ['required', Rule::in(array_keys(FeedingSchedule::QUANTITY_UNITS))],
            'weight_before' => ['required', 'numeric', 'gt:0'],
            'weight_after' => ['required', 'numeric', 'gt:0'],
            'weight_after_defecation' => ['nullable', 'numeric', 'gt:0'],
            'notes' => ['nullable', 'string'],
        ];
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            $feedingScheduleId = $this->input('feeding_schedule_id');

            if ($feedingScheduleId) {
                $feedingSchedule = FeedingSchedule::with('reptile')->find($feedingScheduleId);

                if (! $feedingSchedule) {
                    return;
                }

                if ($feedingSchedule->status !== 'active') {
                    $validator->errors()->add('feeding_schedule_id', 'Only an active feeding schedule can be used to record a feeding.');
                }

                if (! $feedingSchedule->reptile || $feedingSchedule->reptile->status !== 'active') {
                    $validator->errors()->add('feeding_schedule_id', 'This feeding schedule belongs to a reptile that is not currently active.');
                }

                return;
            }

            $reptile = Reptile::find($this->input('reptile_id'));

            if ($reptile && $reptile->status !== 'active') {
                $validator->errors()->add('reptile_id', 'Only an active reptile can have a feeding record added.');
            }
        });
    }
}
