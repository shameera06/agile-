<?php

namespace App\Http\Requests\Admin;

use App\Models\Reptile;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreReptileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            // Only an active species may be assigned to a new reptile.
            'species_id' => [
                'required',
                Rule::exists('species', 'id')->where(fn ($query) => $query->where('status', true)),
            ],
            // Optional: a reptile may be registered under its species type
            // before a variety/morph is chosen. When provided, it must
            // actually belong to the selected species_id — never a variety
            // borrowed from a different species type.
            'species_variety_id' => [
                'nullable',
                Rule::exists('species_varieties', 'id')->where(
                    fn ($query) => $query->where('species_id', $this->input('species_id'))
                ),
            ],
            'name' => ['required', 'string', 'max:255'],
            'sex' => ['required', Rule::in(array_keys(Reptile::SEXES))],
            'date_of_birth' => ['nullable', 'date', 'before_or_equal:today'],
            'acquisition_date' => ['nullable', 'date', 'before_or_equal:today'],
            'acquisition_source' => ['nullable', 'string', 'max:255'],
            'current_weight' => ['nullable', 'numeric', 'min:0'],
            'weight_unit' => ['nullable', Rule::in(array_keys(Reptile::WEIGHT_UNITS))],
            'length' => ['nullable', 'numeric', 'min:0'],
            'length_unit' => ['nullable', Rule::in(array_keys(Reptile::LENGTH_UNITS))],
            'status' => ['required', Rule::in(array_keys(Reptile::STATUSES))],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'notes' => ['nullable', 'string'],
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
        ]);
    }
}
