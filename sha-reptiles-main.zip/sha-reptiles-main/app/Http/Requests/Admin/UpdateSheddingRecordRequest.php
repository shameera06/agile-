<?php

namespace App\Http\Requests\Admin;

use App\Models\SheddingRecord;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateSheddingRecordRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'reptile_id' => ['required', Rule::exists('reptiles', 'id')],
            'shedding_date' => ['required', 'date'],
            'status' => ['required', Rule::in(array_keys(SheddingRecord::STATUSES))],
            'notes' => ['nullable', 'string'],
            'observations' => ['nullable', 'string'],
        ];
    }
}
