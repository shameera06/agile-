<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreMedicalRecordRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'reptile_id' => ['required', Rule::exists('reptiles', 'id')],
            'treatment_date' => ['required', 'date'],
            'symptoms_or_condition' => ['required', 'string'],
            'medicine_name' => ['nullable', 'string', 'max:255'],
            'dosage' => ['nullable', 'string', 'max:255'],
            'treatment_details' => ['nullable', 'string'],
            'veterinarian_name' => ['nullable', 'string', 'max:255'],
            'veterinarian_contact' => ['nullable', 'string', 'max:255'],
            'notes' => ['nullable', 'string'],
            // 'mimes' is checked against the file's actual content (a guessed
            // MIME type), not the client-supplied extension/MIME header, so a
            // renamed executable or an SVG can't slip through as an image/PDF.
            'prescription' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,pdf', 'max:5120'],
        ];
    }
}
