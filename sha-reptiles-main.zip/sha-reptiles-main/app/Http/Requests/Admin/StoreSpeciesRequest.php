<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreSpeciesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            // Optional: a species type may be created before it's assigned to a
            // category, same as before this hierarchy existed.
            'category_id' => ['nullable', Rule::exists('species_categories', 'id')],
            'name' => ['required', 'string', 'max:255', Rule::unique('species', 'name')],
            'scientific_name' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'status' => ['required', 'boolean'],
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
            'scientific_name' => $this->filled('scientific_name') ? trim((string) $this->input('scientific_name')) : null,
        ]);
    }
}
