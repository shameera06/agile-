<?php

namespace App\Http\Requests\Admin;

use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Carbon;
use Illuminate\Validation\Rule;
use Throwable;

class StoreFeedingScheduleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'reptile_id' => ['required', Rule::exists('reptiles', 'id')],
            'food_type_id' => ['required', Rule::exists('food_types', 'id')],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'quantity_unit' => ['required', Rule::in(array_keys(FeedingSchedule::QUANTITY_UNITS))],
            'interval_days' => ['required', 'integer', 'min:1'],
            'first_due_date' => ['required', 'date'],
            'first_due_time' => ['required', 'date_format:H:i'],
            'start_date' => ['required', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'status' => ['required', Rule::in(array_keys(FeedingSchedule::STATUSES))],
            'notes' => ['nullable', 'string'],
        ];
    }

    /**
     * Configure the validator instance with the module's business rules, which
     * go beyond simple field-level checks (active/leaf food type, active
     * reptile, one active schedule per reptile, ...).
     */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            // Unconditional, regardless of status: a schedule may never reference
            // a food category ("parent") — that's a structural invariant, not a
            // business/active-state rule, so no historical schedule is exempt.
            if ($foodType = FoodType::find($this->input('food_type_id'))) {
                if (! $foodType->isLeaf()) {
                    $validator->errors()->add('food_type_id', 'The selected food type is a category with sub-types; choose a specific sub-type instead.');
                } elseif ($this->input('status') === 'active' && ! $foodType->status) {
                    // Inactive-food-type is only rejected when the schedule is/becomes
                    // active — an existing schedule may still be edited (notes, etc.) or
                    // deactivated even after its food type has since gone inactive.
                    $validator->errors()->add('food_type_id', 'The selected food type is inactive and cannot be used for an active feeding schedule.');
                }
            }

            if ($this->input('status') !== 'active') {
                return;
            }

            $reptile = Reptile::find($this->input('reptile_id'));

            if ($reptile && $reptile->status !== 'active') {
                $validator->errors()->add('reptile_id', 'Only an active reptile can receive a new active feeding schedule.');
            }

            if ($reptile && FeedingSchedule::where('reptile_id', $reptile->id)->where('status', 'active')->exists()) {
                $validator->errors()->add('reptile_id', 'This reptile already has an active feeding schedule. Edit or deactivate the existing schedule before creating a new one.');
            }

            $firstDueAt = $this->firstDueAt();

            if ($firstDueAt && $firstDueAt->lt(now(config('app.timezone'))->startOfDay())) {
                $validator->errors()->add('first_due_date', 'The first feeding date must be today or in the future for a new active schedule.');
            }
        });
    }

    /**
     * The combined first-feeding date and time, or null if either part is missing/invalid.
     */
    public function firstDueAt(): ?Carbon
    {
        $date = $this->input('first_due_date');
        $time = $this->input('first_due_time');

        if (! $date || ! $time) {
            return null;
        }

        try {
            return Carbon::parse("{$date} {$time}", config('app.timezone'));
        } catch (Throwable) {
            return null;
        }
    }
}
