<?php

namespace App\Http\Requests\Admin;

use App\Models\FeedingSchedule;
use App\Models\FoodType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateFoodTypeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'parent_id' => ['nullable', $this->validParentRule()],
            'name' => [
                'required', 'string', 'max:255',
                Rule::unique('food_types', 'name')
                    ->where(fn ($query) => $this->scopeToSameParent($query))
                    ->ignore($this->route('food_type')),
            ],
            'description' => ['nullable', 'string'],
            'status' => ['required', 'boolean'],
            'default_unit' => ['nullable', Rule::in(array_keys(FeedingSchedule::QUANTITY_UNITS))],
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
        ]);
    }

    /**
     * Scope a uniqueness query to the same parent group (top-level items count as
     * their own group), correctly handling the null-parent case via whereNull().
     */
    protected function scopeToSameParent($query)
    {
        $parentId = $this->input('parent_id');

        return $parentId ? $query->where('parent_id', $parentId) : $query->whereNull('parent_id');
    }

    /**
     * A closure rule accepting: no parent (clears it), the food type's current
     * parent (even if it has since gone inactive), or any other active
     * top-level category — but never itself, and never any parent at all if
     * this food type already has sub-types of its own (max nesting depth: 2).
     */
    protected function validParentRule(): \Closure
    {
        return function (string $attribute, mixed $value, \Closure $fail) {
            if ($value === null || $value === '') {
                return;
            }

            $foodType = $this->route('food_type');

            if ((int) $value === $foodType->id) {
                $fail('A food type cannot be its own parent.');

                return;
            }

            $isCurrentParent = $foodType->parent_id && (int) $value === $foodType->parent_id;
            $isActiveTopLevel = FoodType::whereNull('parent_id')->where('status', true)->where('id', $value)->exists();

            if (! $isCurrentParent && ! $isActiveTopLevel) {
                $fail('The selected parent category is invalid or inactive.');

                return;
            }

            if ($foodType->children()->exists()) {
                $fail('This food type has its own sub-types and cannot be nested under another category.');
            }
        };
    }
}
