<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Restricts a route to Admin users. Applied only where Staff is explicitly
 * disallowed (currently: deleting a Medical Record) — everything else
 * Admin/Staff can both do stays behind the plain `auth` middleware.
 */
class EnsureUserIsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless($request->user()?->isAdmin(), 403);

        return $next($request);
    }
}
