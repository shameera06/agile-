<?php

namespace App\Services\Admin;

use App\Models\FeedingRecord;
use App\Models\HealthAlert;
use App\Models\Reptile;
use App\Services\HealthAlertService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

/**
 * Builds the data shown on the admin dashboard.
 *
 * Several of the modules this dashboard reports on (Weight & Growth,
 * Notifications, ...) do not exist yet. Every getter below is written to be
 * safe to call right now — before those modules exist — and to start
 * returning real data automatically once the relevant module adds its model
 * and table, without needing to touch this class's public API.
 */
class DashboardService
{
    /**
     * Per-request memoization caches. The dashboard calls several getters
     * (getSummaryStatistics, getReptileStatusOverview, getRecentActivity,
     * ...) that independently need the same underlying counts/table checks.
     * Schema/module availability never changes mid-request and these counts
     * are read-only snapshots for the one page render, so caching them here
     * only avoids re-running the identical query a second/third time in the
     * same request — it never serves stale data across requests (nothing is
     * cached beyond this single DashboardService instance, which itself is
     * created fresh per request).
     *
     * @var array{total: int, active: int, inactive: int}|null
     */
    protected ?array $reptileCounts = null;

    protected ?bool $reptilesAvailable = null;

    protected ?bool $feedingRecordsAvailable = null;

    protected ?bool $healthAlertsAvailable = null;

    public function __construct(protected HealthAlertService $healthAlerts) {}

    /**
     * Primary/secondary summary card counters.
     *
     * @return array{
     *     totalReptiles: int,
     *     activeReptiles: int,
     *     inactiveReptiles: int,
     *     weightChecksDue: int,
     *     growthWarnings: int,
     *     criticalAlerts: int,
     *     activeHealthAlerts: int,
     *     attentionRequiredReptiles: int,
     * }
     */
    public function getSummaryStatistics(): array
    {
        $reptiles = $this->reptileCounts();

        return [
            'totalReptiles' => $reptiles['total'],
            'activeReptiles' => $reptiles['active'],
            'inactiveReptiles' => $reptiles['inactive'],

            // TODO: Weight & Growth module — reptiles due a weight check / below growth target.
            'weightChecksDue' => 0,
            'growthWarnings' => 0,

            // Module 10 (Health Monitoring + Alerts) is the single source of
            // truth for both of these — never a second, independently
            // computed health-status algorithm.
            'criticalAlerts' => $this->healthAlertsTableAvailable()
                ? HealthAlert::where('status', 'active')->where('severity', 'critical')->count()
                : 0,
            'activeHealthAlerts' => $this->healthAlertsTableAvailable() ? $this->healthAlerts->getActiveAlertCount() : 0,
            'attentionRequiredReptiles' => $this->healthAlertsTableAvailable() ? $this->healthAlerts->getAttentionRequiredReptileCount() : 0,
        ];
    }

    /**
     * Reptile status breakdown (counts + share of total) for the status overview chart.
     *
     * @return array{
     *     total: int,
     *     active: array{count: int, percentage: float},
     *     inactive: array{count: int, percentage: float},
     * }
     */
    public function getReptileStatusOverview(): array
    {
        $reptiles = $this->reptileCounts();
        $total = $reptiles['total'];
        $active = $reptiles['active'];
        $inactive = $reptiles['inactive'];

        return [
            'total' => $total,
            'active' => [
                'count' => $active,
                'percentage' => $this->percentageOf($active, $total),
            ],
            'inactive' => [
                'count' => $inactive,
                'percentage' => $this->percentageOf($inactive, $total),
            ],
        ];
    }

    /**
     * A short "Today · 7:00 PM" / "Tomorrow · 9:00 AM" / "Sep 15 · 7:00 PM" label
     * for a date/time, in the application's configured timezone. Used by
     * getRecentActivity() below.
     */
    protected function dueDateLabel(Carbon $dueAt): string
    {
        $now = now(config('app.timezone'));
        $time = $dueAt->format('g:i A');

        if ($dueAt->isSameDay($now)) {
            return "Today · {$time}";
        }

        if ($dueAt->isSameDay($now->copy()->addDay())) {
            return "Tomorrow · {$time}";
        }

        return $dueAt->format('M d').' · '.$time;
    }

    /**
     * Growth target breakdown. Waiting on the Weight & Growth module.
     *
     * @return array{onTarget: int, belowTarget: int, critical: int}
     */
    public function getGrowthSummary(): array
    {
        // TODO: Weight & Growth module — replace with real counts once growth_targets exists.
        return [
            'onTarget' => 0,
            'belowTarget' => 0,
            'critical' => 0,
        ];
    }

    /**
     * Weight trend series for the dashboard chart. Waiting on the Weight & Growth module.
     *
     * @return array{labels: array<int, string>, averageWeight: array<int, float>, targetWeight: array<int, float>}
     */
    public function getWeightTrend(): array
    {
        // TODO: Weight & Growth module — replace with real monthly aggregates (e.g. average
        // recorded weight vs. target weight per month) once weight_records exists.
        return [
            'labels' => [],
            'averageWeight' => [],
            'targetWeight' => [],
        ];
    }

    /**
     * Recent activity across feeding, weight, growth, and observations.
     *
     * Only Feeding Records exist so far; growth target updates and health
     * observations will be merged into this same timeline once those
     * modules exist.
     *
     * @return Collection<int, object>
     */
    public function getRecentActivity(): Collection
    {
        if (! $this->feedingRecordsTableAvailable()) {
            return collect();
        }

        return FeedingRecord::with('reptile')
            ->orderByDesc('feeding_date')
            ->limit(5)
            ->get()
            ->map(fn (FeedingRecord $record) => (object) [
                'description' => "{$record->reptile->name} was fed (".rtrim(rtrim($record->quantity, '0'), '.')." {$record->quantity_unit}).",
                'occurred_at_label' => $this->dueDateLabel($record->feeding_date),
            ]);
    }

    /**
     * Alert summary grouped by severity.
     *
     * Sourced entirely from Module 10's HealthAlert — the single source of
     * truth for reptile health status (see class docblock on
     * HealthAlertService::getAttentionRequiredReptileCount()) — rather than
     * re-deriving warnings directly from FeedingRecord a second time.
     * Overdue-feeding alerts wait on the Notifications module.
     *
     * Each entry carries the reptile_id alongside its message so the
     * dashboard view can link the alert straight to that reptile's Details
     * page.
     *
     * @return array{critical: array<int, array{message: string, reptile_id: int}>, warning: array<int, array{message: string, reptile_id: int}>, info: array<int, array{message: string, reptile_id: int}>}
     */
    public function getAlerts(): array
    {
        if (! $this->healthAlertsTableAvailable()) {
            return ['critical' => [], 'warning' => [], 'info' => []];
        }

        $active = HealthAlert::with('reptile')
            ->where('status', 'active')
            ->orderByDesc('triggered_at')
            ->limit(5)
            ->get();

        $toLinkableAlert = fn (HealthAlert $alert) => [
            'message' => "{$alert->reptile->name}: {$alert->message}",
            'reptile_id' => $alert->reptile_id,
        ];

        return [
            'critical' => $active->where('severity', 'critical')->map($toLinkableAlert)->values()->all(),
            'warning' => $active->where('severity', 'warning')->map($toLinkableAlert)->values()->all(),
            'info' => [],
        ];
    }

    /**
     * Total/active/inactive reptile counts in one place, computed at most
     * once per request and shared by getSummaryStatistics() and
     * getReptileStatusOverview() (both need the exact same three numbers).
     * All zero if Reptile Management (or its status column) has not been
     * implemented yet.
     *
     * @return array{total: int, active: int, inactive: int}
     */
    protected function reptileCounts(): array
    {
        if ($this->reptileCounts !== null) {
            return $this->reptileCounts;
        }

        if (! $this->reptilesTableAvailable() || ! Schema::hasColumn('reptiles', 'status')) {
            return $this->reptileCounts = ['total' => 0, 'active' => 0, 'inactive' => 0];
        }

        return $this->reptileCounts = [
            'total' => Reptile::count(),
            'active' => Reptile::where('status', 'active')->count(),
            'inactive' => Reptile::where('status', 'inactive')->count(),
        ];
    }

    /**
     * Whether the Reptile Management module has been implemented yet.
     * Memoized: Schema::hasTable() itself runs a query, and this is checked
     * from several getters within the same dashboard request.
     */
    protected function reptilesTableAvailable(): bool
    {
        return $this->reptilesAvailable ??= class_exists(Reptile::class) && Schema::hasTable('reptiles');
    }

    /**
     * Whether the Feeding Records module (Module 07) has been implemented yet.
     */
    protected function feedingRecordsTableAvailable(): bool
    {
        return $this->feedingRecordsAvailable ??= class_exists(FeedingRecord::class) && Schema::hasTable('feeding_records');
    }

    /**
     * Whether the Health Alerts module (Module 10) has been implemented yet.
     */
    protected function healthAlertsTableAvailable(): bool
    {
        return $this->healthAlertsAvailable ??= class_exists(HealthAlert::class) && Schema::hasTable('health_alerts');
    }

    /**
     * $part as a percentage of $total, safely handling division by zero.
     */
    protected function percentageOf(int $part, int $total): float
    {
        return $total > 0 ? round(($part / $total) * 100, 1) : 0.0;
    }
}
