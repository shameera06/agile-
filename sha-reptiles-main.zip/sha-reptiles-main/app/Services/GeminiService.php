<?php

namespace App\Services;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/**
 * Thin HTTP wrapper around the Google Gemini API (config('services.gemini')).
 * Knows nothing about reptiles or any other domain concept — any future AI
 * feature can reuse this to send a system/user prompt pair to the configured
 * Gemini model. The browser never talks to Gemini directly and the API key
 * never leaves the server; only this service, from the Laravel backend, ever
 * makes the request.
 */
class GeminiService
{
    /**
     * Send a single-turn request and return its plain-text answer.
     *
     * @return array{success: true, answer: string}|array{success: false, error: string}
     */
    public function chat(string $systemPrompt, string $userPrompt): array
    {
        $apiKey = config('services.gemini.api_key');
        $model = config('services.gemini.model');
        $timeout = (int) config('services.gemini.timeout', 30);

        if (! $apiKey || ! $model) {
            Log::error('AI Reptile Assistant: Gemini is not configured (missing GEMINI_API_KEY or GEMINI_MODEL).');

            return ['success' => false, 'error' => 'not_configured'];
        }

        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent";

        try {
            $response = Http::timeout($timeout)
                ->withHeaders(['x-goog-api-key' => $apiKey])
                ->post($url, [
                    'systemInstruction' => [
                        'parts' => [['text' => $systemPrompt]],
                    ],
                    'contents' => [
                        ['role' => 'user', 'parts' => [['text' => $userPrompt]]],
                    ],
                ]);
        } catch (ConnectionException $e) {
            // Http::timeout() surfaces both "connection refused" and "request
            // timed out" as the same exception class — inspect the message so
            // a timeout can show its own message.
            $isTimeout = Str::contains(strtolower($e->getMessage()), 'timed out');

            Log::error('AI Reptile Assistant: failed to reach Gemini.', [
                'timeout' => $isTimeout,
                'message' => $e->getMessage(),
            ]);

            return ['success' => false, 'error' => $isTimeout ? 'timeout' : 'unavailable'];
        } catch (Throwable $e) {
            Log::error('AI Reptile Assistant: unexpected error calling Gemini.', [
                'message' => $e->getMessage(),
            ]);

            return ['success' => false, 'error' => 'unavailable'];
        }

        if ($response->status() === 401 || $response->status() === 403) {
            Log::error('AI Reptile Assistant: Gemini rejected the configured API key.', [
                'status' => $response->status(),
                'body' => Str::limit($response->body(), 500),
            ]);

            return ['success' => false, 'error' => 'not_configured'];
        }

        if ($response->status() === 429) {
            Log::error('AI Reptile Assistant: Gemini rate limit reached.', [
                'status' => $response->status(),
                'body' => Str::limit($response->body(), 500),
            ]);

            return ['success' => false, 'error' => 'rate_limited'];
        }

        if ($response->failed()) {
            Log::error('AI Reptile Assistant: Gemini returned an error response.', [
                'status' => $response->status(),
                'body' => Str::limit($response->body(), 500),
            ]);

            // A 404 most commonly means the configured model name is invalid
            // or not available to this API key.
            return ['success' => false, 'error' => $response->status() === 404 ? 'model_missing' : 'unavailable'];
        }

        $blockReason = data_get($response->json(), 'promptFeedback.blockReason');

        if ($blockReason) {
            Log::error('AI Reptile Assistant: Gemini blocked the prompt.', ['reason' => $blockReason]);

            return ['success' => false, 'error' => 'unavailable'];
        }

        $content = data_get($response->json(), 'candidates.0.content.parts.0.text');

        if (! is_string($content) || trim($content) === '') {
            Log::error('AI Reptile Assistant: Gemini returned an empty or unexpected response body.', [
                'body' => Str::limit($response->body(), 500),
            ]);

            return ['success' => false, 'error' => 'unavailable'];
        }

        return ['success' => true, 'answer' => trim($content)];
    }
}
