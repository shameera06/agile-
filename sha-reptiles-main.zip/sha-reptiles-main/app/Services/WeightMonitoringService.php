<?php

namespace App\Services;

use App\Models\FeedingRecord;
use App\Models\Reptile;
use Illuminate\Support\Collection;

/**
 * Centralizes all weight-change/trend/alert logic for Feeding Records so it
 * isn't duplicated across the Controller, Blade views, or the model.
 *
 * Key fallback rule used consistently everywhere a record's weight needs to
 * be reduced to a single comparable number ("effective weight"):
 * weight_after_defecation, then weight_after, then weight_before.
 */
class WeightMonitoringService
{
    public const ALERT_MESSAGE = 'The reptile is not gaining weight properly. Please consult a veterinarian.';

    /**
     * The single measurement used to represent a feeding record's weight for
     * trend analysis and for syncing the reptile's current_weight.
     */
    public function getEffectiveWeight(FeedingRecord $record): float
    {
        return (float) ($record->weight_after_defecation ?? $record->weight_after ?? $record->weight_before);
    }

    /**
     * The net weight_change stored on the record: post-defecation weight minus
     * pre-feeding weight when available. When no after-defecation weight has
     * been recorded yet, falls back to post-feeding minus pre-feeding as a
     * temporary stand-in — the missing after-defecation value itself is never
     * backfilled with this calculated number.
     */
    public function calculateWeightChange(FeedingRecord $record): ?float
    {
        if ($record->weight_before === null) {
            return null;
        }

        if ($record->weight_after_defecation !== null) {
            return round((float) $record->weight_after_defecation - (float) $record->weight_before, 2);
        }

        if ($record->weight_after !== null) {
            return round((float) $record->weight_after - (float) $record->weight_before, 2);
        }

        return null;
    }

    /**
     * The immediate weight_after - weight_before change. Shown alongside the
     * net (post-defecation) change for context — food itself can temporarily
     * inflate the measured weight — but is not persisted on the record.
     */
    public function calculateImmediateWeightChange(FeedingRecord $record): ?float
    {
        if ($record->weight_before === null || $record->weight_after === null) {
            return null;
        }

        return round((float) $record->weight_after - (float) $record->weight_before, 2);
    }

    /**
     * gain / no_gain / loss, by comparing this record's effective weight
     * against the previous record's effective weight. Null when there is no
     * previous record (the reptile's first feeding record) — that is not the
     * same as a gain and must be displayed as "First Record" / "N/A".
     */
    public function determineWeightTrend(FeedingRecord $record, ?FeedingRecord $previous): ?string
    {
        if (! $previous) {
            return null;
        }

        $current = $this->getEffectiveWeight($record);
        $previousWeight = $this->getEffectiveWeight($previous);

        if ($current > $previousWeight) {
            return 'gain';
        }

        if ($current < $previousWeight) {
            return 'loss';
        }

        return 'no_gain';
    }

    /**
     * The most recent feeding records for a reptile, newest first, optionally
     * excluding one record id (the record currently being saved/edited).
     *
     * @return Collection<int, FeedingRecord>
     */
    public function previousRecordsFor(int $reptileId, ?int $excludeId = null, int $limit = 3): Collection
    {
        return FeedingRecord::where('reptile_id', $reptileId)
            ->when($excludeId, fn ($query) => $query->where('id', '!=', $excludeId))
            ->orderByDesc('feeding_date')
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }

    /**
     * Whether (at least) three records were given and none of them shows a
     * gain across the sequence. A null weight_trend only ever occurs on a
     * reptile's very first-ever feeding record (nothing to compare it to),
     * so it's treated as the sequence's starting point rather than as a
     * disqualifying result — only an actual 'gain' disqualifies. Used both
     * for the three-record alert trigger (the current record plus its two
     * predecessors) and for highlighting the latest three records on the
     * Reptile Profile — the same rule, different inputs.
     *
     * @param  Collection<int, FeedingRecord>  $records
     */
    public function hasThreeConsecutivePoorGainRecords(Collection $records): bool
    {
        if ($records->count() < 3) {
            return false;
        }

        return $records->take(3)->every(
            fn (FeedingRecord $record) => $record->weight_trend === null
                || in_array($record->weight_trend, FeedingRecord::POOR_GAIN_TRENDS, true)
        );
    }

    /**
     * Whether a feeding record should carry the weight alert: the three
     * feeding records immediately BEFORE it (never the record itself) all
     * show no_gain or loss. Fewer than three previous records never triggers.
     */
    public function shouldTriggerWeightAlert(int $reptileId, ?int $excludeId = null): bool
    {
        return $this->hasThreeConsecutivePoorGainRecords($this->previousRecordsFor($reptileId, $excludeId, 3));
    }

    public function alertMessage(): string
    {
        return self::ALERT_MESSAGE;
    }

    /**
     * Recompute weight_change/weight_trend/weight_alert_* for every feeding
     * record belonging to a reptile, in chronological order, and sync the
     * reptile's current_weight to its latest record's effective weight.
     *
     * Called after a feeding record is created or after an existing one's
     * weight values are edited: an edit can change the trend of every later
     * record for the same reptile (and therefore their alert state too), so
     * the whole history is recalculated rather than just the touched record.
     * Historical quantity/notes fields are never touched here.
     */
    public function recalculateReptileWeightHistory(int $reptileId): void
    {
        $records = FeedingRecord::where('reptile_id', $reptileId)
            ->orderBy('feeding_date')
            ->orderBy('id')
            ->get();

        $processed = collect();

        foreach ($records as $record) {
            $previous = $processed->last();

            $record->weight_change = $this->calculateWeightChange($record);
            $record->weight_trend = $this->determineWeightTrend($record, $previous);

            $processed->push($record);

            // The alert must fire on the record that completes a three-record
            // no-gain sequence — i.e. this record together with its two
            // immediate predecessors — not one record later.
            $latestThree = $processed->slice(-3)->values();
            $alertTriggered = $this->hasThreeConsecutivePoorGainRecords($latestThree);
            $record->weight_alert_triggered = $alertTriggered;
            $record->weight_alert_message = $alertTriggered ? $this->alertMessage() : null;

            $record->save();
        }

        if ($latest = $processed->last()) {
            Reptile::whereKey($reptileId)->update(['current_weight' => $this->getEffectiveWeight($latest)]);
        }
    }
}
