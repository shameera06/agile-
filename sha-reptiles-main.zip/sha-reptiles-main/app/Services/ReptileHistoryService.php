<?php

namespace App\Services;

use App\Models\FeedingRecord;
use App\Models\HealthAlert;
use App\Models\MedicalRecord;
use App\Models\Reptile;
use App\Models\SheddingRecord;
use Illuminate\Support\Collection;

/**
 * Builds the data shown on Module 11's Complete History page — a read-only
 * aggregation view over records that already exist in Modules 7-10 (Feeding/
 * Weight, Shedding, Medical, Health Alerts). Creates nothing, modifies
 * nothing, and never recalculates a value another module already owns
 * (weight trend/effective weight stay WeightMonitoringService's job).
 *
 * Every query here is explicitly scoped by reptile_id — see each method —
 * so one reptile's history can never include another's records.
 */
class ReptileHistoryService
{
    public function __construct(protected WeightMonitoringService $weightMonitoring) {}

    /**
     * Cheap count/aggregate queries only — never loads full historical
     * collections into memory just to count or summarize them.
     *
     * @return array{
     *     totalFeedingRecords: int,
     *     totalSheddingRecords: int,
     *     totalMedicalRecords: int,
     *     totalHealthAlerts: int,
     *     activeHealthAlerts: int,
     * }
     */
    public function getHistoryCounts(Reptile $reptile): array
    {
        return [
            'totalFeedingRecords' => FeedingRecord::where('reptile_id', $reptile->id)->count(),
            'totalSheddingRecords' => SheddingRecord::where('reptile_id', $reptile->id)->count(),
            'totalMedicalRecords' => MedicalRecord::where('reptile_id', $reptile->id)->count(),
            'totalHealthAlerts' => HealthAlert::where('reptile_id', $reptile->id)->count(),
            'activeHealthAlerts' => HealthAlert::where('reptile_id', $reptile->id)->where('status', 'active')->count(),
        ];
    }

    /**
     * The single latest record of each type, for the "Latest Records" /
     * "Current Health Status" summary — a handful of small, indexed,
     * single-row queries rather than loading each full history.
     *
     * @return array{
     *     feeding: ?FeedingRecord,
     *     shedding: ?SheddingRecord,
     *     medical: ?MedicalRecord,
     *     healthAlert: ?HealthAlert,
     * }
     */
    public function getLatestRecords(Reptile $reptile): array
    {
        return [
            'feeding' => FeedingRecord::where('reptile_id', $reptile->id)
                ->with('foodType.parent')
                ->orderByDesc('feeding_date')->orderByDesc('id')->first(),
            'shedding' => SheddingRecord::where('reptile_id', $reptile->id)
                ->orderByDesc('shedding_date')->orderByDesc('id')->first(),
            'medical' => MedicalRecord::where('reptile_id', $reptile->id)
                ->orderByDesc('treatment_date')->orderByDesc('id')->first(),
            'healthAlert' => HealthAlert::where('reptile_id', $reptile->id)
                ->orderByDesc('triggered_at')->orderByDesc('id')->first(),
        ];
    }

    /**
     * Every active alert for this reptile — displayed prominently at the
     * top of the History page (see the module spec's "Weight Alert"
     * section). Never generates a new alert; Module 10 already owns that.
     *
     * @return Collection<int, HealthAlert>
     */
    public function getActiveHealthAlerts(Reptile $reptile): Collection
    {
        return HealthAlert::where('reptile_id', $reptile->id)
            ->where('status', 'active')
            ->orderByDesc('triggered_at')
            ->get();
    }

    /**
     * The ids of the feeding records that must render with a red "poor
     * gain" highlight: the reptile's latest three feeding records, but only
     * when ALL THREE already satisfy Module 7's own, unmodified
     * WeightMonitoringService::hasThreeConsecutivePoorGainRecords() rule —
     * the exact same check ReptileController::show() already applies to
     * the Reptile Profile's Feeding tab. No second "poor gain" definition.
     *
     * @return Collection<int, int>
     */
    public function getHighlightedFeedingRecordIds(Reptile $reptile): Collection
    {
        $latestThree = FeedingRecord::where('reptile_id', $reptile->id)
            ->orderByDesc('feeding_date')
            ->orderByDesc('id')
            ->limit(3)
            ->get();

        return $this->weightMonitoring->hasThreeConsecutivePoorGainRecords($latestThree)
            ? $latestThree->pluck('id')
            : collect();
    }

    /**
     * Current weight, latest weight trend, and the reptile's own DOB/status
     * — read straight off the existing Reptile row, nothing derived or
     * duplicated (see the module spec's "Current Health Status" section).
     *
     * @return array{currentWeight: ?string, weightUnit: string, recentWeightTrend: ?string}
     */
    public function getCurrentHealthStatus(Reptile $reptile, ?FeedingRecord $latestFeeding): array
    {
        return [
            'currentWeight' => $reptile->current_weight,
            'weightUnit' => $reptile->weight_unit,
            'recentWeightTrend' => $latestFeeding?->weight_trend,
        ];
    }

    /**
     * Module 12 (PDF/Print) reuses these four full-collection getters rather
     * than the on-screen page's Yajra DataTables — a PDF is generated
     * server-side in one shot, it never makes a browser ajax round trip, so
     * it cannot depend on FeedingHistoryDataTable/SheddingHistoryDataTable/
     * MedicalRecordDataTable/HealthAlertDataTable directly. Each method below
     * mirrors that DataTable's own query() scoping/ordering/eager-loading
     * exactly — same reptile_id scope, same columns, same sort — so the PDF
     * and the on-screen Complete History page always describe the same
     * underlying records.
     */

    /**
     * Every Feeding & Weight History record for one reptile, newest first —
     * mirrors FeedingHistoryDataTable::query(). weight_change/weight_trend
     * are read straight off the stored record (already computed by
     * WeightMonitoringService::recalculateReptileWeightHistory()), never
     * recalculated here.
     *
     * @return Collection<int, FeedingRecord>
     */
    public function getFeedingHistory(Reptile $reptile): Collection
    {
        return FeedingRecord::where('reptile_id', $reptile->id)
            ->with('foodType.parent')
            ->orderByDesc('feeding_date')
            ->orderByDesc('id')
            ->get();
    }

    /**
     * @return Collection<int, SheddingRecord>
     */
    public function getSheddingHistory(Reptile $reptile): Collection
    {
        return SheddingRecord::where('reptile_id', $reptile->id)
            ->with('createdBy')
            ->orderByDesc('shedding_date')
            ->orderByDesc('id')
            ->get();
    }

    /**
     * @return Collection<int, MedicalRecord>
     */
    public function getMedicalHistory(Reptile $reptile): Collection
    {
        return MedicalRecord::where('reptile_id', $reptile->id)
            ->with('createdBy')
            ->orderByDesc('treatment_date')
            ->orderByDesc('id')
            ->get();
    }

    /**
     * Every Health Alert regardless of status (active/resolved/dismissed) —
     * distinct from getActiveHealthAlerts() above, which is active-only.
     *
     * @return Collection<int, HealthAlert>
     */
    public function getHealthAlertHistory(Reptile $reptile): Collection
    {
        return HealthAlert::where('reptile_id', $reptile->id)
            ->with('resolvedBy')
            ->orderByDesc('triggered_at')
            ->orderByDesc('id')
            ->get();
    }

    /**
     * The single measurement used to represent a feeding record's weight —
     * delegates straight to Module 7's own WeightMonitoringService so the
     * PDF's "Effective Weight" column never recalculates this itself.
     */
    public function getEffectiveWeight(FeedingRecord $record): float
    {
        return $this->weightMonitoring->getEffectiveWeight($record);
    }
}
