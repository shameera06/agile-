<?php

namespace App\Services;

use App\Mail\WeightConcernCreated;
use App\Models\FeedingRecord;
use App\Models\HealthAlert;
use App\Models\Reptile;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Mail;

/**
 * The Health Alert layer described in Module 10. This service never
 * calculates weight data itself — WeightMonitoringService (Module 7) remains
 * the sole source of truth for weight_trend/weight_alert_triggered/etc.
 * This service only turns an already-computed weight_alert_triggered result
 * into a persisted, auditable HealthAlert.
 */
class HealthAlertService
{
    /**
     * Create the automatic weight HealthAlert for a feeding record, if (and
     * only if) that record's existing Module 7 result says it should carry
     * one. Idempotent: health_alerts.feeding_record_id is uniquely
     * constrained, so calling this any number of times for the same record
     * — e.g. because recalculateReptileWeightHistory() reprocesses a
     * reptile's whole history on every save — never creates a duplicate.
     *
     * Returns null when the record doesn't (or no longer) trigger an alert,
     * or when one already exists for it.
     */
    public function createWeightAlertFromFeedingRecord(FeedingRecord $record): ?HealthAlert
    {
        if (! $record->weight_alert_triggered) {
            return null;
        }

        $alert = HealthAlert::firstOrCreate(
            ['feeding_record_id' => $record->id],
            [
                'reptile_id' => $record->reptile_id,
                'alert_type' => 'weight',
                'title' => HealthAlert::WEIGHT_ALERT_TITLE,
                // The exact, unmodified Module 7 message — never retyped.
                'message' => $record->weight_alert_message ?? FeedingRecord::ALERT_MESSAGE,
                'severity' => 'warning',
                'status' => 'active',
                'source' => 'feeding_record',
                'triggered_at' => $record->feeding_date,
            ]
        );

        // firstOrCreate() returns the existing row untouched when one
        // already existed — nothing more to do either way.
        return $alert;
    }

    /**
     * Sync alerts for every one of a reptile's feeding records that
     * currently carries weight_alert_triggered = true. Called after
     * FeedingRecordController's store()/update() recalculates the reptile's
     * whole weight history (an edit can newly trigger — or stop triggering
     * — the condition for records other than the one just saved); already-
     * existing alerts are left exactly as they are (see class docblock: this
     * service never deletes or auto-resolves an alert).
     *
     * @return Collection<int, HealthAlert> the alerts actually created by this call (not pre-existing ones)
     */
    public function syncWeightAlertsForReptile(int $reptileId): Collection
    {
        return FeedingRecord::where('reptile_id', $reptileId)
            ->where('weight_alert_triggered', true)
            ->get()
            ->map(fn (FeedingRecord $record) => $this->createWeightAlertFromFeedingRecord($record))
            ->filter(fn (?HealthAlert $alert) => $alert?->wasRecentlyCreated)
            ->values();
    }

    /**
     * One-time/idempotent backfill across every reptile — for feeding
     * records that already had weight_alert_triggered = true before Module
     * 10 existed. Safe to run any number of times (same uniqueness
     * guarantee as createWeightAlertFromFeedingRecord()); never touches
     * feeding_records. See App\Console\Commands\BackfillHealthAlerts.
     *
     * @return int number of alerts actually created
     */
    public function backfillFromExistingFeedingRecords(): int
    {
        return FeedingRecord::where('weight_alert_triggered', true)
            ->get()
            ->filter(fn (FeedingRecord $record) => $this->createWeightAlertFromFeedingRecord($record)?->wasRecentlyCreated)
            ->count();
    }

    /**
     * Mark an active alert resolved by the given (Admin) user. Never
     * touches the triggering feeding record or any historical weight value
     * — only this alert's own status/audit fields change. Requiring that
     * documentation exist before this is called is the caller's job (see
     * ResolveHealthAlertRequest) — this method only persists it.
     */
    public function resolveAlert(HealthAlert $alert, User $user, ?string $notes = null, ?string $evidencePath = null): HealthAlert
    {
        $alert->update([
            'status' => 'resolved',
            'resolved_at' => now(),
            'resolved_by' => $user->id,
            'notes' => $notes ?? $alert->notes,
            'evidence_path' => $evidencePath ?? $alert->evidence_path,
        ]);

        return $alert;
    }

    /**
     * Record what action was taken on a still-open concern — notes and/or
     * supporting evidence — without closing it. Any authenticated user (not
     * just Admin) can do this; it's the "document action taken" step that
     * happens before an Admin resolves the concern.
     */
    public function recordAction(HealthAlert $alert, ?string $notes, ?string $evidencePath = null): HealthAlert
    {
        $alert->update([
            'notes' => $notes ?? $alert->notes,
            'evidence_path' => $evidencePath ?? $alert->evidence_path,
        ]);

        return $alert;
    }

    /**
     * Email every Admin user about each newly created Weight Concern.
     * Callers pass only genuinely new alerts (e.g.
     * syncWeightAlertsForReptile()'s return value, already filtered to
     * wasRecentlyCreated) so a resync/edit that doesn't create a new alert
     * row can never send a duplicate email for an already-open concern.
     * Never called from the historical backfill command — a one-time
     * backfill must not email admins about old data.
     *
     * @param  Collection<int, HealthAlert>  $alerts
     */
    public function notifyNewAlerts(Collection $alerts): void
    {
        if ($alerts->isEmpty()) {
            return;
        }

        $recipients = $this->adminRecipients();

        if (empty($recipients)) {
            return;
        }

        foreach ($alerts as $alert) {
            Mail::to($recipients)->send(new WeightConcernCreated($alert));
        }
    }

    /**
     * @return array<int, string>
     */
    protected function adminRecipients(): array
    {
        return User::where('role', 'admin')->whereNotNull('email')->pluck('email')->all();
    }

    /**
     * Mark an active alert dismissed by the given (Admin) user. The
     * suggested health_alerts schema has no separate dismissed_at/
     * dismissed_by pair, so resolved_at/resolved_by double as "closed
     * at/by" for both terminal states — the alert itself is never deleted,
     * only its status changes (see class docblock).
     */
    public function dismissAlert(HealthAlert $alert, User $user, ?string $notes = null): HealthAlert
    {
        $alert->update([
            'status' => 'dismissed',
            'resolved_at' => now(),
            'resolved_by' => $user->id,
            'notes' => $notes ?? $alert->notes,
        ]);

        return $alert;
    }

    /**
     * @return Collection<int, HealthAlert>
     */
    public function getActiveAlertsForReptile(int $reptileId): Collection
    {
        return HealthAlert::where('reptile_id', $reptileId)
            ->where('status', 'active')
            ->orderByDesc('triggered_at')
            ->get();
    }

    public function getActiveAlertCount(): int
    {
        return HealthAlert::where('status', 'active')->count();
    }

    /**
     * Number of distinct reptiles that currently have at least one active
     * alert — the single source of truth for "Attention Required" (see
     * Reptile Management's Health Status column and the Dashboard card).
     */
    public function getAttentionRequiredReptileCount(): int
    {
        return Reptile::whereHas('healthAlerts', fn ($query) => $query->where('status', 'active'))->count();
    }
}
