<?php

namespace App\Mail;

use App\Models\HealthAlert;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Sent to Admin users when Module 7's weight monitoring auto-creates a new
 * HealthAlert (a "Weight Concern") for a reptile. Deliberately NOT
 * ShouldQueue — this app's QUEUE_CONNECTION is sync and nothing else here
 * queues mail, so sending synchronously (right after the triggering DB
 * transaction commits — see HealthAlertService::notifyNewAlerts()) keeps
 * this consistent with the rest of the codebase.
 */
class WeightConcernCreated extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public HealthAlert $healthAlert) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: "Weight Concern: {$this->healthAlert->reptile->name}",
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.weight-concern-created',
        );
    }
}
