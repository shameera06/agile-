<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MedicalRecord extends Model
{
    use HasFactory;

    protected $fillable = [
        'reptile_id',
        'treatment_date',
        'symptoms_or_condition',
        'medicine_name',
        'dosage',
        'treatment_details',
        'veterinarian_name',
        'veterinarian_contact',
        'notes',
        'prescription_path',
        'created_by',
    ];

    protected $casts = [
        'treatment_date' => 'date',
    ];

    public function reptile(): BelongsTo
    {
        return $this->belongsTo(Reptile::class);
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function hasPrescription(): bool
    {
        return ! empty($this->prescription_path);
    }
}
