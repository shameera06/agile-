<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SheddingRecord extends Model
{
    use HasFactory;

    /**
     * Allowed values for `status`, keyed by stored value. A record
     * classification only — "problematic" never implies a diagnosis.
     *
     * @var array<string, string>
     */
    public const STATUSES = [
        'complete' => 'Complete',
        'partial' => 'Partial',
        'incomplete' => 'Incomplete',
        'problematic' => 'Problematic',
    ];

    protected $fillable = [
        'reptile_id',
        'shedding_date',
        'status',
        'notes',
        'observations',
        'created_by',
    ];

    protected $casts = [
        'shedding_date' => 'date',
    ];

    public function reptile(): BelongsTo
    {
        return $this->belongsTo(Reptile::class);
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
