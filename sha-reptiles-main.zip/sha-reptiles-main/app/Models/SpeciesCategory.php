<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Top level of the Species → Category → Type → Variety hierarchy
 * (e.g. Snake, Iguana, Bearded Dragon). Species Types (the existing
 * `species` table) belong to a category.
 */
class SpeciesCategory extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'status',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'status' => 'boolean',
    ];

    /**
     * The Species Types (existing `species` rows) registered under this category.
     */
    public function speciesTypes(): HasMany
    {
        return $this->hasMany(Species::class, 'category_id');
    }
}
