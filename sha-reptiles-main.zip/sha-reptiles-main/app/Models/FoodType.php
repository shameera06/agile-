<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FoodType extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'parent_id',
        'name',
        'description',
        'status',
        'default_unit',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'status' => 'boolean',
    ];

    /**
     * The parent category this food type belongs to (null if it is itself top-level).
     */
    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    /**
     * The sub-types/variants belonging to this food type (only populated for
     * top-level categories; a maximum nesting depth of two levels is enforced
     * in the Form Requests).
     */
    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    /**
     * The feeding schedules that use this food type (only ever a leaf food type
     * in practice; validated in the feeding-schedule Form Requests).
     */
    public function feedingSchedules(): HasMany
    {
        return $this->hasMany(FeedingSchedule::class);
    }

    /**
     * The actual feeding records that recorded this food type being fed.
     */
    public function feedingRecords(): HasMany
    {
        return $this->hasMany(FeedingRecord::class);
    }

    /**
     * Whether this is a top-level category rather than a sub-type/variant.
     */
    public function isTopLevel(): bool
    {
        return $this->parent_id === null;
    }

    /**
     * Whether this food type is a leaf (has no sub-types of its own). Only leaf
     * food types may be used on a feeding schedule — a category like "Mouse" is
     * not itself a feeding item, only its variants ("Pinky", "Fuzzy", ...) are.
     */
    public function isLeaf(): bool
    {
        return ! $this->children()->exists();
    }

    /**
     * Scope a query to leaf food types only (no sub-types of their own).
     */
    public function scopeLeaf(Builder $query): Builder
    {
        return $query->whereDoesntHave('children');
    }
}
