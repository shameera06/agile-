<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FeedingScheduleAdjustment extends Model
{
    use HasFactory;

    /**
     * Allowed values for `reason`, keyed by stored value. A management
     * reason entered by staff — never an automated medical diagnosis.
     *
     * @var array<string, string>
     */
    public const REASONS = [
        'digestion_delay' => 'Digestion delay',
        'not_defecated' => 'Has not defecated',
        'feeding_skipped' => 'Feeding skipped',
        'health_observation' => 'Health observation',
        'temporary_adjustment' => 'Temporary schedule adjustment',
        'other' => 'Other',
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'feeding_schedule_id',
        'reptile_id',
        'original_next_due_at',
        'adjusted_next_due_at',
        'reason',
        'notes',
        'adjusted_by',
        'adjusted_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'original_next_due_at' => 'datetime',
        'adjusted_next_due_at' => 'datetime',
        'adjusted_at' => 'datetime',
    ];

    public function feedingSchedule(): BelongsTo
    {
        return $this->belongsTo(FeedingSchedule::class);
    }

    public function reptile(): BelongsTo
    {
        return $this->belongsTo(Reptile::class);
    }

    public function adjustedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'adjusted_by');
    }
}
