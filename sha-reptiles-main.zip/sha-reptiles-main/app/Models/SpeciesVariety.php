<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Third level of the Species → Category → Type → Variety hierarchy
 * (e.g. "Royal Python" under the "Python Snake" species type). Individual
 * reptiles optionally belong to a variety via `reptiles.species_variety_id`.
 */
class SpeciesVariety extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'species_id',
        'name',
        'status',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'status' => 'boolean',
    ];

    /**
     * The Species Type (existing `species` row) this variety belongs to.
     */
    public function species(): BelongsTo
    {
        return $this->belongsTo(Species::class);
    }

    /**
     * Individual reptiles registered under this variety.
     */
    public function reptiles(): HasMany
    {
        return $this->hasMany(Reptile::class);
    }
}
