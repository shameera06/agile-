<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A derived, historical health event for one individual reptile — currently
 * generated only from Module 7's existing weight-monitoring result (see
 * HealthAlertService::createWeightAlertFromFeedingRecord()). Never deleted:
 * status moves between active/resolved/dismissed so the event stays
 * auditable. Never recalculates or stores weight data itself — that remains
 * WeightMonitoringService's/FeedingRecord's responsibility.
 */
class HealthAlert extends Model
{
    use HasFactory;

    /**
     * Allowed values for `alert_type`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const ALERT_TYPES = [
        'weight' => 'Weight',
    ];

    /**
     * Allowed values for `severity`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const SEVERITIES = [
        'warning' => 'Warning',
        'critical' => 'Critical',
    ];

    /**
     * Allowed values for `status`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const STATUSES = [
        'active' => 'Active',
        'resolved' => 'Resolved',
        'dismissed' => 'Dismissed',
    ];

    /**
     * Allowed values for `source`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const SOURCES = [
        'feeding_record' => 'Feeding Record',
        'manual' => 'Manual',
    ];

    /**
     * The exact, unmodified Module 7 weight-alert warning. Re-exported here
     * (rather than retyped) so every automatic weight HealthAlert always
     * carries precisely this message.
     */
    public const WEIGHT_ALERT_TITLE = 'Weight Gain Alert';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'reptile_id',
        'feeding_record_id',
        'alert_type',
        'title',
        'message',
        'severity',
        'status',
        'source',
        'triggered_at',
        'resolved_at',
        'resolved_by',
        'notes',
        'evidence_path',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'triggered_at' => 'datetime',
        'resolved_at' => 'datetime',
    ];

    public function reptile(): BelongsTo
    {
        return $this->belongsTo(Reptile::class);
    }

    public function feedingRecord(): BelongsTo
    {
        return $this->belongsTo(FeedingRecord::class);
    }

    public function resolvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function hasEvidence(): bool
    {
        return ! empty($this->evidence_path);
    }
}
