<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FeedingRecord extends Model
{
    use HasFactory;

    public const WEIGHT_TRENDS = [
        'gain' => 'Gain',
        'no_gain' => 'No Gain',
        'loss' => 'Loss',
    ];

    public const POOR_GAIN_TRENDS = ['no_gain', 'loss'];

    public const ALERT_MESSAGE = 'The reptile is not gaining weight properly. Please consult a veterinarian.';

    protected $fillable = [
        'reptile_id',
        'feeding_schedule_id',
        'food_type_id',
        'feeding_date',
        'quantity',
        'quantity_unit',
        'weight_before',
        'weight_after',
        'weight_after_defecation',
        'weight_change',
        'weight_trend',
        'weight_alert_triggered',
        'weight_alert_message',
        'notes',
        'created_by',
    ];

    protected $casts = [
        'feeding_date' => 'datetime',
        'quantity' => 'decimal:2',
        'weight_before' => 'decimal:2',
        'weight_after' => 'decimal:2',
        'weight_after_defecation' => 'decimal:2',
        'weight_change' => 'decimal:2',
        'weight_alert_triggered' => 'boolean',
    ];

    public function reptile(): BelongsTo
    {
        return $this->belongsTo(Reptile::class);
    }

    public function feedingSchedule(): BelongsTo
    {
        return $this->belongsTo(FeedingSchedule::class);
    }

    public function foodType(): BelongsTo
    {
        return $this->belongsTo(FoodType::class);
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * At most one, in practice (see health_alerts.feeding_record_id's unique
     * index) — a hasMany rather than hasOne only because that's the
     * relationship Eloquent needs to stay symmetric with HealthAlert's
     * belongsTo; see HealthAlertService::createWeightAlertFromFeedingRecord().
     */
    public function healthAlerts(): HasMany
    {
        return $this->hasMany(HealthAlert::class);
    }
}
