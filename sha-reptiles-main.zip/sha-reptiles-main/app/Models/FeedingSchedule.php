<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FeedingSchedule extends Model
{
    use HasFactory;

    /**
     * Allowed values for `status`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const STATUSES = [
        'active' => 'Active',
        'inactive' => 'Inactive',
        'completed' => 'Completed',
    ];

    /**
     * Allowed values for `quantity_unit`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const QUANTITY_UNITS = [
        'piece' => 'Piece',
        'gram' => 'Gram',
        'kg' => 'Kilogram (kg)',
        'ml' => 'Milliliter (ml)',
        'liter' => 'Liter (L)',
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'reptile_id',
        'food_type_id',
        'quantity',
        'quantity_unit',
        'interval_days',
        'first_due_at',
        'next_due_at',
        'start_date',
        'end_date',
        'status',
        'notes',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'quantity' => 'decimal:2',
        'first_due_at' => 'datetime',
        'next_due_at' => 'datetime',
        'start_date' => 'date',
        'end_date' => 'date',
    ];

    public function reptile(): BelongsTo
    {
        return $this->belongsTo(Reptile::class);
    }

    public function foodType(): BelongsTo
    {
        return $this->belongsTo(FoodType::class);
    }

    public function feedingRecords(): HasMany
    {
        return $this->hasMany(FeedingRecord::class);
    }

    /**
     * All "Adjust Next Feeding" audit entries for this schedule, most recent first.
     */
    public function adjustments(): HasMany
    {
        return $this->hasMany(FeedingScheduleAdjustment::class)->orderByDesc('adjusted_at');
    }

    /**
     * This schedule's current due bucket ("overdue", "due_today", "upcoming"),
     * or null if it isn't active (inactive/completed schedules are never due).
     *
     * When a due date earlier today hasn't been acted on, it's reported as
     * "overdue" rather than "due_today" — "due today" means still actionable
     * later today, not already past.
     */
    public function dueStatus(): ?string
    {
        if ($this->status !== 'active') {
            return null;
        }

        $now = now(config('app.timezone'));

        if ($this->next_due_at->lt($now)) {
            return 'overdue';
        }

        if ($this->next_due_at->lte($now->copy()->endOfDay())) {
            return 'due_today';
        }

        return 'upcoming';
    }

    /**
     * Scope a query to active schedules that are currently overdue.
     */
    public function scopeOverdue(Builder $query): Builder
    {
        return $query->where('status', 'active')
            ->where('next_due_at', '<', now(config('app.timezone')));
    }

    /**
     * Scope a query to active schedules due later today (not already overdue).
     */
    public function scopeDueToday(Builder $query): Builder
    {
        $now = now(config('app.timezone'));

        return $query->where('status', 'active')
            ->whereBetween('next_due_at', [$now, $now->copy()->endOfDay()]);
    }

    /**
     * Scope a query to active schedules due on a future day.
     */
    public function scopeUpcoming(Builder $query): Builder
    {
        return $query->where('status', 'active')
            ->where('next_due_at', '>', now(config('app.timezone'))->endOfDay());
    }
}
