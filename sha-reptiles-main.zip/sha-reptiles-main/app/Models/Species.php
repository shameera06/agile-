<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * This is the "Species Type" level of the Species → Category → Type →
 * Variety hierarchy (e.g. "Corn Snake", "Python Snake"). The table/model
 * name is unchanged from before the hierarchy existed — only a nullable
 * `category_id` was added — so every pre-existing relationship below
 * (reptiles, feeding/shedding/medical records via those reptiles) keeps
 * working exactly as it did.
 */
class Species extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'category_id',
        'name',
        'scientific_name',
        'description',
        'status',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'status' => 'boolean',
    ];

    /**
     * The Category (top of the hierarchy) this species type belongs to.
     * Nullable: a species type may not yet be assigned to a category.
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(SpeciesCategory::class, 'category_id');
    }

    /**
     * The Varieties/Morphs registered under this species type.
     */
    public function varieties(): HasMany
    {
        return $this->hasMany(SpeciesVariety::class);
    }

    public function reptiles(): HasMany
    {
        return $this->hasMany(Reptile::class);
    }
}
