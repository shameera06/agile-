<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Storage;

class Reptile extends Model
{
    use HasFactory;

    /**
     * Allowed values for `sex`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const SEXES = [
        'male' => 'Male',
        'female' => 'Female',
        'unknown' => 'Unknown',
    ];

    /**
     * Allowed values for `status`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const STATUSES = [
        'active' => 'Active',
        'inactive' => 'Inactive',
        'transferred' => 'Transferred',
        'sold' => 'Sold',
        'deceased' => 'Deceased',
    ];

    /**
     * Allowed values for `weight_unit`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const WEIGHT_UNITS = [
        'g' => 'Grams (g)',
        'kg' => 'Kilograms (kg)',
        'oz' => 'Ounces (oz)',
        'lb' => 'Pounds (lb)',
    ];

    /**
     * Allowed values for `length_unit`, keyed by stored value.
     *
     * @var array<string, string>
     */
    public const LENGTH_UNITS = [
        'cm' => 'Centimeters (cm)',
        'in' => 'Inches (in)',
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'species_id',
        'species_variety_id',
        'name',
        'reptile_code',
        'sex',
        'date_of_birth',
        'acquisition_date',
        'acquisition_source',
        'current_weight',
        'weight_unit',
        'length',
        'length_unit',
        'status',
        'photo',
        'notes',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'date_of_birth' => 'date',
        'acquisition_date' => 'date',
        'current_weight' => 'decimal:2',
        'length' => 'decimal:2',
    ];

    public function species(): BelongsTo
    {
        return $this->belongsTo(Species::class);
    }

    /**
     * The Variety/Morph (bottom of the Species → Category → Type → Variety
     * hierarchy) this reptile is registered under. Nullable: a reptile may
     * not yet be assigned to a variety (e.g. every reptile that existed
     * before this hierarchy was introduced).
     */
    public function variety(): BelongsTo
    {
        return $this->belongsTo(SpeciesVariety::class, 'species_variety_id');
    }

    public function feedingSchedules(): HasMany
    {
        return $this->hasMany(FeedingSchedule::class);
    }

    public function feedingRecords(): HasMany
    {
        return $this->hasMany(FeedingRecord::class);
    }

    public function sheddingRecords(): HasMany
    {
        return $this->hasMany(SheddingRecord::class);
    }

    public function medicalRecords(): HasMany
    {
        return $this->hasMany(MedicalRecord::class);
    }

    public function healthAlerts(): HasMany
    {
        return $this->hasMany(HealthAlert::class);
    }

    // Future modules will add:
    //
    // public function growthTargets(): HasMany { ... }
    // public function notifications(): HasMany { ... }

    /**
     * The public URL of the reptile's photo, or null if it has none.
     */
    protected function photoUrl(): Attribute
    {
        return Attribute::get(fn () => $this->photo ? Storage::disk('public')->url($this->photo) : null);
    }
}
