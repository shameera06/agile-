<?php

namespace App\Console\Commands;

use App\Services\HealthAlertService;
use Illuminate\Console\Command;

/**
 * One-time/idempotent backfill for Module 10: creates a HealthAlert for any
 * feeding record that already had weight_alert_triggered = true before this
 * module existed. Safe to run any number of times — health_alerts.
 * feeding_record_id is uniquely constrained, so an already-backfilled (or
 * already auto-created) record is simply skipped, never duplicated. Never
 * modifies feeding_records or any historical weight value.
 *
 * Usage: php artisan health-alerts:backfill
 */
class BackfillHealthAlerts extends Command
{
    protected $signature = 'health-alerts:backfill';

    protected $description = 'Create Health Alerts for existing feeding records that already carry weight_alert_triggered = true (idempotent, safe to re-run)';

    public function handle(HealthAlertService $healthAlerts): int
    {
        $this->info('Backfilling Health Alerts from existing feeding records...');

        $created = $healthAlerts->backfillFromExistingFeedingRecords();

        $this->info("Done. {$created} new health alert(s) created; any already-covered feeding record was skipped.");

        return self::SUCCESS;
    }
}
