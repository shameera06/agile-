<?php

namespace App\DataTables;

use App\Models\HealthAlert;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

/**
 * Server-side listing for Health Alerts — modeled directly on the existing
 * App\DataTables\MedicalRecordDataTable so the project keeps one Yajra
 * DataTable architecture rather than a second, competing one. Search/sort/
 * pagination/filtering all run at the database level.
 */
class HealthAlertDataTable extends DataTable
{
    /**
     * Set only by Module 11's Complete History page (see
     * ReptileHistoryController) to scope this same DataTable to one
     * reptile's own records via an explicit route param, rather than the
     * `?reptile_id=` query-string convention query() already supports below
     * (the History page's URL carries the reptile as a route segment, not
     * a query string). The main Health Alerts index page never calls this.
     */
    protected ?Reptile $reptile = null;

    public function forReptile(Reptile $reptile): static
    {
        $this->reptile = $reptile;

        return $this;
    }

    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->addColumn('reptile_name', fn (HealthAlert $alert) => e($alert->reptile->name).' <small class="text-muted">'.e($alert->reptile->reptile_code).'</small>')
            ->addColumn('alert_type_label', fn (HealthAlert $alert) => e(HealthAlert::ALERT_TYPES[$alert->alert_type] ?? ucfirst($alert->alert_type)))
            ->editColumn('triggered_at', fn (HealthAlert $alert) => $alert->triggered_at->format('M d, Y g:i A'))
            ->addColumn('severity_badge', fn (HealthAlert $alert) => view('admin.health-alerts._severity_badge', ['severity' => $alert->severity])->render())
            ->addColumn('status_badge', fn (HealthAlert $alert) => view('admin.health-alerts._status_badge', ['status' => $alert->status])->render())
            ->addColumn('source_label', fn (HealthAlert $alert) => e(HealthAlert::SOURCES[$alert->source] ?? ucfirst($alert->source)))
            ->addColumn('actions', fn (HealthAlert $alert) => $this->actionButtons($alert))
            // Global search runs against the fields the module spec calls out
            // (reptile name/code, alert type, title, message) at the database
            // level — never by loading the full table into PHP. The `false`
            // here (the default) is required: it turns OFF Yajra's own
            // automatic global search so only this callback runs — Yajra's
            // own search can't see the computed columns above anyway.
            ->filter(function (QueryBuilder $query) {
                $search = $this->request()->input('search.value');

                if ($search) {
                    $query->where(function (QueryBuilder $query) use ($search) {
                        $query->where('alert_type', 'like', "%{$search}%")
                            ->orWhere('title', 'like', "%{$search}%")
                            ->orWhere('message', 'like', "%{$search}%")
                            ->orWhereHas('reptile', function ($query) use ($search) {
                                $query->where('name', 'like', "%{$search}%")
                                    ->orWhere('reptile_code', 'like', "%{$search}%");
                            });
                    });
                }
            })
            ->rawColumns(['reptile_name', 'severity_badge', 'status_badge', 'actions'])
            ->setRowId('id');
    }

    /**
     * Eager-loads exactly what the columns above need — no N+1 queries when
     * rendering a page of rows. Also applies this page's optional filters
     * (severity/status/alert_type/date range/reptile) at the database
     * level — never in Blade/PHP.
     */
    public function query(HealthAlert $model): QueryBuilder
    {
        $request = $this->request();

        return $model->newQuery()
            ->with(['reptile', 'resolvedBy'])
            ->when($this->reptile, fn ($query, $reptile) => $query->where('reptile_id', $reptile->id))
            ->when($request->integer('reptile_id'), fn ($query, $reptileId) => $query->where('reptile_id', $reptileId))
            ->when($request->filled('severity'), fn ($query) => $query->where('severity', $request->input('severity')))
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->input('status')))
            ->when($request->filled('alert_type'), fn ($query) => $query->where('alert_type', $request->input('alert_type')))
            ->when($request->filled('date_from'), fn ($query) => $query->whereDate('triggered_at', '>=', $request->input('date_from')))
            ->when($request->filled('date_to'), fn ($query) => $query->whereDate('triggered_at', '<=', $request->input('date_to')));
    }

    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->setTableId('health-alerts-table')
            ->columns($this->getColumns())
            ->minifiedAjax($this->reptile ? route('admin.reptiles.history.health-alerts-data', $this->reptile) : '')
            ->orderBy(5, 'desc')
            ->parameters([
                'language' => ['search' => '_INPUT_', 'searchPlaceholder' => 'Search reptile, alert type, title, message...'],
            ]);
    }

    public function getColumns(): array
    {
        return [
            Column::computed('reptile_name')->title('Reptile'),
            Column::computed('alert_type_label')->title('Alert Type'),
            Column::make('title')->title('Title'),
            Column::computed('severity_badge')->title('Severity'),
            Column::computed('status_badge')->title('Status'),
            Column::make('triggered_at')->title('Triggered At'),
            Column::computed('source_label')->title('Source'),
            Column::computed('actions')->title('Actions')->orderable(false)->searchable(false)->exportable(false)->printable(false),
        ];
    }

    /**
     * View for everyone (Admin/Staff); Resolve/Dismiss only for Admin.
     * Rendered through the shared <x-admin.action-menu> component so this
     * looks and behaves identically to every other module's Actions column.
     */
    protected function actionButtons(HealthAlert $alert): string
    {
        return view('admin.health-alerts._actions', ['alert' => $alert])->render();
    }

    protected function filename(): string
    {
        return 'HealthAlerts_'.date('YmdHis');
    }
}
