<?php

namespace App\DataTables;

use App\Models\Reptile;
use App\Models\SheddingRecord;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

/**
 * Server-side Shedding History for ONE reptile, for Module 11's Complete
 * History page. Modeled directly on the existing App\DataTables\
 * MedicalRecordDataTable / HealthAlertDataTable — same architecture.
 * "Problematic" here is only Module 8's existing record classification,
 * never reinterpreted as a medical diagnosis.
 */
class SheddingHistoryDataTable extends DataTable
{
    protected Reptile $reptile;

    public function forReptile(Reptile $reptile): static
    {
        $this->reptile = $reptile;

        return $this;
    }

    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->editColumn('shedding_date', fn (SheddingRecord $record) => $record->shedding_date->format('M d, Y'))
            ->addColumn('status_badge', fn (SheddingRecord $record) => view('admin.shedding-records._status_badge', ['status' => $record->status])->render())
            ->editColumn('notes', fn (SheddingRecord $record) => e($record->notes ?? '—'))
            ->editColumn('observations', fn (SheddingRecord $record) => e($record->observations ?? '—'))
            ->addColumn('created_by_name', fn (SheddingRecord $record) => e($record->createdBy->name ?? '—'))
            ->addColumn('actions', fn (SheddingRecord $record) => '<a href="'.route('admin.shedding-records.edit', $record).'" class="btn btn-sm btn-outline-primary"><i class="bx bx-show me-1"></i>View</a>')
            // Search is scoped to this reptile's own records only (see
            // query()) and, within that, to status/notes/observations.
            ->filter(function (QueryBuilder $query) {
                $search = $this->request()->input('search.value');

                if (! $search) {
                    return;
                }

                $query->where(function (QueryBuilder $query) use ($search) {
                    $query->where('status', 'like', "%{$search}%")
                        ->orWhere('notes', 'like', "%{$search}%")
                        ->orWhere('observations', 'like', "%{$search}%");
                });
            })
            ->rawColumns(['status_badge', 'actions'])
            ->setRowId('id');
    }

    /**
     * Always scoped to the one reptile passed via forReptile() — never all
     * shedding records — with eager loading so rendering a page of rows
     * never triggers N+1 queries.
     */
    public function query(SheddingRecord $model): QueryBuilder
    {
        return $model->newQuery()
            ->with('createdBy')
            ->where('reptile_id', $this->reptile->id);
    }

    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->setTableId('shedding-history-table')
            ->columns($this->getColumns())
            ->minifiedAjax(route('admin.reptiles.history.shedding-data', $this->reptile))
            ->orderBy(0, 'desc')
            ->parameters([
                'language' => ['search' => '_INPUT_', 'searchPlaceholder' => 'Search status, notes, observations...'],
            ]);
    }

    public function getColumns(): array
    {
        return [
            Column::make('shedding_date')->title('Shedding Date'),
            Column::computed('status_badge')->title('Status'),
            Column::make('notes')->title('Notes'),
            Column::make('observations')->title('Observations'),
            Column::computed('created_by_name')->title('Created By'),
            Column::computed('actions')->title('Actions')->orderable(false)->searchable(false)->exportable(false)->printable(false),
        ];
    }

    protected function filename(): string
    {
        return 'SheddingHistory_'.$this->reptile->reptile_code.'_'.date('YmdHis');
    }
}
