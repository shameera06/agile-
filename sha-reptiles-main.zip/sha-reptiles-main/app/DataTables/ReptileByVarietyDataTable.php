<?php

namespace App\DataTables;

use App\Models\Reptile;
use App\Models\SpeciesVariety;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

/**
 * Server-side listing of the individual reptiles registered under one
 * Species Variety/Morph — the bottom of the Species → Category → Type →
 * Variety hierarchy. Modeled directly on App\DataTables\MedicalRecordDataTable:
 * search/sort/pagination all run at the database level, and the query is
 * always scoped to a single variety (see forVariety()/query()) so one
 * variety's reptiles can never leak into another's listing.
 */
class ReptileByVarietyDataTable extends DataTable
{
    protected SpeciesVariety $variety;

    /**
     * Scope this DataTable to one variety. Must be called by the controller
     * (after validating the variety belongs to the requested species/category)
     * before html()/ajax() — see SpeciesController::variety().
     */
    public function forVariety(SpeciesVariety $variety): static
    {
        $this->variety = $variety;

        return $this;
    }

    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->editColumn('date_of_birth', fn (Reptile $reptile) => optional($reptile->date_of_birth)->format('M d, Y') ?? '—')
            ->addColumn('sex_label', fn (Reptile $reptile) => Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex))
            ->addColumn('current_weight_label', fn (Reptile $reptile) => $reptile->current_weight !== null
                ? e($reptile->current_weight.' '.$reptile->weight_unit)
                : '—')
            ->addColumn('status_badge', fn (Reptile $reptile) => view('admin.reptiles._status_badge', ['status' => $reptile->status])->render())
            ->addColumn('actions', fn (Reptile $reptile) => $this->actionButtons($reptile))
            // Global search is scoped to this variety's own reptiles only —
            // never other varieties — and runs at the database level.
            ->filter(function (QueryBuilder $query) {
                $search = $this->request()->input('search.value');

                if (! $search) {
                    return;
                }

                $query->where(function (QueryBuilder $query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('reptile_code', 'like', "%{$search}%");
                });
            })
            ->rawColumns(['status_badge', 'actions'])
            ->setRowId('id');
    }

    /**
     * Scoped strictly to the given variety, with eager loading so rendering
     * a page of rows never triggers N+1 queries.
     */
    public function query(Reptile $model): QueryBuilder
    {
        return $model->newQuery()
            ->with(['species.category', 'variety'])
            ->where('species_variety_id', $this->variety->id);
    }

    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->setTableId('reptiles-by-variety-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->orderBy(1, 'asc')
            ->parameters([
                'language' => ['search' => '_INPUT_', 'searchPlaceholder' => 'Search name or reptile ID...'],
            ]);
    }

    public function getColumns(): array
    {
        return [
            Column::make('name')->title('Animal Name'),
            Column::make('reptile_code')->title('Reptile ID'),
            Column::computed('current_weight_label')->title('Current Weight'),
            Column::computed('sex_label')->title('Sex'),
            Column::make('date_of_birth')->title('DOB / Hatch Date'),
            Column::computed('status_badge')->title('Status'),
            Column::computed('actions')->title('Actions')->orderable(false)->searchable(false)->exportable(false)->printable(false),
        ];
    }

    /**
     * View only, per the module spec — edit/delete stay on the existing
     * Reptile Management screens/permissions and aren't duplicated here.
     */
    protected function actionButtons(Reptile $reptile): string
    {
        return '<a href="'.route('admin.reptiles.show', $reptile).'" class="btn btn-sm btn-outline-primary"><i class="bx bx-show me-1"></i>View</a>';
    }

    protected function filename(): string
    {
        return 'Reptiles_'.$this->variety->name.'_'.date('YmdHis');
    }
}
