<?php

namespace App\DataTables;

use App\Models\FeedingRecord;
use App\Models\Reptile;
use App\Services\WeightMonitoringService;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Illuminate\Support\Collection;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

/**
 * Server-side Feeding & Weight History for ONE reptile, for Module 11's
 * Complete History page. Feeding and weight measurements are the same
 * underlying `feeding_records` rows in this application (Module 7 never
 * created a separate weight-only table) — this single DataTable covers
 * both the "Weight History" and "Feeding History" sections the module spec
 * describes, rather than querying the identical rows twice under two names.
 *
 * Modeled directly on the existing App\DataTables\MedicalRecordDataTable /
 * HealthAlertDataTable — same architecture, nothing new invented. Reuses
 * WeightMonitoringService for effective weight — never recalculates it.
 */
class FeedingHistoryDataTable extends DataTable
{
    protected Reptile $reptile;

    /** @var Collection<int, int> feeding_record ids to highlight red — see ReptileHistoryService */
    protected Collection $highlightedIds;

    public function __construct(protected WeightMonitoringService $weightMonitoring)
    {
        $this->highlightedIds = collect();
    }

    /**
     * Scope this DataTable to one reptile. Must be called by the controller
     * before html()/ajax() — mirrors ReptileByVarietyDataTable::forVariety().
     */
    public function forReptile(Reptile $reptile): static
    {
        $this->reptile = $reptile;

        return $this;
    }

    /**
     * The feeding_record ids that should render with a red row highlight —
     * computed once by ReptileHistoryService using the exact existing
     * Module 7 WeightMonitoringService::hasThreeConsecutivePoorGainRecords()
     * definition, never a second "poor gain" rule.
     *
     * @param  Collection<int, int>  $ids
     */
    public function highlightIds(Collection $ids): static
    {
        $this->highlightedIds = $ids;

        return $this;
    }

    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->editColumn('feeding_date', fn (FeedingRecord $record) => $record->feeding_date->format('M d, Y g:i A'))
            ->addColumn('food_type_label', function (FeedingRecord $record) {
                return $record->foodType->parent
                    ? e($record->foodType->parent->name).' &rarr; '.e($record->foodType->name)
                    : e($record->foodType->name);
            })
            ->addColumn('quantity_label', fn (FeedingRecord $record) => e(rtrim(rtrim($record->quantity, '0'), '.').' '.(\App\Models\FeedingSchedule::QUANTITY_UNITS[$record->quantity_unit] ?? $record->quantity_unit)))
            ->addColumn('effective_weight_label', fn (FeedingRecord $record) => $this->weightMonitoring->getEffectiveWeight($record).' g')
            ->editColumn('weight_change', function (FeedingRecord $record) {
                if ($record->weight_change === null) {
                    return '<span class="text-muted">—</span>';
                }

                $class = $record->weight_change > 0 ? 'text-success' : ($record->weight_change < 0 ? 'text-danger' : '');

                return '<span class="'.$class.'">'.($record->weight_change > 0 ? '+' : '').$record->weight_change.' g</span>';
            })
            ->addColumn('trend_badge', fn (FeedingRecord $record) => view('admin.feeding-records._trend_badge', ['trend' => $record->weight_trend])->render())
            ->addColumn('alert_badge', fn (FeedingRecord $record) => view('admin.feeding-records._alert_badge', [
                'alertTriggered' => $record->weight_alert_triggered,
                'alertMessage' => $record->weight_alert_message,
            ])->render())
            ->addColumn('actions', fn (FeedingRecord $record) => '<a href="'.route('admin.feeding-records.edit', $record).'" class="btn btn-sm btn-outline-primary"><i class="bx bx-show me-1"></i>View</a>')
            // Search is scoped to this reptile's own records only (see
            // query()) and, within that, to food type / notes per the module
            // spec — always at the database level.
            ->filter(function (QueryBuilder $query) {
                $search = $this->request()->input('search.value');

                if (! $search) {
                    return;
                }

                $query->where(function (QueryBuilder $query) use ($search) {
                    $query->where('notes', 'like', "%{$search}%")
                        ->orWhereHas('foodType', function ($query) use ($search) {
                            $query->where('name', 'like', "%{$search}%");
                        });
                });
            })
            // Red highlight for the exact latest-three-poor-gain records —
            // Module 7's own definition, computed once by
            // ReptileHistoryService and handed in via highlightIds().
            ->setRowClass(fn (FeedingRecord $record) => $this->highlightedIds->contains($record->id) ? 'table-danger' : '')
            ->rawColumns(['food_type_label', 'weight_change', 'trend_badge', 'alert_badge', 'actions'])
            ->setRowId('id');
    }

    /**
     * Always scoped to the one reptile passed via forReptile() — never all
     * feeding records — with eager loading so rendering a page of rows
     * never triggers N+1 queries.
     */
    public function query(FeedingRecord $model): QueryBuilder
    {
        return $model->newQuery()
            ->with('foodType.parent')
            ->where('reptile_id', $this->reptile->id);
    }

    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->setTableId('feeding-history-table')
            ->columns($this->getColumns())
            ->minifiedAjax(route('admin.reptiles.history.feeding-data', $this->reptile))
            ->orderBy(0, 'desc')
            ->parameters([
                'language' => ['search' => '_INPUT_', 'searchPlaceholder' => 'Search food type or notes...'],
            ]);
    }

    public function getColumns(): array
    {
        return [
            Column::make('feeding_date')->title('Feeding Date'),
            Column::computed('food_type_label')->title('Food Type'),
            Column::computed('quantity_label')->title('Quantity')->orderable(false),
            Column::make('weight_before')->title('Before'),
            Column::make('weight_after')->title('After'),
            Column::make('weight_after_defecation')->title('After Defecation'),
            Column::computed('effective_weight_label')->title('Effective Weight')->orderable(false),
            Column::make('weight_change')->title('Weight Change'),
            Column::computed('trend_badge')->title('Trend')->orderable(false),
            Column::computed('alert_badge')->title('Weight Alert')->orderable(false),
            Column::computed('actions')->title('Actions')->orderable(false)->searchable(false)->exportable(false)->printable(false),
        ];
    }

    protected function filename(): string
    {
        return 'FeedingWeightHistory_'.$this->reptile->reptile_code.'_'.date('YmdHis');
    }
}
