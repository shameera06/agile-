<?php

namespace App\DataTables;

use App\Models\MedicalRecord;
use App\Models\Reptile;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Illuminate\Support\Str;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

/**
 * Server-side listing for Medical Records. Search/sort/pagination all run
 * at the database level (see dataTable()'s filter() override and query()'s
 * eager loading) — the browser never receives more than one page of rows.
 */
class MedicalRecordDataTable extends DataTable
{
    /**
     * Set only by Module 11's Complete History page (see
     * ReptileHistoryController) to scope this same DataTable to one
     * reptile's own records — the main Medical Records index page never
     * calls this, so its existing (unscoped) behavior is unchanged.
     */
    protected ?Reptile $reptile = null;

    public function forReptile(Reptile $reptile): static
    {
        $this->reptile = $reptile;

        return $this;
    }

    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->addColumn('reptile_name', fn (MedicalRecord $record) => e($record->reptile->name).' <small class="text-muted">'.e($record->reptile->reptile_code).'</small>')
            ->editColumn('treatment_date', fn (MedicalRecord $record) => $record->treatment_date->format('M d, Y'))
            ->editColumn('symptoms_or_condition', fn (MedicalRecord $record) => e(Str::limit($record->symptoms_or_condition, 60)))
            ->editColumn('medicine_name', fn (MedicalRecord $record) => e($record->medicine_name ?? '—'))
            ->editColumn('dosage', fn (MedicalRecord $record) => e($record->dosage ?? '—'))
            ->editColumn('veterinarian_name', fn (MedicalRecord $record) => e($record->veterinarian_name ?? '—'))
            ->addColumn('prescription', fn (MedicalRecord $record) => $this->prescriptionCell($record))
            ->addColumn('created_by_name', fn (MedicalRecord $record) => e($record->createdBy->name ?? '—'))
            ->addColumn('actions', fn (MedicalRecord $record) => $this->actionButtons($record))
            // Global search runs against the fields the module spec calls out
            // (reptile name/code, symptoms, medicine, veterinarian) at the
            // database level — never by loading the full table into PHP.
            // The `false` here (the default) is required: it turns OFF
            // Yajra's own automatic global search so only this callback
            // runs — passing `true` would run both, and Yajra's own search
            // can't see the "reptile_name" computed column at all.
            ->filter(function (QueryBuilder $query) {
                $search = $this->request()->input('search.value');

                if (! $search) {
                    return;
                }

                $query->where(function (QueryBuilder $query) use ($search) {
                    $query->where('symptoms_or_condition', 'like', "%{$search}%")
                        ->orWhere('medicine_name', 'like', "%{$search}%")
                        ->orWhere('veterinarian_name', 'like', "%{$search}%")
                        ->orWhereHas('reptile', function ($query) use ($search) {
                            $query->where('name', 'like', "%{$search}%")
                                ->orWhere('reptile_code', 'like', "%{$search}%");
                        });
                });
            })
            ->rawColumns(['reptile_name', 'prescription', 'actions'])
            ->setRowId('id');
    }

    /**
     * Eager-loads exactly what the columns above need — no N+1 queries when
     * rendering a page of rows.
     */
    public function query(MedicalRecord $model): QueryBuilder
    {
        return $model->newQuery()
            ->with(['reptile', 'createdBy'])
            ->when($this->reptile, fn ($query, $reptile) => $query->where('reptile_id', $reptile->id));
    }

    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->setTableId('medical-records-table')
            ->columns($this->getColumns())
            ->minifiedAjax($this->reptile ? route('admin.reptiles.history.medical-data', $this->reptile) : '')
            ->orderBy(1, 'desc')
            ->parameters([
                'language' => ['search' => '_INPUT_', 'searchPlaceholder' => 'Search reptile, symptoms, medicine, vet...'],
            ]);
    }

    public function getColumns(): array
    {
        return [
            Column::computed('reptile_name')->title('Reptile'),
            Column::make('treatment_date')->title('Treatment Date'),
            Column::make('symptoms_or_condition')->title('Symptoms / Condition'),
            Column::make('medicine_name')->title('Medicine'),
            Column::make('dosage')->title('Dosage'),
            Column::make('veterinarian_name')->title('Veterinarian'),
            Column::computed('prescription')->title('Prescription')->orderable(false)->exportable(false)->printable(false),
            Column::computed('created_by_name')->title('Created By'),
            Column::computed('actions')->title('Actions')->orderable(false)->searchable(false)->exportable(false)->printable(false),
        ];
    }

    protected function prescriptionCell(MedicalRecord $record): string
    {
        if (! $record->hasPrescription()) {
            return '<span class="text-muted">—</span>';
        }

        $url = route('admin.medical-records.prescription', $record);

        return '<a href="'.$url.'" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bx bx-file me-1"></i>View</a>';
    }

    /**
     * View/Edit for everyone; Delete only for Admin (Staff never sees it).
     * Rendered through the shared <x-admin.action-menu> component so the
     * DataTable's Actions column looks and behaves identically to every
     * other module's plain-Blade listing.
     */
    protected function actionButtons(MedicalRecord $record): string
    {
        return view('admin.medical-records._actions', ['record' => $record])->render();
    }

    protected function filename(): string
    {
        return 'MedicalRecords_'.date('YmdHis');
    }
}
