# AI Reptile Assistant

## What it does

The AI Reptile Assistant helps you quickly understand a reptile's own recorded history — feeding, weight, shedding, medical records, and health alerts — by answering plain-language questions about it. It only reads existing records already stored in the system; it does not change any data.

## How to open it

1. Go to the reptile's **Reptile Details** page.
2. Click the **AI Assistant** button in the action bar (next to Weight History, Add Shedding Record, etc.).
3. Type a question, or click one of the suggested questions, and press **Ask AI**.

## Example questions

- Give me a summary of this reptile.
- How has the weight changed recently?
- Summarize the feeding history.
- Summarize the shedding history.
- Summarize the medical history.
- Are there any recent health alerts?
- Prepare a short summary I can share with a veterinarian.

## Important things to know

- **It only summarizes existing records.** It does not invent dates, measurements, or events that aren't already in the system.
- **It is not a veterinary diagnosis.** It can describe recorded symptoms, treatments, and alerts, but it will not diagnose a condition or recommend medication or dosage changes. Always consult a qualified veterinarian for medical decisions.
- **It only discusses the reptile you opened it from.** It cannot show or use information about any other reptile, even if asked to.
- **It does not modify records.** Weight calculations, health alerts, feeding schedules, and all other data continue to work exactly as before — the assistant only explains what's already there.
