# AI Reptile Assistant — Technical Setup

Technical reference for developers/ops deploying or maintaining the AI Reptile Assistant feature. For the client-facing explanation, see `docs/AI_ASSISTANT_USER_GUIDE.md`.

## 1. What this feature is

A read-only assistant on each reptile's profile page that answers questions about that one reptile using only its own stored records (feeding, shedding, medical, health alerts). It calls the Google Gemini API from the Laravel backend. It never writes to the database and never calls Gemini except when a user explicitly submits a question.

Key files:
- `app/Services/GeminiService.php` — HTTP client for the Gemini REST API (domain-agnostic).
- `app/Services/AiReptileAssistantService.php` — builds the reptile-scoped context and prompt, calls `GeminiService`.
- `app/Http/Controllers/Admin/ReptileAiAssistantController.php` — thin controller (`show`, `ask`).
- `resources/views/admin/reptiles/ai-assistant.blade.php` — the page.
- Routes: `admin.reptiles.ai-assistant` (GET), `admin.reptiles.ai-assistant.ask` (POST, rate-limited).

## 2. Gemini API setup

1. Go to [Google AI Studio](https://aistudio.google.com/) (or Google Cloud Console if using a GCP-billed project) and create an API key for the Gemini API.
2. Note the model name you want to use (e.g. `gemini-2.5-flash`). Check Google's current model list — model names and availability change over time, so confirm the current recommended model in Google's Gemini API documentation before deploying.
3. The free tier has request-per-minute and request-per-day quotas. This feature only calls Gemini when a user submits a question, so normal usage should stay well within free-tier limits for a small team.

## 3. Required environment variables

Add to `.env` (never commit real values):

```
GEMINI_API_KEY=your-real-api-key
GEMINI_MODEL=gemini-2.5-flash
GEMINI_TIMEOUT=30
```

These are read via `config('services.gemini.*')` in `config/services.php`. Never hardcode the key or model anywhere else.

## 4. cPanel deployment steps

1. Deploy the updated code (via git pull, zip upload, or your existing deployment process) as usual.
2. In cPanel, open the app's `.env` file (via File Manager or terminal/SSH if available) and add the three `GEMINI_*` variables above with the real API key.
3. If the application caches configuration in production (`php artisan config:cache`), clear and rebuild it after changing `.env`:
   ```
   php artisan config:clear
   php artisan config:cache
   ```
   If config caching isn't used in this environment, `config:clear` alone is enough.
4. Do not run destructive commands (`migrate:fresh`, `db:wipe`, etc.) — this feature requires no database migrations.
5. Confirm `.env` is not web-accessible and is excluded via `.gitignore` (it already is in this project).

## 5. How to test the integration

- Automated: `php artisan test --filter=ReptileAiAssistantTest` — all Gemini calls are mocked via `Http::fake()`, so this requires no real API key or network access.
- Manual: log in, open any reptile's profile, click **AI Assistant**, ask a question (or click a suggested question), confirm a response appears within a few seconds.
- Confirm the button/page/route names are unchanged (`admin.reptiles.ai-assistant*`) so no other part of the app breaks.

## 6. Troubleshooting API errors

All Gemini calls and failures are logged via `Log::error(...)` with the prefix `AI Reptile Assistant:` — check `storage/logs/laravel.log`. The user-facing message and the likely cause:

| User sees | Likely cause | Where to look |
|---|---|---|
| "AI Assistant is not currently configured." | `GEMINI_API_KEY` or `GEMINI_MODEL` missing, or Gemini rejected the key (401/403) | `.env`, API key validity in AI Studio |
| "AI Assistant is currently unavailable. Please try again later." | Network failure, 5xx from Gemini, invalid model name (404), empty/blocked response | Log message + status code |
| "The AI Assistant took too long to respond. Please try again." | Request exceeded `GEMINI_TIMEOUT` seconds | Consider raising `GEMINI_TIMEOUT` if this is frequent |
| "The AI Assistant has temporarily reached its usage limit. Please try again later." | Gemini returned HTTP 429 (quota/rate limit) | Check quota usage in Google AI Studio / Cloud Console |

Never expose API keys, request headers, or raw exceptions to the browser — the controller only ever returns the mapped friendly message.

## 7. Rate-limit behavior

- **Gemini-side**: handled gracefully (see table above); the app does not automatically retry.
- **App-side**: the `ask` endpoint is throttled server-side via a dedicated named limiter (`gemini-assistant`, defined in `app/Providers/RouteServiceProvider.php`), currently 10 requests/minute per authenticated user, independent of the general `api` limiter. Adjust the `Limit::perMinute(10)` value there if usage patterns require it.

## 8. Security considerations

- The API key lives only in `.env` / `config/services.php`; it is never sent to the browser, never logged, and never appears in Blade or JavaScript.
- The Gemini request is authenticated via the `x-goog-api-key` HTTP header (not a URL query string), so it won't leak into request-URL logs.
- Every request is scoped server-side to the route-bound `{reptile}` — the question text can never change which reptile's data is loaded (see `AiReptileAssistantService::buildContext()`), and the system prompt explicitly instructs the model to treat all record data and the user's question as data, not instructions.
- No prescription file contents (images/PDFs) are ever sent to Gemini — only structured text fields already stored on the medical record.
- No chat history is persisted; each request is stateless and rebuilt from the database every time.

## 9. How to change the Gemini model

Update `GEMINI_MODEL` in `.env` (e.g. to a newer or higher-capacity model Google has since released) and clear the config cache (`php artisan config:clear`, then `config:cache` if used). No code changes are required — `GeminiService` always reads the model name from config.
