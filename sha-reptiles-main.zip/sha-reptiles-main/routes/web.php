<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\FeedingRecordController;
use App\Http\Controllers\Admin\FeedingScheduleController;
use App\Http\Controllers\Admin\FoodTypeController;
use App\Http\Controllers\Admin\ForgotPasswordController;
use App\Http\Controllers\Admin\HealthAlertController;
use App\Http\Controllers\Admin\MedicalRecordController;
use App\Http\Controllers\Admin\ReptileAiAssistantController;
use App\Http\Controllers\Admin\ReptileController;
use App\Http\Controllers\Admin\ReptileHistoryController;
use App\Http\Controllers\Admin\ResetPasswordController;
use App\Http\Controllers\Admin\SheddingRecordController;
use App\Http\Controllers\Admin\SpeciesCategoryController;
use App\Http\Controllers\Admin\SpeciesController;
use App\Http\Controllers\Admin\SpeciesVarietyController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::redirect('/', '/admin/dashboard');

Route::prefix('admin')->name('admin.')->group(function () {

    // Guest routes
    Route::middleware('guest')->group(function () {
        Route::get('login', [AuthController::class, 'showLogin'])->name('login');
        Route::post('login', [AuthController::class, 'login'])->name('login.submit');

        Route::get('forgot-password', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
        Route::post('forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');

        Route::get('reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
        Route::post('reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');
    });

    // Authenticated routes
    Route::middleware('auth')->group(function () {
        Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
        Route::post('logout', [AuthController::class, 'logout'])->name('logout');

        Route::resource('species', SpeciesController::class)->except(['show']);

        // Species → Category → Type → Variety browse hierarchy. Additive and
        // separate from the flat CRUD list above (admin.species.index), which
        // is untouched. See SpeciesController's "browse hierarchy" section.
        Route::get('species/browse', [SpeciesController::class, 'browse'])->name('species.browse');
        Route::get('species/browse/{category}', [SpeciesController::class, 'category'])->name('species.category');
        Route::get('species/browse/type/{species}', [SpeciesController::class, 'type'])->name('species.type');
        Route::get('species/browse/type/{species}/{variety}', [SpeciesController::class, 'variety'])->name('species.variety');

        Route::resource('species-categories', SpeciesCategoryController::class)->except(['index', 'show']);
        Route::resource('species-varieties', SpeciesVarietyController::class)->except(['index', 'show']);

        Route::resource('reptiles', ReptileController::class)->except(['destroy']);
        Route::patch('reptiles/{reptile}/archive', [ReptileController::class, 'archive'])->name('reptiles.archive');

        // Weight History: a dedicated, read-only page for one reptile's own
        // weight/feeding records. Reuses the existing feeding_records data,
        // WeightMonitoringService's effective-weight/trend rules, and the
        // same FeedingHistoryDataTable + ajax endpoint Module 11's Complete
        // History page already uses — no new table, no new ajax route.
        Route::get('reptiles/{reptile}/weight-history', [ReptileController::class, 'weightHistory'])->name('reptiles.weight-history');

        // Module 11: Complete (read-only) History for one individual reptile.
        // Four small ajax endpoints (one per embedded Yajra DataTable) so each
        // table on the page gets its own distinct ajax URL — see
        // ReptileHistoryController and resources/views/admin/reptiles/history.blade.php.
        Route::get('reptiles/{reptile}/history', [ReptileHistoryController::class, 'index'])->name('reptiles.history');
        Route::get('reptiles/{reptile}/history/feeding-data', [ReptileHistoryController::class, 'feedingData'])->name('reptiles.history.feeding-data');
        Route::get('reptiles/{reptile}/history/shedding-data', [ReptileHistoryController::class, 'sheddingData'])->name('reptiles.history.shedding-data');
        Route::get('reptiles/{reptile}/history/medical-data', [ReptileHistoryController::class, 'medicalData'])->name('reptiles.history.medical-data');
        Route::get('reptiles/{reptile}/history/health-alerts-data', [ReptileHistoryController::class, 'healthAlertsData'])->name('reptiles.history.health-alerts-data');

        // Module 12: server-generated, downloadable PDF of the same Complete
        // History above — read-only, scoped to this one {reptile} only.
        Route::get('reptiles/{reptile}/history/pdf', [ReptileHistoryController::class, 'pdf'])->name('reptiles.history.pdf');

        // AI Reptile Assistant: a dedicated, read-only page that explains one
        // reptile's own existing records via the Google Gemini API. Never
        // writes to the database — see AiReptileAssistantService. The
        // reptile's identity comes only from this route's {reptile} binding.
        Route::get('reptiles/{reptile}/ai-assistant', [ReptileAiAssistantController::class, 'show'])->name('reptiles.ai-assistant');
        Route::post('reptiles/{reptile}/ai-assistant/ask', [ReptileAiAssistantController::class, 'ask'])
            ->middleware('throttle:gemini-assistant')
            ->name('reptiles.ai-assistant.ask');

        Route::resource('food-types', FoodTypeController::class)->except(['show']);

        Route::resource('feeding-schedules', FeedingScheduleController::class)->except(['show', 'destroy']);

        // Adjust Next Feeding: a temporary override of one schedule's next
        // occurrence (e.g. digestion delay) that never touches interval_days.
        // Scoped to the single {feeding_schedule} in the URL — see
        // FeedingScheduleController::storeAdjustment — so it can never be used
        // to move another schedule's next feeding date.
        Route::get('feeding-schedules/{feeding_schedule}/adjust-next-feeding', [FeedingScheduleController::class, 'adjustNextFeeding'])
            ->name('feeding-schedules.adjust-next-feeding');
        Route::post('feeding-schedules/{feeding_schedule}/adjust-next-feeding', [FeedingScheduleController::class, 'storeAdjustment'])
            ->name('feeding-schedules.adjust-next-feeding.store');

        Route::resource('feeding-records', FeedingRecordController::class)->except(['show', 'destroy']);

        Route::resource('shedding-records', SheddingRecordController::class)->except(['show', 'destroy']);

        // Medical Records: everyone authenticated can view/create/edit; only
        // Admin (see the `admin` middleware) can delete.
        Route::resource('medical-records', MedicalRecordController::class)->except(['destroy']);
        Route::delete('medical-records/{medical_record}', [MedicalRecordController::class, 'destroy'])
            ->name('medical-records.destroy')
            ->middleware('admin');
        Route::get('medical-records/{medical_record}/prescription', [MedicalRecordController::class, 'prescription'])
            ->name('medical-records.prescription');

        // Health Alerts (a.k.a. Weight Concerns): everyone authenticated can
        // view and document action taken (update/evidence); only Admin (see
        // the `admin` middleware) can resolve/dismiss — alerts are never
        // deleted.
        Route::resource('health-alerts', HealthAlertController::class)->only(['index', 'show']);
        Route::patch('health-alerts/{health_alert}', [HealthAlertController::class, 'update'])
            ->name('health-alerts.update');
        Route::get('health-alerts/{health_alert}/evidence', [HealthAlertController::class, 'evidence'])
            ->name('health-alerts.evidence');
        Route::patch('health-alerts/{health_alert}/resolve', [HealthAlertController::class, 'resolve'])
            ->name('health-alerts.resolve')
            ->middleware('admin');
        Route::patch('health-alerts/{health_alert}/dismiss', [HealthAlertController::class, 'dismiss'])
            ->name('health-alerts.dismiss')
            ->middleware('admin');
    });
});
