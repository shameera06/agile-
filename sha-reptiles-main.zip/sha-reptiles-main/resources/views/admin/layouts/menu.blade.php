<ul class="menu-inner py-1">
    <li class="menu-header small text-uppercase">
      <span class="menu-header-text">Main</span>
    </li>

    <!-- Dashboard -->
    <li class="menu-item {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
      <a href="{{ route('admin.dashboard') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-home-circle"></i>
        <div data-i18n="Dashboard">Dashboard</div>
      </a>
    </li>

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text">Reptile Management</span>
    </li>

    <!-- Species: enters the Category → Type → Variety browse hierarchy;
         the flat Species catalog (admin.species.index) is reached from
         a button on that page, not directly from this link. -->
    <li class="menu-item {{ request()->routeIs('admin.species.*', 'admin.species-categories.*', 'admin.species-varieties.*') ? 'active' : '' }}">
      <a href="{{ route('admin.species.browse') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-spa"></i>
        <div data-i18n="Species">Species</div>
      </a>
    </li>

    <!-- Reptiles -->
    <li class="menu-item {{ request()->routeIs('admin.reptiles.*') ? 'active' : '' }}">
      <a href="{{ route('admin.reptiles.index') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-id-card"></i>
        <div data-i18n="Reptiles">Reptiles</div>
      </a>
    </li>

    <!-- Food Types -->
    <li class="menu-item {{ request()->routeIs('admin.food-types.*') ? 'active' : '' }}">
      <a href="{{ route('admin.food-types.index') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-food-menu"></i>
        <div data-i18n="Food Types">Food Types</div>
      </a>
    </li>

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text">Care Management</span>
    </li>

    <!-- Feeding Records. Feeding Schedules is intentionally not linked here —
         the client's normal workflow adds Feeding Records directly from a
         reptile's profile; the schedules module (routes/controllers/data)
         remains intact and reachable by URL, just hidden from this nav. -->
    <li class="menu-item {{ request()->routeIs('admin.feeding-records.*') ? 'active' : '' }}">
      <a href="{{ route('admin.feeding-records.index') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-restaurant"></i>
        <div data-i18n="Feeding Records">Feeding Records</div>
      </a>
    </li>

    <!-- Shedding Records -->
    <li class="menu-item {{ request()->routeIs('admin.shedding-records.*') ? 'active' : '' }}">
      <a href="{{ route('admin.shedding-records.index') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-refresh"></i>
        <div data-i18n="Shedding Records">Shedding Records</div>
      </a>
    </li>

    <!-- Medical Records -->
    <li class="menu-item {{ request()->routeIs('admin.medical-records.*') ? 'active' : '' }}">
      <a href="{{ route('admin.medical-records.index') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-plus-medical"></i>
        <div data-i18n="Medical Records">Medical Records</div>
      </a>
    </li>

    <!-- Health Alerts -->
    <li class="menu-item {{ request()->routeIs('admin.health-alerts.*') ? 'active' : '' }}">
      <a href="{{ route('admin.health-alerts.index') }}" class="menu-link">
        <i class="menu-icon tf-icons bx bx-error-circle"></i>
        <div data-i18n="Health Alerts">Health Alerts</div>
      </a>
    </li>
  </ul>
