@extends('admin.layouts.master')

@section('title', 'Add Feeding Schedule')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.feeding-schedules.index') }}">Feeding Schedules</a></li>
            <li class="breadcrumb-item active">Add Feeding Schedule</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Add Feeding Schedule</h4>

    <div class="card">
        <div class="card-body">
            @include('admin.feeding-schedules._form')
        </div>
    </div>
</div>
@endsection
