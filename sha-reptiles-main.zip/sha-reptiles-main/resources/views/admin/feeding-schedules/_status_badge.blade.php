@php
    $statusBadgeClasses = [
        'active' => 'bg-label-success',
        'inactive' => 'bg-label-secondary',
        'completed' => 'bg-label-dark',
    ];
@endphp
<span class="badge {{ $statusBadgeClasses[$status] ?? 'bg-label-secondary' }}">
    {{ \App\Models\FeedingSchedule::STATUSES[$status] ?? ucfirst($status) }}
</span>
