@extends('admin.layouts.master')

@section('title', 'Edit Feeding Schedule')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.feeding-schedules.index') }}">Feeding Schedules</a></li>
            <li class="breadcrumb-item active">Edit Feeding Schedule</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Edit Feeding Schedule</h4>

    @if ($latestAdjustment)
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="fw-semibold mb-0">Schedule Adjustment</h6>
                <a href="{{ route('admin.feeding-schedules.adjust-next-feeding', $feedingSchedule) }}" class="btn btn-sm btn-outline-primary">View Adjustment History</a>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3 mb-md-0">
                        <label class="form-label">Original Next Feeding</label>
                        <p class="mb-0">{{ $latestAdjustment->original_next_due_at->format('d M Y, g:i A') }}</p>
                    </div>
                    <div class="col-md-3 mb-3 mb-md-0">
                        <label class="form-label">Adjusted Next Feeding</label>
                        <p class="mb-0">{{ $latestAdjustment->adjusted_next_due_at->format('d M Y, g:i A') }}</p>
                    </div>
                    <div class="col-md-3 mb-3 mb-md-0">
                        <label class="form-label">Reason</label>
                        <p class="mb-0">{{ \App\Models\FeedingScheduleAdjustment::REASONS[$latestAdjustment->reason] ?? $latestAdjustment->reason }}</p>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Adjusted By</label>
                        <p class="mb-0">{{ $latestAdjustment->adjustedBy->name ?? '—' }} <small class="text-muted d-block">{{ $latestAdjustment->adjusted_at->format('d M Y, g:i A') }}</small></p>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            @include('admin.feeding-schedules._form')
        </div>
    </div>
</div>
@endsection
