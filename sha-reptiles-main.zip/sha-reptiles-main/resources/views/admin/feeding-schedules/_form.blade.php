@php
    $isEdit = $feedingSchedule->exists;
    $action = $isEdit ? route('admin.feeding-schedules.update', $feedingSchedule) : route('admin.feeding-schedules.store');
@endphp

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="reptile_id" class="form-label">Reptile *</label>
            <select id="reptile_id" name="reptile_id" class="form-select @error('reptile_id') is-invalid @enderror">
                <option value="">Select a reptile</option>
                @foreach ($reptileOptions as $option)
                    <option value="{{ $option->id }}" @selected((int) old('reptile_id', $feedingSchedule->reptile_id) === $option->id)>
                        {{ $option->name }} — {{ $option->reptile_code }} — {{ $option->species->name }}
                        {{ $option->status !== 'active' ? ' (' . \App\Models\Reptile::STATUSES[$option->status] . ')' : '' }}
                    </option>
                @endforeach
            </select>
            @error('reptile_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="food_type_id" class="form-label">Food Type *</label>
            <select id="food_type_id" name="food_type_id" class="form-select @error('food_type_id') is-invalid @enderror">
                <option value="">Select a food type</option>
                @foreach ($foodTypeOptions as $option)
                    <option
                        value="{{ $option->id }}"
                        data-default-unit="{{ $option->default_unit }}"
                        @selected((int) old('food_type_id', $feedingSchedule->food_type_id) === $option->id)
                    >
                        {{ $option->parent ? $option->parent->name . ' → ' . $option->name : $option->name }}
                        {{ ! $option->status ? ' (inactive)' : '' }}
                    </option>
                @endforeach
            </select>
            @error('food_type_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-3 mb-3">
            <label for="quantity" class="form-label">Quantity *</label>
            <input
                type="number"
                step="0.01"
                min="0.01"
                id="quantity"
                name="quantity"
                class="form-control @error('quantity') is-invalid @enderror"
                value="{{ old('quantity', $feedingSchedule->quantity) }}"
            />
            @error('quantity')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="quantity_unit" class="form-label">Quantity Unit *</label>
            <select id="quantity_unit" name="quantity_unit" class="form-select @error('quantity_unit') is-invalid @enderror">
                @foreach (\App\Models\FeedingSchedule::QUANTITY_UNITS as $value => $label)
                    <option value="{{ $value }}" @selected(old('quantity_unit', $feedingSchedule->quantity_unit) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('quantity_unit')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="interval_days" class="form-label">Feeding Interval (days) *</label>
            <input
                type="number"
                step="1"
                min="1"
                id="interval_days"
                name="interval_days"
                class="form-control @error('interval_days') is-invalid @enderror"
                value="{{ old('interval_days', $feedingSchedule->interval_days) }}"
            />
            @error('interval_days')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="status" class="form-label">Status *</label>
            <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
                @foreach (\App\Models\FeedingSchedule::STATUSES as $value => $label)
                    <option value="{{ $value }}" @selected(old('status', $feedingSchedule->status) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('status')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-3 mb-3">
            <label for="first_due_date" class="form-label">First Feeding Date *</label>
            <input
                type="date"
                id="first_due_date"
                name="first_due_date"
                class="form-control @error('first_due_date') is-invalid @enderror"
                value="{{ old('first_due_date', optional($feedingSchedule->first_due_at)->format('Y-m-d')) }}"
            />
            @error('first_due_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="first_due_time" class="form-label">First Feeding Time *</label>
            <input
                type="time"
                id="first_due_time"
                name="first_due_time"
                class="form-control @error('first_due_time') is-invalid @enderror"
                value="{{ old('first_due_time', optional($feedingSchedule->first_due_at)->format('H:i')) }}"
            />
            @error('first_due_time')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="start_date" class="form-label">Start Date *</label>
            <input
                type="date"
                id="start_date"
                name="start_date"
                class="form-control @error('start_date') is-invalid @enderror"
                value="{{ old('start_date', optional($feedingSchedule->start_date)->format('Y-m-d')) }}"
            />
            @error('start_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="end_date" class="form-label">End Date</label>
            <input
                type="date"
                id="end_date"
                name="end_date"
                class="form-control @error('end_date') is-invalid @enderror"
                value="{{ old('end_date', optional($feedingSchedule->end_date)->format('Y-m-d')) }}"
            />
            <small class="text-muted d-block mt-1">Leave blank for an indefinite schedule.</small>
            @error('end_date')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-4">
        <label for="notes" class="form-label">Notes</label>
        <textarea
            id="notes"
            name="notes"
            rows="3"
            class="form-control @error('notes') is-invalid @enderror"
            placeholder="e.g. Feed in the evening after handling."
        >{{ old('notes', $feedingSchedule->notes) }}</textarea>
        @error('notes')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Feeding Schedule</button>
    <a href="{{ route('admin.feeding-schedules.index') }}" class="btn btn-outline-secondary">Cancel</a>
</form>

@push('page-scripts')
<script>
    (function () {
        // Fill the Quantity Unit field from the selected food type's default unit.
        // Vanilla JS only — the backend still validates whatever unit is submitted.
        var foodSelect = document.getElementById('food_type_id');
        var unitSelect = document.getElementById('quantity_unit');

        if (!foodSelect || !unitSelect) {
            return;
        }

        foodSelect.addEventListener('change', function () {
            var option = foodSelect.options[foodSelect.selectedIndex];
            var defaultUnit = option ? option.getAttribute('data-default-unit') : '';

            if (defaultUnit && unitSelect.querySelector('option[value="' + defaultUnit + '"]')) {
                unitSelect.value = defaultUnit;
            }
        });
    })();
</script>
@endpush
