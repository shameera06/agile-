@extends('admin.layouts.master')

@section('title', 'Adjust Next Feeding')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.feeding-schedules.index') }}">Feeding Schedules</a></li>
            <li class="breadcrumb-item active">Adjust Next Feeding</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Adjust Next Feeding</h4>

    <div class="card mb-4">
        <div class="card-body">
            <h6 class="fw-semibold mb-3">Current Schedule</h6>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label class="form-label">Reptile</label>
                    <p class="mb-0">{{ $feedingSchedule->reptile->name }} <small class="text-muted">({{ $feedingSchedule->reptile->reptile_code }})</small></p>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Food</label>
                    <p class="mb-0">
                        {{ $feedingSchedule->foodType->parent ? $feedingSchedule->foodType->parent->name . ' → ' . $feedingSchedule->foodType->name : $feedingSchedule->foodType->name }}
                    </p>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Feeding Interval</label>
                    <p class="mb-0">Every {{ $feedingSchedule->interval_days }} {{ Str::plural('day', $feedingSchedule->interval_days) }}</p>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Current Next Feeding</label>
                    <p class="mb-0">{{ $feedingSchedule->next_due_at->format('d M Y, g:i A') }}</p>
                </div>
            </div>
            <small class="text-muted">
                Adjusting the next feeding only changes this upcoming occurrence — the {{ $feedingSchedule->interval_days }}-{{ Str::plural('day', $feedingSchedule->interval_days) }} interval itself is not changed.
            </small>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h6 class="fw-semibold mb-3">Save Adjustment</h6>
            <form method="POST" action="{{ route('admin.feeding-schedules.adjust-next-feeding.store', $feedingSchedule) }}">
                @csrf

                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label for="adjusted_next_due_date" class="form-label">New Next Feeding Date *</label>
                        <input
                            type="date"
                            id="adjusted_next_due_date"
                            name="adjusted_next_due_date"
                            class="form-control @error('adjusted_next_due_date') is-invalid @enderror"
                            value="{{ old('adjusted_next_due_date', $feedingSchedule->next_due_at->format('Y-m-d')) }}"
                        />
                        @error('adjusted_next_due_date')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-3 mb-3">
                        <label for="adjusted_next_due_time" class="form-label">New Next Feeding Time *</label>
                        <input
                            type="time"
                            id="adjusted_next_due_time"
                            name="adjusted_next_due_time"
                            class="form-control @error('adjusted_next_due_time') is-invalid @enderror"
                            value="{{ old('adjusted_next_due_time', $feedingSchedule->next_due_at->format('H:i')) }}"
                        />
                        @error('adjusted_next_due_time')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-3 mb-3">
                        <label for="reason" class="form-label">Reason *</label>
                        <select id="reason" name="reason" class="form-select @error('reason') is-invalid @enderror">
                            <option value="">Select a reason</option>
                            @foreach (\App\Models\FeedingScheduleAdjustment::REASONS as $value => $label)
                                <option value="{{ $value }}" @selected(old('reason') === $value)>{{ $label }}</option>
                            @endforeach
                        </select>
                        @error('reason')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="mb-4">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea
                        id="notes"
                        name="notes"
                        rows="3"
                        class="form-control @error('notes') is-invalid @enderror"
                        placeholder="e.g. Additional digestion time required."
                    >{{ old('notes') }}</textarea>
                    @error('notes')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <button type="submit" class="btn btn-primary">Save Adjustment</button>
                <a href="{{ route('admin.feeding-schedules.index') }}" class="btn btn-outline-secondary">Cancel</a>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h6 class="fw-semibold mb-0">Adjustment History</h6>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Original Next Feeding</th>
                        <th>Adjusted Next Feeding</th>
                        <th>Reason</th>
                        <th>Notes</th>
                        <th>Adjusted By</th>
                        <th>Adjusted At</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($feedingSchedule->adjustments as $adjustment)
                        <tr>
                            <td>{{ $adjustment->original_next_due_at->format('d M Y, g:i A') }}</td>
                            <td>{{ $adjustment->adjusted_next_due_at->format('d M Y, g:i A') }}</td>
                            <td>{{ \App\Models\FeedingScheduleAdjustment::REASONS[$adjustment->reason] ?? $adjustment->reason }}</td>
                            <td>{{ $adjustment->notes ?? '—' }}</td>
                            <td>{{ $adjustment->adjustedBy->name ?? '—' }}</td>
                            <td>{{ $adjustment->adjusted_at->format('d M Y, g:i A') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <p class="mb-0 text-muted">No adjustments have been made to this schedule yet.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
