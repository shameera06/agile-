@php
    $dueBadgeClasses = [
        'overdue' => 'bg-label-danger',
        'due_today' => 'bg-label-warning',
        'upcoming' => 'bg-label-info',
    ];
    $dueLabels = [
        'overdue' => 'Overdue',
        'due_today' => 'Due Today',
        'upcoming' => 'Upcoming',
    ];
@endphp
@if ($dueStatus)
    <span class="badge {{ $dueBadgeClasses[$dueStatus] }}">{{ $dueLabels[$dueStatus] }}</span>
@else
    <span class="text-muted">—</span>
@endif
