@extends('admin.layouts.master')

@section('title', 'Feeding Schedules')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Feeding Schedules</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Feeding Schedules</h4>
        <a href="{{ route('admin.feeding-schedules.create') }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Feeding Schedule
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.feeding-schedules.index') }}" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="search" class="form-label">Search</label>
                    <input
                        type="text"
                        id="search"
                        name="search"
                        class="form-control"
                        placeholder="Reptile name, code, or food"
                        value="{{ $search }}"
                    />
                </div>
                <div class="col-md-2">
                    <label for="reptile_id" class="form-label">Reptile</label>
                    <select id="reptile_id" name="reptile_id" class="form-select">
                        <option value="">All Reptiles</option>
                        @foreach ($reptileOptions as $option)
                            <option value="{{ $option->id }}" @selected($reptileId === $option->id)>{{ $option->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="food_type_id" class="form-label">Food</label>
                    <select id="food_type_id" name="food_type_id" class="form-select">
                        <option value="">All Food Types</option>
                        @foreach ($foodTypeOptions as $option)
                            <option value="{{ $option->id }}" @selected($foodTypeId === $option->id)>
                                {{ $option->parent ? $option->parent->name . ' → ' . $option->name : $option->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="" @selected($status === '')>All</option>
                        @foreach (\App\Models\FeedingSchedule::STATUSES as $value => $label)
                            <option value="{{ $value }}" @selected($status === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="due" class="form-label">Due</label>
                    <select id="due" name="due" class="form-select">
                        <option value="" @selected($due === '')>All</option>
                        <option value="upcoming" @selected($due === 'upcoming')>Upcoming</option>
                        <option value="due_today" @selected($due === 'due_today')>Due Today</option>
                        <option value="overdue" @selected($due === 'overdue')>Overdue</option>
                    </select>
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary" title="Filter"><i class="bx bx-search"></i></button>
                </div>
            </form>
            @if ($search !== '' || $reptileId || $foodTypeId || $status !== '' || $due !== '')
                <a href="{{ route('admin.feeding-schedules.index') }}" class="btn btn-outline-secondary btn-sm mt-3">Reset filters</a>
            @endif
        </div>
    </div>

    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Reptile</th>
                        <th>Species</th>
                        <th>Food</th>
                        <th>Quantity</th>
                        <th>Interval</th>
                        <th>Next Feeding</th>
                        <th>Due</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($feedingSchedules as $schedule)
                        <tr>
                            <td>
                                <h6 class="mb-0">{{ $schedule->reptile->name }}</h6>
                                <small class="text-muted">{{ $schedule->reptile->reptile_code }}</small>
                            </td>
                            <td>{{ $schedule->reptile->species->name }}</td>
                            <td>
                                {{ $schedule->foodType->parent ? $schedule->foodType->parent->name . ' → ' . $schedule->foodType->name : $schedule->foodType->name }}
                            </td>
                            <td>{{ rtrim(rtrim($schedule->quantity, '0'), '.') }} {{ \App\Models\FeedingSchedule::QUANTITY_UNITS[$schedule->quantity_unit] ?? $schedule->quantity_unit }}</td>
                            <td>Every {{ $schedule->interval_days }} {{ Str::plural('day', $schedule->interval_days) }}</td>
                            <td>{{ $schedule->next_due_at->format('M d, Y g:i A') }}</td>
                            <td>@include('admin.feeding-schedules._due_badge', ['dueStatus' => $schedule->dueStatus()])</td>
                            <td>@include('admin.feeding-schedules._status_badge', ['status' => $schedule->status])</td>
                            <td>
                                <div class="d-flex align-items-center gap-1">
                                    @if ($schedule->status === 'active')
                                        <a href="{{ route('admin.feeding-records.create', ['feeding_schedule_id' => $schedule->id]) }}" class="btn btn-sm btn-primary" title="Record Feeding">
                                            <i class="bx bx-restaurant"></i> Record Feeding
                                        </a>
                                    @endif
                                    <x-admin.action-menu>
                                        <a href="{{ route('admin.feeding-schedules.edit', $schedule) }}" class="dropdown-item">
                                            <i class="bx bx-edit-alt"></i> Edit
                                        </a>
                                        @if ($schedule->status === 'active')
                                            <a href="{{ route('admin.feeding-schedules.adjust-next-feeding', $schedule) }}" class="dropdown-item">
                                                <i class="bx bx-calendar-edit"></i> Adjust Next Feeding
                                            </a>
                                        @endif
                                    </x-admin.action-menu>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" class="text-center py-5">
                                <p class="mb-1 fw-semibold">No feeding schedules found.</p>
                                <p class="text-muted mb-0">Add your first feeding schedule to begin planning feedings.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($feedingSchedules->hasPages())
            <div class="card-footer">
                {{ $feedingSchedules->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
