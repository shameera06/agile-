@php
    $severityBadgeClasses = [
        'warning' => 'bg-label-warning',
        'critical' => 'bg-label-danger',
    ];
@endphp
<span class="badge {{ $severityBadgeClasses[$severity] ?? 'bg-label-secondary' }}">
    {{ strtoupper(\App\Models\HealthAlert::SEVERITIES[$severity] ?? $severity) }}
</span>
