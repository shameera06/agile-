{{-- Rendered server-side by HealthAlertDataTable::actionButtons() for each row. --}}
<x-admin.action-menu>
    <a href="{{ route('admin.health-alerts.show', $alert) }}" class="dropdown-item">
        <i class="bx bx-show"></i> View Alert
    </a>
    <a href="{{ route('admin.reptiles.show', $alert->reptile) }}" class="dropdown-item">
        <i class="bx bx-id-card"></i> View Reptile
    </a>
    @if (auth()->user()?->isAdmin() && $alert->status === 'active')
        {{-- Resolving now requires documentation, so it's done from the
             detail page's form rather than a one-click action here. --}}
        <a href="{{ route('admin.health-alerts.show', $alert) }}#resolve-concern" class="dropdown-item text-success">
            <i class="bx bx-check-circle"></i> Resolve
        </a>
        <form action="{{ route('admin.health-alerts.dismiss', $alert) }}" method="POST"
            onsubmit="return confirm('Dismiss this alert?');">
            @csrf
            @method('PATCH')
            <button type="submit" class="dropdown-item text-muted">
                <i class="bx bx-x-circle"></i> Dismiss
            </button>
        </form>
    @endif
</x-admin.action-menu>
