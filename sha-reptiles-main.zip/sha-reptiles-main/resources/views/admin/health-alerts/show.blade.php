@extends('admin.layouts.master')

@section('title', 'Health Alert Details')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.health-alerts.index') }}">Health Alerts</a></li>
            <li class="breadcrumb-item active">Health Alert Details</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Health Alert Details</h4>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.reptiles.show', $healthAlert->reptile) }}" class="btn btn-outline-primary">
                <i class="bx bx-id-card me-1"></i> View Reptile
            </a>
            @if (auth()->user()?->isAdmin() && $healthAlert->status === 'active')
                <a href="#resolve-concern" class="btn btn-success">
                    <i class="bx bx-check-circle me-1"></i> Resolve
                </a>
                <form action="{{ route('admin.health-alerts.dismiss', $healthAlert) }}" method="POST"
                    onsubmit="return confirm('Dismiss this alert?');" class="d-inline">
                    @csrf
                    @method('PATCH')
                    <button type="submit" class="btn btn-outline-secondary">
                        <i class="bx bx-x-circle me-1"></i> Dismiss
                    </button>
                </form>
            @endif
        </div>
    </div>

    @if ($healthAlert->status === 'active')
        <div class="alert alert-warning d-flex align-items-center mb-4" role="alert">
            <i class="bx bx-error-circle me-2"></i>
            <div>This alert is still <strong>ACTIVE</strong> and requires attention.</div>
        </div>
    @endif

    <div class="row">
        <div class="col-md-4 col-lg-3 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="mb-1">{{ $healthAlert->reptile->name }}</h5>
                    <p class="text-muted mb-2">{{ $healthAlert->reptile->reptile_code }}</p>
                    <div class="d-flex flex-wrap justify-content-center gap-1 mb-2">
                        @if ($healthAlert->reptile->species?->category)
                            <span class="badge bg-label-primary">{{ $healthAlert->reptile->species->category->name }}</span>
                        @endif
                        <span class="badge bg-label-info">{{ $healthAlert->reptile->species->name }}</span>
                        @if ($healthAlert->reptile->variety)
                            <span class="badge bg-label-warning">{{ $healthAlert->reptile->variety->name }}</span>
                        @endif
                    </div>
                    @include('admin.health-alerts._status_badge', ['status' => $healthAlert->status])
                </div>
            </div>
        </div>

        <div class="col-md-8 col-lg-9 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title m-0">{{ $healthAlert->title }}</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-borderless mb-0">
                            <tbody>
                                <tr>
                                    <th class="text-muted" style="width: 220px;">Reptile</th>
                                    <td>{{ $healthAlert->reptile->name }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Animal ID</th>
                                    <td>{{ $healthAlert->reptile->reptile_code }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Category</th>
                                    <td>{{ $healthAlert->reptile->species?->category?->name ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Species Type</th>
                                    <td>{{ $healthAlert->reptile->species->name }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Variety / Morph</th>
                                    <td>{{ $healthAlert->reptile->variety?->name ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Alert Type</th>
                                    <td>{{ \App\Models\HealthAlert::ALERT_TYPES[$healthAlert->alert_type] ?? ucfirst($healthAlert->alert_type) }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Title</th>
                                    <td>{{ $healthAlert->title }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Message</th>
                                    <td>{{ $healthAlert->message }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Severity</th>
                                    <td>@include('admin.health-alerts._severity_badge', ['severity' => $healthAlert->severity])</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Status</th>
                                    <td>@include('admin.health-alerts._status_badge', ['status' => $healthAlert->status])</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Triggered Date</th>
                                    <td>{{ $healthAlert->triggered_at->format('M d, Y g:i A') }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Source</th>
                                    <td>{{ \App\Models\HealthAlert::SOURCES[$healthAlert->source] ?? ucfirst($healthAlert->source) }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Related Feeding Record</th>
                                    <td>
                                        @if ($healthAlert->feedingRecord)
                                            {{ $healthAlert->feedingRecord->feeding_date->format('M d, Y g:i A') }}
                                            <a href="{{ route('admin.feeding-records.edit', $healthAlert->feedingRecord) }}" class="btn btn-sm btn-outline-primary ms-2">View</a>
                                        @else
                                            <span class="text-muted">—</span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Current Weight</th>
                                    <td>{{ $healthAlert->reptile->current_weight !== null ? $healthAlert->reptile->current_weight.' '.$healthAlert->reptile->weight_unit : '—' }}</td>
                                </tr>
                                @if ($healthAlert->feedingRecord)
                                    <tr>
                                        <th class="text-muted">Weight Before / After (triggering feeding)</th>
                                        <td>
                                            {{ $healthAlert->feedingRecord->weight_before }} g
                                            &rarr;
                                            {{ $healthAlert->feedingRecord->weight_after }} g
                                            @if ($healthAlert->feedingRecord->weight_after_defecation !== null)
                                                (after defecation: {{ $healthAlert->feedingRecord->weight_after_defecation }} g)
                                            @endif
                                        </td>
                                    </tr>
                                @endif
                                <tr>
                                    <th class="text-muted">Resolved Date</th>
                                    <td>{{ optional($healthAlert->resolved_at)->format('M d, Y g:i A') ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Resolved By</th>
                                    <td>{{ $healthAlert->resolvedBy->name ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Notes</th>
                                    <td>{{ $healthAlert->notes ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Evidence</th>
                                    <td>
                                        @if ($healthAlert->hasEvidence())
                                            <a href="{{ route('admin.health-alerts.evidence', $healthAlert) }}" class="btn btn-sm btn-outline-primary" target="_blank">
                                                <i class="bx bx-paperclip me-1"></i> View Evidence
                                            </a>
                                        @else
                                            <span class="text-muted">—</span>
                                        @endif
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if ($healthAlert->status === 'active')
        {{-- "User documents action taken" step — any authenticated user, not
             just Admin. Never changes status; see HealthAlertController::update(). --}}
        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title m-0">Document Action Taken</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.health-alerts.update', $healthAlert) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PATCH')
                            <div class="mb-3">
                                <label for="action-notes" class="form-label">Notes</label>
                                <textarea id="action-notes" name="notes" rows="3" class="form-control @error('notes') is-invalid @enderror" placeholder="What was checked/done for this reptile?">{{ old('notes', $healthAlert->notes) }}</textarea>
                                @error('notes')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-3">
                                <label for="action-evidence" class="form-label">Supporting File / Image</label>
                                <input type="file" id="action-evidence" name="evidence" class="form-control @error('evidence') is-invalid @enderror" accept=".jpg,.jpeg,.png,.webp,.pdf">
                                @error('evidence')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bx bx-save me-1"></i> Save Notes
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        @if (auth()->user()?->isAdmin())
            {{-- Resolving requires documentation to already exist — either
                 saved above beforehand, or submitted right here. --}}
            <div class="row" id="resolve-concern">
                <div class="col-lg-8 mb-4">
                    <div class="card border-success">
                        <div class="card-header">
                            <h5 class="card-title m-0">Resolve Weight Concern</h5>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('admin.health-alerts.resolve', $healthAlert) }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <div class="mb-3">
                                    <label for="resolve-notes" class="form-label">Resolution Notes <span class="text-danger">*</span></label>
                                    <textarea id="resolve-notes" name="notes" rows="3" class="form-control @error('notes') is-invalid @enderror" placeholder="Document the action taken before resolving.">{{ old('notes', $healthAlert->notes) }}</textarea>
                                    @error('notes')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <small class="text-muted">Required before this concern can be resolved.</small>
                                </div>
                                <div class="mb-3">
                                    <label for="resolve-evidence" class="form-label">Supporting File / Image</label>
                                    <input type="file" id="resolve-evidence" name="evidence" class="form-control @error('evidence') is-invalid @enderror" accept=".jpg,.jpeg,.png,.webp,.pdf">
                                    @error('evidence')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <button type="submit" class="btn btn-success" onclick="return confirm('Mark this weight concern as resolved?');">
                                    <i class="bx bx-check-circle me-1"></i> Resolve
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    @endif
</div>
@endsection
