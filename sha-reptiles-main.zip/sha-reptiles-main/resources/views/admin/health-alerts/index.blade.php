@extends('admin.layouts.master')

@section('title', 'Health Alerts')

@push('page-styles')
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css') }}" />
@endpush

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Health Alerts</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Health Alerts</h4>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.health-alerts.index') }}" class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label for="severity" class="form-label">Severity</label>
                    <select id="severity" name="severity" class="form-select">
                        <option value="">All</option>
                        @foreach (\App\Models\HealthAlert::SEVERITIES as $value => $label)
                            <option value="{{ $value }}" @selected(request('severity') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="">All</option>
                        @foreach (\App\Models\HealthAlert::STATUSES as $value => $label)
                            <option value="{{ $value }}" @selected(request('status') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="alert_type" class="form-label">Alert Type</label>
                    <select id="alert_type" name="alert_type" class="form-select">
                        <option value="">All</option>
                        @foreach (\App\Models\HealthAlert::ALERT_TYPES as $value => $label)
                            <option value="{{ $value }}" @selected(request('alert_type') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="date_from" class="form-label">Triggered From</label>
                    <input type="date" id="date_from" name="date_from" class="form-control" value="{{ request('date_from') }}" />
                </div>
                <div class="col-md-2">
                    <label for="date_to" class="form-label">Triggered To</label>
                    <input type="date" id="date_to" name="date_to" class="form-control" value="{{ request('date_to') }}" />
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bx bx-filter-alt me-1"></i> Filter
                    </button>
                    @if (request()->anyFilled(['severity', 'status', 'alert_type', 'date_from', 'date_to']))
                        <a href="{{ route('admin.health-alerts.index') }}" class="btn btn-outline-secondary">Reset</a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive text-nowrap">
            {!! $dataTable->table(['class' => 'table']) !!}
        </div>
    </div>
</div>
@endsection

@push('page-scripts')
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.js') }}"></script>
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.js') }}"></script>
{!! $dataTable->scripts() !!}
@endpush
