@php
    $statusBadgeClasses = [
        'active' => 'bg-label-danger',
        'resolved' => 'bg-label-success',
        'dismissed' => 'bg-label-secondary',
    ];
@endphp
<span class="badge {{ $statusBadgeClasses[$status] ?? 'bg-label-secondary' }}">
    {{ strtoupper(\App\Models\HealthAlert::STATUSES[$status] ?? $status) }}
</span>
