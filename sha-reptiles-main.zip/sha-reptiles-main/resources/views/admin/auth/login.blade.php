@extends('admin.layouts.auth')

@section('title', 'Login')

@section('content')
    <h4 class="mb-2">Welcome! 👋</h4>
    <p class="mb-4">Please sign in to your admin account</p>

    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif

    <form id="formAuthentication" class="mb-3" action="{{ route('admin.login.submit') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input
                type="email"
                class="form-control @error('email') is-invalid @enderror"
                id="email"
                name="email"
                placeholder="Enter your email"
                value="{{ old('email') }}"
                autofocus
            />
            @error('email')
                <span class="invalid-feedback d-block" role="alert">{{ $message }}</span>
            @enderror
        </div>
        <div class="mb-3 form-password-toggle">
            <div class="d-flex justify-content-between">
                <label class="form-label" for="password">Password</label>
                <a href="{{ route('admin.password.request') }}">
                    <small>Forgot Password?</small>
                </a>
            </div>
            <div class="input-group input-group-merge">
                <input
                    type="password"
                    id="password"
                    class="form-control @error('password') is-invalid @enderror"
                    name="password"
                    placeholder="············"
                    aria-describedby="password"
                />
                <span class="input-group-text cursor-pointer" id="togglePassword"><i class="bx bx-hide"></i></span>
            </div>
            @error('password')
                <span class="invalid-feedback d-block" role="alert">{{ $message }}</span>
            @enderror
        </div>
        <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="remember-me" name="remember" value="1" />
                <label class="form-check-label" for="remember-me"> Remember Me </label>
            </div>
        </div>
        <div class="mb-3">
            <button class="btn btn-primary d-grid w-100" type="submit">Sign in</button>
        </div>
    </form>
@endsection

@section('scripts')
    <script>
        (function () {
            var toggle = document.getElementById('togglePassword');
            var password = document.getElementById('password');

            if (!toggle || !password) {
                return;
            }

            toggle.addEventListener('click', function () {
                var icon = toggle.querySelector('i');
                var isHidden = password.getAttribute('type') === 'password';

                password.setAttribute('type', isHidden ? 'text' : 'password');
                icon.classList.toggle('bx-hide', !isHidden);
                icon.classList.toggle('bx-show', isHidden);
            });
        })();
    </script>
@endsection
