@extends('admin.layouts.auth')

@section('title', 'Reset Password')

@section('content')
    <h4 class="mb-2">Reset Password 🔑</h4>
    <p class="mb-4">Enter your new password below</p>

    <form id="formResetPassword" class="mb-3" action="{{ route('admin.password.update') }}" method="POST">
        @csrf

        <input type="hidden" name="token" value="{{ $token }}" />

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input
                type="email"
                class="form-control @error('email') is-invalid @enderror"
                id="email"
                name="email"
                placeholder="Enter your email"
                value="{{ old('email', $email) }}"
                autofocus
            />
            @error('email')
                <span class="invalid-feedback d-block" role="alert">{{ $message }}</span>
            @enderror
        </div>
        <div class="mb-3 form-password-toggle">
            <label class="form-label" for="password">New Password</label>
            <div class="input-group input-group-merge">
                <input
                    type="password"
                    id="password"
                    class="form-control @error('password') is-invalid @enderror"
                    name="password"
                    placeholder="············"
                    aria-describedby="password"
                />
                <span class="input-group-text cursor-pointer" id="togglePassword"><i class="bx bx-hide"></i></span>
            </div>
            @error('password')
                <span class="invalid-feedback d-block" role="alert">{{ $message }}</span>
            @enderror
        </div>
        <div class="mb-3 form-password-toggle">
            <label class="form-label" for="password_confirmation">Confirm Password</label>
            <div class="input-group input-group-merge">
                <input
                    type="password"
                    id="password_confirmation"
                    class="form-control"
                    name="password_confirmation"
                    placeholder="············"
                    aria-describedby="password_confirmation"
                />
                <span class="input-group-text cursor-pointer" id="togglePasswordConfirmation"><i class="bx bx-hide"></i></span>
            </div>
        </div>
        <button class="btn btn-primary d-grid w-100 mb-3" type="submit">Reset Password</button>
    </form>

    <div class="text-center">
        <a href="{{ route('admin.login') }}">
            <i class="bx bx-chevron-left scaleX-n1-rtl bx-sm"></i>
            Back to login
        </a>
    </div>
@endsection

@section('scripts')
    <script>
        (function () {
            function bindToggle(toggleId, inputId) {
                var toggle = document.getElementById(toggleId);
                var input = document.getElementById(inputId);

                if (!toggle || !input) {
                    return;
                }

                toggle.addEventListener('click', function () {
                    var icon = toggle.querySelector('i');
                    var isHidden = input.getAttribute('type') === 'password';

                    input.setAttribute('type', isHidden ? 'text' : 'password');
                    icon.classList.toggle('bx-hide', !isHidden);
                    icon.classList.toggle('bx-show', isHidden);
                });
            }

            bindToggle('togglePassword', 'password');
            bindToggle('togglePasswordConfirmation', 'password_confirmation');
        })();
    </script>
@endsection
