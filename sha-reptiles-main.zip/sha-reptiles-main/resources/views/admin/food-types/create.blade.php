@extends('admin.layouts.master')

@section('title', 'Add Food Type')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.food-types.index') }}">Food Types</a></li>
            <li class="breadcrumb-item active">Add Food Type</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Add Food Type</h4>

    <div class="card">
        <div class="card-body">
            @include('admin.food-types._form')
        </div>
    </div>
</div>
@endsection
