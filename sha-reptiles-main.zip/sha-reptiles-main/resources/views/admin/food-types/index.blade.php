@extends('admin.layouts.master')

@section('title', 'Food Types')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Food Types</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Food Types</h4>
        <a href="{{ route('admin.food-types.create') }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Food Type
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.food-types.index') }}" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="search" class="form-label">Search</label>
                    <input
                        type="text"
                        id="search"
                        name="search"
                        class="form-control"
                        placeholder="Search by name or description"
                        value="{{ $search }}"
                    />
                </div>
                <div class="col-md-3">
                    <label for="parent_id" class="form-label">Category</label>
                    <select id="parent_id" name="parent_id" class="form-select">
                        <option value="" @selected($parentFilter === '')>All</option>
                        <option value="top-level" @selected($parentFilter === 'top-level')>Top-Level Categories Only</option>
                        @foreach ($topLevelOptions as $option)
                            <option value="{{ $option->id }}" @selected($parentFilter === (string) $option->id)>
                                Under: {{ $option->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="" @selected($status === '')>All</option>
                        <option value="active" @selected($status === 'active')>Active</option>
                        <option value="inactive" @selected($status === 'inactive')>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bx bx-search me-1"></i> Filter
                    </button>
                    @if ($search !== '' || $status !== '' || $parentFilter !== '')
                        <a href="{{ route('admin.food-types.index') }}" class="btn btn-outline-secondary">Reset</a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Parent Category</th>
                        <th>Status</th>
                        <th>Created Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($foodTypes as $item)
                        <tr>
                            <td>{{ $loop->iteration + ($foodTypes->currentPage() - 1) * $foodTypes->perPage() }}</td>
                            <td>
                                @if ($item->parent)
                                    <i class="bx bx-subdirectory-right text-muted me-1"></i>
                                @endif
                                {{ $item->name }}
                            </td>
                            <td>{{ $item->parent->name ?? '—' }}</td>
                            <td>
                                @if ($item->status)
                                    <span class="badge bg-label-success">Active</span>
                                @else
                                    <span class="badge bg-label-secondary">Inactive</span>
                                @endif
                            </td>
                            <td>{{ $item->created_at->format('M d, Y') }}</td>
                            <td>
                                <x-admin.action-menu>
                                    <a href="{{ route('admin.food-types.edit', $item) }}" class="dropdown-item">
                                        <i class="bx bx-edit-alt"></i> Edit
                                    </a>
                                    <form
                                        method="POST"
                                        action="{{ route('admin.food-types.destroy', $item) }}"
                                        onsubmit="return confirm('Are you sure you want to delete this food type?');"
                                    >
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="bx bx-trash"></i> Delete
                                        </button>
                                    </form>
                                </x-admin.action-menu>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <p class="mb-1 fw-semibold">No food types found.</p>
                                <p class="text-muted mb-0">Add your first food type to begin managing feeding options.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($foodTypes->hasPages())
            <div class="card-footer">
                {{ $foodTypes->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
