@php
    $isEdit = $foodType->exists;
    $action = $isEdit ? route('admin.food-types.update', $foodType) : route('admin.food-types.store');
    $hasChildren = $isEdit && $foodType->children()->exists();
@endphp

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Name *</label>
            <input
                type="text"
                id="name"
                name="name"
                class="form-control @error('name') is-invalid @enderror"
                placeholder="e.g. Mouse, or Pinky"
                value="{{ old('name', $foodType->name) }}"
                autofocus
            />
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="parent_id" class="form-label">Parent Category</label>
            <select
                id="parent_id"
                name="parent_id"
                class="form-select @error('parent_id') is-invalid @enderror"
                @disabled($hasChildren)
            >
                <option value="">None (Top-Level Category)</option>
                @foreach ($parentOptions as $option)
                    <option value="{{ $option->id }}" @selected((int) old('parent_id', $foodType->parent_id) === $option->id)>
                        {{ $option->name }}{{ ! $option->status ? ' (inactive)' : '' }}
                    </option>
                @endforeach
            </select>
            @if ($hasChildren)
                <small class="text-muted d-block mt-1">
                    This food type has its own sub-types and cannot be nested under another category.
                </small>
                {{-- Disabled selects are not submitted, so resend the current (empty) value. --}}
                <input type="hidden" name="parent_id" value="{{ old('parent_id', $foodType->parent_id) }}" />
            @endif
            @error('parent_id')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea
            id="description"
            name="description"
            rows="3"
            class="form-control @error('description') is-invalid @enderror"
            placeholder="A short description of this food type"
        >{{ old('description', $foodType->description) }}</textarea>
        @error('description')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="row">
        <div class="mb-4 col-md-6">
            <label for="status" class="form-label">Status</label>
            <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
                <option value="1" @selected(old('status', (int) $foodType->status) == 1)>Active</option>
                <option value="0" @selected(old('status', (int) $foodType->status) == 0)>Inactive</option>
            </select>
            @error('status')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-4 col-md-6">
            <label for="default_unit" class="form-label">Default Feeding Unit</label>
            <select id="default_unit" name="default_unit" class="form-select @error('default_unit') is-invalid @enderror">
                <option value="">None</option>
                @foreach (\App\Models\FeedingSchedule::QUANTITY_UNITS as $value => $label)
                    <option value="{{ $value }}" @selected(old('default_unit', $foodType->default_unit) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            <small class="text-muted d-block mt-1">Only relevant for leaf food types; pre-fills the unit when this food is used on a feeding schedule.</small>
            @error('default_unit')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Save Food Type</button>
    <a href="{{ route('admin.food-types.index') }}" class="btn btn-outline-secondary">Cancel</a>
</form>
