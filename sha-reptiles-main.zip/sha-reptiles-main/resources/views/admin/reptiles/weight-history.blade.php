@extends('admin.layouts.master')

@section('title', 'Weight History')

@push('page-styles')
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css') }}" />
@endpush

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            @if ($reptile->species?->category)
                {{-- Reached the hierarchy way: Dashboard > Species > Category > Type > Variety > Reptile --}}
                <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.species.category', $reptile->species->category) }}">{{ $reptile->species->category->name }}</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.species.type', $reptile->species) }}">{{ $reptile->species->name }}</a></li>
                @if ($reptile->variety)
                    <li class="breadcrumb-item"><a href="{{ route('admin.species.variety', [$reptile->species, $reptile->variety]) }}">{{ $reptile->variety->name }}</a></li>
                @endif
            @else
                <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.index') }}">Reptiles</a></li>
            @endif
            <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.show', $reptile) }}">{{ $reptile->name }}</a></li>
            <li class="breadcrumb-item active">Weight History</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <div>
            <h4 class="fw-bold mb-1">Weight History</h4>
            <p class="text-muted mb-0">Every recorded weight measurement for {{ $reptile->name }}, drawn from its feeding records.</p>
        </div>
        <a href="{{ route('admin.reptiles.show', $reptile) }}" class="btn btn-outline-secondary">
            <i class="bx bx-arrow-back me-1"></i> Back to Reptile Details
        </a>
    </div>

    <div class="row">
        <div class="col-md-4 col-lg-3 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    @if ($reptile->photo_url)
                        <img src="{{ $reptile->photo_url }}" alt="{{ $reptile->name }}" class="rounded mb-3" style="width: 140px; height: 140px; object-fit: cover;" />
                    @else
                        <span class="avatar-initial rounded bg-label-secondary d-inline-flex mb-3" style="width: 140px; height: 140px; font-size: 3rem;">
                            <i class="bx bx-image d-flex align-items-center justify-content-center w-100 h-100"></i>
                        </span>
                    @endif
                    <h5 class="mb-1">{{ $reptile->name }}</h5>
                    <p class="text-muted mb-2">{{ $reptile->reptile_code }}</p>
                    <div class="d-flex flex-wrap justify-content-center gap-1 mb-2">
                        @if ($reptile->species?->category)
                            <span class="badge bg-label-primary">{{ $reptile->species->category->name }}</span>
                        @endif
                        <span class="badge bg-label-info">{{ $reptile->species->name }}</span>
                        @if ($reptile->variety)
                            <span class="badge bg-label-warning">{{ $reptile->variety->name }}</span>
                        @endif
                    </div>
                    @include('admin.reptiles._status_badge', ['status' => $reptile->status])
                </div>
            </div>
        </div>

        <div class="col-md-8 col-lg-9 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="card-title m-0">Current Weight</h5>
                </div>
                <div class="card-body d-flex flex-column justify-content-center">
                    <h2 class="mb-1">
                        {{ $reptile->current_weight !== null ? $reptile->current_weight.' '.$reptile->weight_unit : '—' }}
                    </h2>
                    <small class="text-muted">
                        This is the reptile's current recorded weight — kept in sync automatically with its most recent feeding record. It is not recalculated on this page.
                    </small>
                </div>
            </div>
        </div>
    </div>

    @if ($highlightedFeedingIds->isNotEmpty())
        <div class="alert alert-danger d-flex align-items-center mb-3" role="alert">
            <i class="bx bx-error-circle me-2"></i>
            <div>
                {{ $reptile->name }} has not shown proper weight gain during the last three feeding
                records (highlighted below). {{ \App\Models\FeedingRecord::ALERT_MESSAGE }}
            </div>
        </div>
    @endif

    <div class="card">
        <div class="card-header">
            <h5 class="card-title m-0">Weight &amp; Feeding Records</h5>
        </div>
        <div class="card-body table-responsive text-nowrap">
            {!! $feedingDataTable->table(['class' => 'table']) !!}
        </div>
    </div>
</div>
@endsection

@push('page-scripts')
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.js') }}"></script>
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.js') }}"></script>
{!! $feedingDataTable->scripts() !!}
@endpush
