@extends('admin.layouts.master')

@section('title', 'Reptiles')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Reptiles</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Reptiles</h4>
        <a href="{{ route('admin.reptiles.create') }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Reptile
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.reptiles.index') }}" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="search" class="form-label">Search</label>
                    <input
                        type="text"
                        id="search"
                        name="search"
                        class="form-control"
                        placeholder="Search by name or reptile code"
                        value="{{ $search }}"
                    />
                </div>
                <div class="col-md-3">
                    <label for="species_id" class="form-label">Species</label>
                    <select id="species_id" name="species_id" class="form-select">
                        <option value="">All Species</option>
                        @foreach ($speciesOptions as $option)
                            <option value="{{ $option->id }}" @selected($speciesId === $option->id)>{{ $option->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="" @selected($status === '')>All</option>
                        @foreach (\App\Models\Reptile::STATUSES as $value => $label)
                            <option value="{{ $value }}" @selected($status === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-1">
                    <label for="sex" class="form-label">Sex</label>
                    <select id="sex" name="sex" class="form-select">
                        <option value="" @selected($sex === '')>All</option>
                        @foreach (\App\Models\Reptile::SEXES as $value => $label)
                            <option value="{{ $value }}" @selected($sex === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bx bx-search me-1"></i> Filter
                    </button>
                    @if ($search !== '' || $speciesId || $status !== '' || $sex !== '')
                        <a href="{{ route('admin.reptiles.index') }}" class="btn btn-outline-secondary">Reset</a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Reptile Code</th>
                        <th>Name</th>
                        <th>Species</th>
                        <th>Sex</th>
                        <th>Current Weight</th>
                        <th>Status</th>
                        <th>Health Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($reptiles as $reptile)
                        <tr>
                            <td>
                                @if ($reptile->photo_url)
                                    <img src="{{ $reptile->photo_url }}" alt="{{ $reptile->name }}" class="rounded" style="width: 40px; height: 40px; object-fit: cover;" />
                                @else
                                    <span class="avatar-initial rounded bg-label-secondary d-inline-flex" style="width: 40px; height: 40px;">
                                        <i class="bx bx-image d-flex align-items-center justify-content-center w-100 h-100"></i>
                                    </span>
                                @endif
                            </td>
                            <td>{{ $reptile->reptile_code }}</td>
                            <td>{{ $reptile->name }}</td>
                            <td>{{ $reptile->species->name }}</td>
                            <td>{{ \App\Models\Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex) }}</td>
                            <td>{{ $reptile->current_weight !== null ? $reptile->current_weight.' '.$reptile->weight_unit : '—' }}</td>
                            <td>@include('admin.reptiles._status_badge', ['status' => $reptile->status])</td>
                            <td>
                                @if ($reptile->has_active_health_alert)
                                    <span class="badge bg-label-danger"><i class="bx bx-error-circle"></i> Attention</span>
                                @else
                                    <span class="badge bg-label-success">Normal</span>
                                @endif
                            </td>
                            <td>{{ $reptile->created_at->format('M d, Y') }}</td>
                            <td>
                                <x-admin.action-menu>
                                    <a href="{{ route('admin.reptiles.show', $reptile) }}" class="dropdown-item">
                                        <i class="bx bx-show"></i> View
                                    </a>
                                    <a href="{{ route('admin.reptiles.edit', $reptile) }}" class="dropdown-item">
                                        <i class="bx bx-edit-alt"></i> Edit
                                    </a>
                                    @if ($reptile->status === 'active')
                                        <form
                                            method="POST"
                                            action="{{ route('admin.reptiles.archive', $reptile) }}"
                                            onsubmit="return confirm('Archive this reptile? Its status will be set to Inactive.');"
                                        >
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="dropdown-item text-warning">
                                                <i class="bx bx-archive"></i> Archive
                                            </button>
                                        </form>
                                    @endif
                                </x-admin.action-menu>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="10" class="text-center py-5">
                                <p class="mb-1 fw-semibold">No reptiles found.</p>
                                <p class="text-muted mb-0">Add your first reptile to begin managing your collection.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($reptiles->hasPages())
            <div class="card-footer">
                {{ $reptiles->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
