@extends('admin.layouts.master')

@section('title', 'Reptile Details')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            @if ($reptile->species?->category)
                {{-- Reached the hierarchy way: Dashboard > Species > Category > Type > Variety > Reptile --}}
                <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.species.category', $reptile->species->category) }}">{{ $reptile->species->category->name }}</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.species.type', $reptile->species) }}">{{ $reptile->species->name }}</a></li>
                @if ($reptile->variety)
                    <li class="breadcrumb-item"><a href="{{ route('admin.species.variety', [$reptile->species, $reptile->variety]) }}">{{ $reptile->variety->name }}</a></li>
                @endif
            @else
                {{-- This reptile's species type isn't assigned to a category yet —
                     fall back to the original, pre-hierarchy breadcrumb so nothing
                     ever dead-ends. --}}
                <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.index') }}">Reptiles</a></li>
            @endif
            <li class="breadcrumb-item active">{{ $reptile->name }}</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Reptile Details</h4>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.reptiles.weight-history', $reptile) }}" class="btn btn-outline-primary">
                <i class="bx bx-line-chart me-1"></i> Weight History
            </a>
            {{-- @if ($activeFeedingSchedule)
                <a href="{{ route('admin.feeding-schedules.adjust-next-feeding', $activeFeedingSchedule) }}" class="btn btn-outline-primary" title="Next Feeding: {{ $activeFeedingSchedule->next_due_at->format('d M Y, g:i A') }}">
                    <i class="bx bx-calendar-edit me-1"></i> Next Feeding: {{ $activeFeedingSchedule->next_due_at->format('d M Y, g:i A') }}
                </a>
            @endif --}}
            @if ($reptile->status === 'active')
                <a href="{{ route('admin.feeding-records.create', ['reptile_id' => $reptile->id]) }}" class="btn btn-primary">
                    <i class="bx bx-restaurant me-1"></i> Add Feeding Record
                </a>
                <a href="{{ route('admin.shedding-records.create', ['reptile_id' => $reptile->id]) }}" class="btn btn-outline-primary">
                    <i class="bx bx-refresh me-1"></i> Add Shedding Record
                </a>
            @endif
            <a href="{{ route('admin.medical-records.create', ['reptile_id' => $reptile->id]) }}" class="btn btn-outline-primary">
                <i class="bx bx-plus-medical me-1"></i> Add Medical Record
            </a>
            <a href="{{ route('admin.reptiles.edit', $reptile) }}" class="btn btn-outline-primary">
                <i class="bx bx-edit-alt me-1"></i> Edit Reptile
            </a>
            <a href="{{ route('admin.reptiles.ai-assistant', $reptile) }}" class="btn btn-outline-primary">
                <i class="bx bx-bot me-1"></i> AI Assistant
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 col-lg-3 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    @if ($reptile->photo_url)
                        <img src="{{ $reptile->photo_url }}" alt="{{ $reptile->name }}" class="rounded mb-3" style="width: 160px; height: 160px; object-fit: cover;" />
                    @else
                        <span class="avatar-initial rounded bg-label-secondary d-inline-flex mb-3" style="width: 160px; height: 160px; font-size: 3.5rem;">
                            <i class="bx bx-image d-flex align-items-center justify-content-center w-100 h-100"></i>
                        </span>
                    @endif

                    <h5 class="mb-1">{{ $reptile->name }}</h5>
                    <p class="text-muted mb-2">{{ $reptile->reptile_code }}</p>

                    {{-- Category / Species Type / Variety, so the hierarchy this
                         reptile lives under is always visible on its own profile. --}}
                    <div class="d-flex flex-wrap justify-content-center gap-1 mb-2">
                        @if ($reptile->species?->category)
                            <span class="badge bg-label-primary">{{ $reptile->species->category->name }}</span>
                        @endif
                        <span class="badge bg-label-info">{{ $reptile->species->name }}</span>
                        @if ($reptile->variety)
                            <span class="badge bg-label-warning">{{ $reptile->variety->name }}</span>
                        @endif
                    </div>

                    @include('admin.reptiles._status_badge', ['status' => $reptile->status])
                </div>
            </div>
        </div>

        <div class="col-md-8 col-lg-9 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title m-0">Basic Information</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-borderless mb-0">
                            <tbody>
                                <tr>
                                    <th class="text-muted" style="width: 220px;">Name</th>
                                    <td>{{ $reptile->name }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Reptile Code</th>
                                    <td>{{ $reptile->reptile_code }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Category</th>
                                    <td>{{ $reptile->species?->category?->name ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Species Type</th>
                                    <td>{{ $reptile->species->name }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Variety / Morph</th>
                                    <td>{{ $reptile->variety?->name ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Sex</th>
                                    <td>{{ \App\Models\Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex) }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Date of Birth</th>
                                    <td>{{ optional($reptile->date_of_birth)->format('M d, Y') ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Acquisition Date</th>
                                    <td>{{ optional($reptile->acquisition_date)->format('M d, Y') ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Acquisition Source</th>
                                    <td>{{ $reptile->acquisition_source ?? '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Current Weight</th>
                                    <td>{{ $reptile->current_weight !== null ? $reptile->current_weight.' '.$reptile->weight_unit : '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Length</th>
                                    <td>{{ $reptile->length !== null ? $reptile->length.' '.$reptile->length_unit : '—' }}</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Status</th>
                                    <td>@include('admin.reptiles._status_badge', ['status' => $reptile->status])</td>
                                </tr>
                                <tr>
                                    <th class="text-muted">Notes</th>
                                    <td>{{ $reptile->notes ?? '—' }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{--
        Existing Feeding/Weight, Shedding and Medical sections below are
        unchanged in content — only re-containered into tabs so this profile
        is structurally ready for future modules to plug into without
        another redesign. Bootstrap's own native tab plugin
        (data-bs-toggle="tab") is used — bootstrap.js is already loaded on
        every admin page, no new library needed. "Complete History" (Module
        11) is a real link to its own page, not a tab toggle. "Print PDF"
        remains an inert placeholder: no Module 12 functionality here.
    --}}
    <div class="row">
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-feeding" type="button" role="tab">
                                <i class="bx bx-restaurant me-1"></i> Feeding &amp; Weight
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-shedding" type="button" role="tab">
                                <i class="bx bx-refresh me-1"></i> Shedding
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-medical" type="button" role="tab">
                                <i class="bx bx-plus-medical me-1"></i> Medical
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-health-alerts" type="button" role="tab">
                                <i class="bx bx-error-circle me-1"></i> Health Alerts
                                @if ($healthAlerts->contains(fn ($alert) => $alert->status === 'active'))
                                    <span class="badge bg-label-danger ms-1">{{ $healthAlerts->where('status', 'active')->count() }}</span>
                                @endif
                            </button>
                        </li>
                        {{-- Module 11: a real link (not a tab toggle) to the
                             dedicated Complete History page — kept in the
                             same nav-tabs strip, styled identically, so the
                             profile itself isn't redesigned. --}}
                        <li class="nav-item" role="presentation">
                            <a href="{{ route('admin.reptiles.history', $reptile) }}" class="nav-link" role="tab">
                                <i class="bx bx-history me-1"></i> Complete History
                            </a>
                        </li>
                        {{-- Module 12: same pattern — a real link, not a tab, to
                             the server-generated PDF of this reptile's Complete
                             History. --}}
                        <li class="nav-item" role="presentation">
                            <a href="{{ route('admin.reptiles.history.pdf', $reptile) }}" class="nav-link" role="tab">
                                <i class="bx bx-printer me-1"></i> Print PDF
                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link disabled" type="button" role="tab" tabindex="-1" aria-disabled="true"
                                title="Coming in a future module">
                                <i class="bx bx-printer me-1"></i> Print PDF
                            </button>
                        </li>
                    </ul>
                </div>
                <div class="card-body tab-content">

                    <div class="tab-pane fade show active" id="tab-feeding" role="tabpanel">
                        @if ($feedingRecords->isEmpty())
                            <div class="text-center text-muted py-4">
                                No feeding records yet for {{ $reptile->name }}.
                            </div>
                        @else
                            @if ($highlightPoorGainIds->isNotEmpty())
                                <div class="alert alert-danger d-flex align-items-center mb-3" role="alert">
                                    <i class="bx bx-error-circle me-2"></i>
                                    <div>
                                        {{ $reptile->name }} has not shown proper weight gain during the last three feeding
                                        records (highlighted below). {{ \App\Models\FeedingRecord::ALERT_MESSAGE }}
                                    </div>
                                </div>
                            @endif

                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <h6 class="mb-0">Feeding History &amp; Weight Tracking</h6>
                                <a href="{{ route('admin.feeding-records.index', ['reptile_id' => $reptile->id]) }}" class="btn btn-sm btn-outline-primary">View All</a>
                            </div>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Date</th><th>Food</th><th>Quantity</th>
                                            <th>Before</th><th>After</th><th>After Defecation</th>
                                            <th>Weight Change</th><th>Trend</th><th>Alert</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        @foreach ($feedingRecords as $record)
                                            <tr class="{{ $highlightPoorGainIds->contains($record->id) ? 'table-danger' : '' }}">
                                                <td>{{ $record->feeding_date->format('M d, Y g:i A') }}</td>
                                                <td>{{ $record->foodType->parent ? $record->foodType->parent->name . ' → ' . $record->foodType->name : $record->foodType->name }}</td>
                                                <td>{{ rtrim(rtrim($record->quantity, '0'), '.') }} {{ \App\Models\FeedingSchedule::QUANTITY_UNITS[$record->quantity_unit] ?? $record->quantity_unit }}</td>
                                                <td>{{ $record->weight_before }} g</td>
                                                <td>{{ $record->weight_after }} g</td>
                                                <td>{{ $record->weight_after_defecation !== null ? $record->weight_after_defecation.' g' : '—' }}</td>
                                                <td>
                                                    @if ($record->weight_change !== null)
                                                        <span class="{{ $record->weight_change > 0 ? 'text-success' : ($record->weight_change < 0 ? 'text-danger' : '') }}">
                                                            {{ $record->weight_change > 0 ? '+' : '' }}{{ $record->weight_change }} g
                                                        </span>
                                                    @else
                                                        <span class="text-muted">—</span>
                                                    @endif
                                                </td>
                                                <td>@include('admin.feeding-records._trend_badge', ['trend' => $record->weight_trend])</td>
                                                <td>@include('admin.feeding-records._alert_badge', ['alertTriggered' => $record->weight_alert_triggered, 'alertMessage' => $record->weight_alert_message])</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>

                    <div class="tab-pane fade" id="tab-shedding" role="tabpanel">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <h6 class="mb-0">Shedding History</h6>
                            <a href="{{ route('admin.shedding-records.index', ['reptile_id' => $reptile->id]) }}" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>

                        @if ($sheddingRecords->isEmpty())
                            <div class="text-center text-muted py-4">
                                No shedding records yet for {{ $reptile->name }}.
                            </div>
                        @else
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Date</th><th>Status</th><th>Notes</th><th>Observations</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        @foreach ($sheddingRecords as $record)
                                            <tr>
                                                <td>{{ $record->shedding_date->format('M d, Y') }}</td>
                                                <td>@include('admin.shedding-records._status_badge', ['status' => $record->status])</td>
                                                <td>{{ $record->notes ?? '—' }}</td>
                                                <td>{{ $record->observations ?? '—' }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>

                    <div class="tab-pane fade" id="tab-medical" role="tabpanel">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <h6 class="mb-0">Medical History</h6>
                            <a href="{{ route('admin.medical-records.index', ['reptile_id' => $reptile->id]) }}" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>

                        @if ($medicalRecords->isEmpty())
                            <div class="text-center text-muted py-4">
                                No medical records yet for {{ $reptile->name }}.
                            </div>
                        @else
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Treatment Date</th><th>Symptoms / Condition</th><th>Medicine</th>
                                            <th>Dosage</th><th>Veterinarian</th><th>Prescription</th><th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        @foreach ($medicalRecords as $record)
                                            <tr>
                                                <td>{{ $record->treatment_date->format('M d, Y') }}</td>
                                                <td>{{ \Illuminate\Support\Str::limit($record->symptoms_or_condition, 60) }}</td>
                                                <td>{{ $record->medicine_name ?? '—' }}</td>
                                                <td>{{ $record->dosage ?? '—' }}</td>
                                                <td>{{ $record->veterinarian_name ?? '—' }}</td>
                                                <td>
                                                    @if ($record->hasPrescription())
                                                        <a href="{{ route('admin.medical-records.prescription', $record) }}" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                                                    @else
                                                        <span class="text-muted">—</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <x-admin.action-menu>
                                                        <a href="{{ route('admin.medical-records.show', $record) }}" class="dropdown-item">
                                                            <i class="bx bx-show"></i> View
                                                        </a>
                                                        <a href="{{ route('admin.medical-records.edit', $record) }}" class="dropdown-item">
                                                            <i class="bx bx-edit-alt"></i> Edit
                                                        </a>
                                                        @if (auth()->user()?->isAdmin())
                                                            <form action="{{ route('admin.medical-records.destroy', $record) }}" method="POST"
                                                                onsubmit="return confirm('Delete this medical record? This cannot be undone.');">
                                                                @csrf
                                                                @method('DELETE')
                                                                <button type="submit" class="dropdown-item text-danger">
                                                                    <i class="bx bx-trash"></i> Delete
                                                                </button>
                                                            </form>
                                                        @endif
                                                    </x-admin.action-menu>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>

                    <div class="tab-pane fade" id="tab-health-alerts" role="tabpanel">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <h6 class="mb-0">Health Alerts</h6>
                            <a href="{{ route('admin.health-alerts.index', ['reptile_id' => $reptile->id]) }}" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>

                        @if ($healthAlerts->isEmpty())
                            <div class="text-center text-muted py-4">
                                No health alerts yet for {{ $reptile->name }}.
                            </div>
                        @else
                            @foreach ($healthAlerts->where('status', 'active') as $activeAlert)
                                <div class="alert alert-danger d-flex align-items-center justify-content-between mb-3" role="alert">
                                    <div class="d-flex align-items-center">
                                        <i class="bx bx-error-circle me-2"></i>
                                        <div>
                                            <strong>{{ $activeAlert->title }}</strong>
                                            <div class="small">{{ $activeAlert->message }}</div>
                                            <div class="small text-muted">Triggered: {{ $activeAlert->triggered_at->format('d M Y') }}</div>
                                        </div>
                                    </div>
                                    <a href="{{ route('admin.health-alerts.show', $activeAlert) }}" class="btn btn-sm btn-outline-danger">View Alert</a>
                                </div>
                            @endforeach

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Triggered</th><th>Title</th><th>Severity</th><th>Status</th><th>Source</th><th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        @foreach ($healthAlerts as $alert)
                                            <tr>
                                                <td>{{ $alert->triggered_at->format('M d, Y g:i A') }}</td>
                                                <td>{{ $alert->title }}</td>
                                                <td>@include('admin.health-alerts._severity_badge', ['severity' => $alert->severity])</td>
                                                <td>@include('admin.health-alerts._status_badge', ['status' => $alert->status])</td>
                                                <td>{{ \App\Models\HealthAlert::SOURCES[$alert->source] ?? ucfirst($alert->source) }}</td>
                                                <td>
                                                    <a href="{{ route('admin.health-alerts.show', $alert) }}" class="btn btn-sm btn-outline-primary">View</a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
