@extends('admin.layouts.master')

@section('title', 'Add Reptile')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.index') }}">Reptiles</a></li>
            <li class="breadcrumb-item active">Add Reptile</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Add Reptile</h4>

    <div class="card">
        <div class="card-body">
            @include('admin.reptiles._form')
        </div>
    </div>
</div>
@endsection
