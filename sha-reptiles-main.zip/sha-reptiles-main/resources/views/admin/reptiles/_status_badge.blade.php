@php
    $statusBadgeClasses = [
        'active' => 'bg-label-success',
        'inactive' => 'bg-label-secondary',
        'transferred' => 'bg-label-info',
        'sold' => 'bg-label-warning',
        'deceased' => 'bg-label-dark',
    ];
@endphp
<span class="badge {{ $statusBadgeClasses[$status] ?? 'bg-label-secondary' }}">
    {{ \App\Models\Reptile::STATUSES[$status] ?? ucfirst($status) }}
</span>
