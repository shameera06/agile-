@extends('admin.layouts.master')

@section('title', 'AI Reptile Assistant')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.show', $reptile) }}">{{ $reptile->name }}</a></li>
            <li class="breadcrumb-item active">AI Assistant</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">AI Reptile Assistant</h4>
        <a href="{{ route('admin.reptiles.show', $reptile) }}" class="btn btn-outline-primary">
            <i class="bx bx-arrow-back me-1"></i> Back to Reptile Details
        </a>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-body d-flex flex-wrap align-items-center gap-3">
                    @if ($reptile->photo_url)
                        <img src="{{ $reptile->photo_url }}" alt="{{ $reptile->name }}" class="rounded" style="width: 64px; height: 64px; object-fit: cover;" />
                    @else
                        <span class="avatar-initial rounded bg-label-secondary d-inline-flex" style="width: 64px; height: 64px; font-size: 1.5rem;">
                            <i class="bx bx-image d-flex align-items-center justify-content-center w-100 h-100"></i>
                        </span>
                    @endif
                    <div>
                        <h5 class="mb-0">{{ $reptile->name }}</h5>
                        <p class="text-muted mb-1">{{ $reptile->reptile_code }}</p>
                        <div class="d-flex flex-wrap gap-1">
                            @if ($reptile->species?->category)
                                <span class="badge bg-label-primary">{{ $reptile->species->category->name }}</span>
                            @endif
                            <span class="badge bg-label-info">{{ $reptile->species->name }}</span>
                            @if ($reptile->variety)
                                <span class="badge bg-label-warning">{{ $reptile->variety->name }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title m-0">Ask about {{ $reptile->name }}</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info d-flex align-items-start" role="alert">
                        <i class="bx bx-info-circle me-2 mt-1"></i>
                        <div>
                            This assistant only explains information already recorded for {{ $reptile->name }}. It does not
                            diagnose conditions, prescribe medication, or replace a qualified veterinarian.
                        </div>
                    </div>

                    <form id="ai-assistant-form">
                        @csrf
                        <div class="mb-3">
                            <label for="ai-question" class="form-label">Ask something about this reptile...</label>
                            <textarea
                                id="ai-question"
                                name="question"
                                class="form-control"
                                rows="3"
                                maxlength="1000"
                                placeholder="e.g. Is this reptile gaining weight properly?"
                                required
                            ></textarea>
                        </div>

                        <div class="mb-3">
                            <div class="mb-2 text-muted small">Suggested questions:</div>
                            <div class="d-flex flex-wrap gap-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Give me a summary of this reptile</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">How has the weight changed recently?</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Summarize the last 30 days</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Summarize the feeding history</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Summarize the shedding history</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Summarize the medical history</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Are there any recent health alerts?</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary ai-example-question">Prepare a short summary I can share with a veterinarian</button>
                            </div>
                        </div>

                        <button type="submit" id="ai-ask-button" class="btn btn-primary">
                            <i class="bx bx-send me-1"></i> Ask AI
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="card" id="ai-response-card" style="display: none;">
                <div class="card-header">
                    <h5 class="card-title m-0">AI Response</h5>
                </div>
                <div class="card-body">
                    <div id="ai-conversation"></div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('page-scripts')
<script>
    (function () {
        const form = document.getElementById('ai-assistant-form');
        const questionField = document.getElementById('ai-question');
        const askButton = document.getElementById('ai-ask-button');
        const responseCard = document.getElementById('ai-response-card');
        const conversation = document.getElementById('ai-conversation');
        const askUrl = @json(route('admin.reptiles.ai-assistant.ask', $reptile));
        const csrfToken = form.querySelector('input[name="_token"]').value;

        document.querySelectorAll('.ai-example-question').forEach(function (button) {
            button.addEventListener('click', function () {
                questionField.value = button.textContent.trim();
                questionField.focus();
            });
        });

        function appendEntry(question, html, isError) {
            responseCard.style.display = '';

            const entry = document.createElement('div');
            entry.className = 'mb-4';

            const questionEl = document.createElement('div');
            questionEl.className = 'fw-semibold mb-1';
            questionEl.textContent = 'You: ' + question;

            const answerEl = document.createElement('div');
            answerEl.className = isError ? 'alert alert-warning mb-0' : 'ai-answer';
            if (isError) {
                answerEl.textContent = html;
            } else {
                answerEl.style.whiteSpace = 'pre-line';
                answerEl.textContent = html;
            }

            entry.appendChild(questionEl);
            entry.appendChild(answerEl);
            conversation.prepend(entry);
        }

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const question = questionField.value.trim();
            if (question === '' || askButton.disabled) {
                return;
            }

            askButton.disabled = true;
            const originalLabel = askButton.innerHTML;
            askButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Analyzing reptile records...';

            fetch(askUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify({ question: question }),
            })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { ok: response.ok, data: data };
                    });
                })
                .then(function (result) {
                    if (result.ok) {
                        appendEntry(question, result.data.answer, false);
                        questionField.value = '';
                    } else {
                        appendEntry(question, result.data.message || 'AI Assistant is currently unavailable. Please try again later.', true);
                    }
                })
                .catch(function () {
                    appendEntry(question, 'AI Assistant is currently unavailable. Please try again later.', true);
                })
                .finally(function () {
                    askButton.disabled = false;
                    askButton.innerHTML = originalLabel;
                });
        });
    })();
</script>
@endpush
