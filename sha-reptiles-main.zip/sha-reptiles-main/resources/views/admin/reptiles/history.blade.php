@extends('admin.layouts.master')

@section('title', 'Complete History')

@push('page-styles')
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css') }}" />
@endpush

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            @if ($reptile->species?->category)
                <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.species.category', $reptile->species->category) }}">{{ $reptile->species->category->name }}</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.species.type', $reptile->species) }}">{{ $reptile->species->name }}</a></li>
                @if ($reptile->variety)
                    <li class="breadcrumb-item"><a href="{{ route('admin.species.variety', [$reptile->species, $reptile->variety]) }}">{{ $reptile->variety->name }}</a></li>
                @endif
            @else
                <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.index') }}">Reptiles</a></li>
            @endif
            <li class="breadcrumb-item"><a href="{{ route('admin.reptiles.show', $reptile) }}">{{ $reptile->name }}</a></li>
            <li class="breadcrumb-item active">Complete History</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <div>
            <h4 class="fw-bold mb-1">{{ $reptile->name }} — Complete History</h4>
            <p class="text-muted mb-0">A complete, read-only historical view. Use each section's View/Edit link to open the original record.</p>
        </div>
        <div class="d-flex gap-2">
            {{-- Module 12: server-generated PDF of this same page's data —
                 see ReptileHistoryController::pdf() / ReptileHistoryService. --}}
            <a href="{{ route('admin.reptiles.history.pdf', $reptile) }}" class="btn btn-outline-primary">
                <i class="bx bx-printer me-1"></i> Print PDF
            </a>
            <a href="{{ route('admin.reptiles.show', $reptile) }}" class="btn btn-outline-secondary">
                <i class="bx bx-arrow-back me-1"></i> Back to Profile
            </a>
        </div>
    </div>

    {{-- Prominent active alerts — displayed, never generated, here. --}}
    @foreach ($activeHealthAlerts as $activeAlert)
        <div class="alert alert-danger d-flex align-items-center justify-content-between mb-3" role="alert">
            <div class="d-flex align-items-center">
                <i class="bx bx-error-circle me-2"></i>
                <div>
                    <strong>{{ strtoupper($activeAlert->title) }}</strong>
                    <div class="small">{{ $activeAlert->message }}</div>
                </div>
            </div>
            <a href="{{ route('admin.health-alerts.show', $activeAlert) }}" class="btn btn-sm btn-outline-danger">View Alert</a>
        </div>
    @endforeach

    <div class="row">
        <div class="col-md-4 col-lg-3 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    @if ($reptile->photo_url)
                        <img src="{{ $reptile->photo_url }}" alt="{{ $reptile->name }}" class="rounded mb-3" style="width: 140px; height: 140px; object-fit: cover;" />
                    @else
                        <span class="avatar-initial rounded bg-label-secondary d-inline-flex mb-3" style="width: 140px; height: 140px; font-size: 3rem;">
                            <i class="bx bx-image d-flex align-items-center justify-content-center w-100 h-100"></i>
                        </span>
                    @endif
                    <h5 class="mb-1">{{ $reptile->name }}</h5>
                    <p class="text-muted mb-2">{{ $reptile->reptile_code }}</p>
                    <div class="d-flex flex-wrap justify-content-center gap-1 mb-2">
                        @if ($reptile->species?->category)
                            <span class="badge bg-label-primary">{{ $reptile->species->category->name }}</span>
                        @endif
                        <span class="badge bg-label-info">{{ $reptile->species->name }}</span>
                        @if ($reptile->variety)
                            <span class="badge bg-label-warning">{{ $reptile->variety->name }}</span>
                        @endif
                    </div>
                    @include('admin.reptiles._status_badge', ['status' => $reptile->status])
                </div>
            </div>
        </div>

        <div class="col-md-8 col-lg-9 mb-4">
            <div class="row h-100">
                <div class="col-sm-6 col-lg-3 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">Current Weight</span>
                            <h4 class="mb-0">{{ $currentHealthStatus['currentWeight'] !== null ? $currentHealthStatus['currentWeight'].' '.$currentHealthStatus['weightUnit'] : '—' }}</h4>
                            <small class="text-muted">
                                @if ($currentHealthStatus['recentWeightTrend'])
                                    @include('admin.feeding-records._trend_badge', ['trend' => $currentHealthStatus['recentWeightTrend']])
                                @else
                                    No trend yet
                                @endif
                            </small>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">Feeding Records</span>
                            <h4 class="mb-0">{{ $counts['totalFeedingRecords'] }}</h4>
                            <small class="text-muted">Total recorded</small>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">Shedding Records</span>
                            <h4 class="mb-0">{{ $counts['totalSheddingRecords'] }}</h4>
                            <small class="text-muted">Total recorded</small>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">Medical Records</span>
                            <h4 class="mb-0">{{ $counts['totalMedicalRecords'] }}</h4>
                            <small class="text-muted">Total recorded</small>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">Health Alerts</span>
                            <h4 class="mb-0 {{ $counts['activeHealthAlerts'] > 0 ? 'text-danger' : '' }}">{{ $counts['totalHealthAlerts'] }}</h4>
                            <small class="{{ $counts['activeHealthAlerts'] > 0 ? 'text-danger fw-semibold' : 'text-muted' }}">
                                {{ $counts['activeHealthAlerts'] }} active
                            </small>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">Sex</span>
                            <h4 class="mb-0">{{ \App\Models\Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex) }}</h4>
                            <small class="text-muted">Status: {{ \App\Models\Reptile::STATUSES[$reptile->status] ?? ucfirst($reptile->status) }}</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-overview" type="button" role="tab">
                                <i class="bx bx-info-circle me-1"></i> Overview
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-weight-feeding" type="button" role="tab">
                                <i class="bx bx-restaurant me-1"></i> Weight &amp; Feeding History
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-shedding" type="button" role="tab">
                                <i class="bx bx-refresh me-1"></i> Shedding History
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-medical" type="button" role="tab">
                                <i class="bx bx-plus-medical me-1"></i> Medical History
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-health-alerts" type="button" role="tab">
                                <i class="bx bx-error-circle me-1"></i> Health Alerts
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-observations" type="button" role="tab">
                                <i class="bx bx-note me-1"></i> Observations
                            </button>
                        </li>
                    </ul>
                </div>
                <div class="card-body tab-content">

                    {{-- Overview: birth/basic info + a compact "latest records" summary. --}}
                    <div class="tab-pane fade show active" id="tab-overview" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Basic / Birth Information</h6>
                                <table class="table table-borderless table-sm mb-4">
                                    <tbody>
                                        <tr><th class="text-muted" style="width: 180px;">Animal Name</th><td>{{ $reptile->name }}</td></tr>
                                        <tr><th class="text-muted">Animal ID</th><td>{{ $reptile->reptile_code }}</td></tr>
                                        <tr><th class="text-muted">Category</th><td>{{ $reptile->species?->category?->name ?? '—' }}</td></tr>
                                        <tr><th class="text-muted">Species Type</th><td>{{ $reptile->species->name }}</td></tr>
                                        <tr><th class="text-muted">Variety / Morph</th><td>{{ $reptile->variety?->name ?? '—' }}</td></tr>
                                        <tr><th class="text-muted">Sex</th><td>{{ \App\Models\Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex) }}</td></tr>
                                        <tr><th class="text-muted">Date of Birth / Hatch Date</th><td>{{ optional($reptile->date_of_birth)->format('M d, Y') ?? 'Not recorded' }}</td></tr>
                                        <tr><th class="text-muted">Acquisition Date</th><td>{{ optional($reptile->acquisition_date)->format('M d, Y') ?? 'Not recorded' }}</td></tr>
                                        <tr><th class="text-muted">Current Weight</th><td>{{ $currentHealthStatus['currentWeight'] !== null ? $currentHealthStatus['currentWeight'].' '.$currentHealthStatus['weightUnit'] : 'Not recorded' }}</td></tr>
                                        <tr><th class="text-muted">Status</th><td>@include('admin.reptiles._status_badge', ['status' => $reptile->status])</td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h6>Latest Records</h6>
                                <ul class="list-unstyled">
                                    <li class="mb-3">
                                        <strong>Last Feeding:</strong>
                                        @if ($latestRecords['feeding'])
                                            {{ $latestRecords['feeding']->feeding_date->format('M d, Y') }} —
                                            {{ $latestRecords['feeding']->foodType->name }}
                                            @include('admin.feeding-records._trend_badge', ['trend' => $latestRecords['feeding']->weight_trend])
                                        @else
                                            <span class="text-muted">No feeding records found.</span>
                                        @endif
                                    </li>
                                    <li class="mb-3">
                                        <strong>Last Shedding:</strong>
                                        @if ($latestRecords['shedding'])
                                            {{ $latestRecords['shedding']->shedding_date->format('M d, Y') }} —
                                            @include('admin.shedding-records._status_badge', ['status' => $latestRecords['shedding']->status])
                                        @else
                                            <span class="text-muted">No shedding records found.</span>
                                        @endif
                                    </li>
                                    <li class="mb-3">
                                        <strong>Last Medical Record:</strong>
                                        @if ($latestRecords['medical'])
                                            {{ $latestRecords['medical']->treatment_date->format('M d, Y') }} —
                                            {{ \Illuminate\Support\Str::limit($latestRecords['medical']->symptoms_or_condition, 40) }}
                                        @else
                                            <span class="text-muted">No medical records found.</span>
                                        @endif
                                    </li>
                                    <li class="mb-3">
                                        <strong>Last Health Alert:</strong>
                                        @if ($latestRecords['healthAlert'])
                                            {{ $latestRecords['healthAlert']->triggered_at->format('M d, Y') }} —
                                            {{ $latestRecords['healthAlert']->title }}
                                            @include('admin.health-alerts._status_badge', ['status' => $latestRecords['healthAlert']->status])
                                        @else
                                            <span class="text-muted">No health alerts found.</span>
                                        @endif
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="tab-weight-feeding" role="tabpanel">
                        @if ($highlightedFeedingIds->isNotEmpty())
                            <div class="alert alert-danger d-flex align-items-center mb-3" role="alert">
                                <i class="bx bx-error-circle me-2"></i>
                                <div>The latest three feeding records (highlighted below) all show no gain/loss — see {{ \App\Models\FeedingRecord::ALERT_MESSAGE }}</div>
                            </div>
                        @endif
                        <div class="table-responsive">
                            {!! $feedingDataTable->table(['class' => 'table']) !!}
                        </div>
                    </div>

                    <div class="tab-pane fade" id="tab-shedding" role="tabpanel">
                        <div class="table-responsive">
                            {!! $sheddingDataTable->table(['class' => 'table']) !!}
                        </div>
                    </div>

                    <div class="tab-pane fade" id="tab-medical" role="tabpanel">
                        <div class="table-responsive">
                            {!! $medicalDataTable->table(['class' => 'table']) !!}
                        </div>
                    </div>

                    <div class="tab-pane fade" id="tab-health-alerts" role="tabpanel">
                        <div class="table-responsive">
                            {!! $healthAlertDataTable->table(['class' => 'table']) !!}
                        </div>
                    </div>

                    <div class="tab-pane fade" id="tab-observations" role="tabpanel">
                        <h6>Important Observations</h6>
                        <p class="mb-0">{{ $reptile->notes ?? 'No observations recorded.' }}</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('page-scripts')
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.js') }}"></script>
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.js') }}"></script>
{!! $feedingDataTable->scripts() !!}
{!! $sheddingDataTable->scripts() !!}
{!! $medicalDataTable->scripts() !!}
{!! $healthAlertDataTable->scripts() !!}

<script>
    // All four DataTables above sit inside Bootstrap tab-panes that are
    // hidden (display: none) on page load — only "Overview" starts shown.
    // A DataTable initialized while hidden computes zero-width columns, so
    // each one is re-adjusted the moment its own tab is actually revealed.
    // Plain Bootstrap 5 + jQuery — no new library.
    document.querySelectorAll('[data-bs-toggle="tab"]').forEach(function (tabButton) {
        tabButton.addEventListener('shown.bs.tab', function () {
            var pane = document.querySelector(tabButton.getAttribute('data-bs-target'));
            var $table = pane && window.jQuery ? window.jQuery(pane).find('table.dataTable') : null;

            if ($table && $table.length && window.jQuery.fn.DataTable.isDataTable($table[0])) {
                $table.DataTable().columns.adjust().draw(false);
            }
        });
    });
</script>
@endpush
