@php
    $isEdit = $reptile->exists;
    $action = $isEdit ? route('admin.reptiles.update', $reptile) : route('admin.reptiles.store');
@endphp

<form method="POST" action="{{ $action }}" enctype="multipart/form-data">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row mb-4">
        <div class="col-md-3 text-center">
            @if ($isEdit && $reptile->photo_url)
                <img src="{{ $reptile->photo_url }}" alt="{{ $reptile->name }}" class="rounded mb-2" style="width: 140px; height: 140px; object-fit: cover;" />
            @else
                <span class="avatar-initial rounded bg-label-secondary d-inline-flex mb-2" style="width: 140px; height: 140px; font-size: 3rem;">
                    <i class="bx bx-image d-flex align-items-center justify-content-center w-100 h-100"></i>
                </span>
            @endif
        </div>
        <div class="col-md-9">
            <label for="photo" class="form-label">Photo</label>
            <input
                type="file"
                id="photo"
                name="photo"
                class="form-control @error('photo') is-invalid @enderror"
                accept="image/jpeg,image/png,image/webp"
            />
            <small class="text-muted d-block mt-1">JPG, PNG or WEBP. Max 5 MB.</small>
            @error('photo')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Name *</label>
            <input
                type="text"
                id="name"
                name="name"
                class="form-control @error('name') is-invalid @enderror"
                placeholder="e.g. Rocky"
                value="{{ old('name', $reptile->name) }}"
                autofocus
            />
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="species_id" class="form-label">Species *</label>
            <select id="species_id" name="species_id" class="form-select @error('species_id') is-invalid @enderror">
                <option value="">Select a species</option>
                @foreach ($speciesOptions as $option)
                    <option value="{{ $option->id }}" @selected((int) old('species_id', $reptile->species_id) === $option->id)>
                        {{ $option->name }}{{ ! $option->status ? ' (inactive)' : '' }}
                    </option>
                @endforeach
            </select>
            @error('species_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="species_variety_id" class="form-label">Variety / Morph</label>
            <select id="species_variety_id" name="species_variety_id" class="form-select @error('species_variety_id') is-invalid @enderror">
                <option value="">Unassigned</option>
                @foreach ($varietyOptions as $option)
                    <option
                        value="{{ $option->id }}"
                        data-species-id="{{ $option->species_id }}"
                        @selected((int) old('species_variety_id', $reptile->species_variety_id) === $option->id)
                    >
                        {{ $option->name }}{{ ! $option->status ? ' (inactive)' : '' }}
                    </option>
                @endforeach
            </select>
            <small class="text-muted d-block mt-1">Options are filtered to the selected Species above. Optional — leave Unassigned if this reptile isn't registered under a variety yet.</small>
            @error('species_variety_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-3">
            <label for="sex" class="form-label">Sex *</label>
            <select id="sex" name="sex" class="form-select @error('sex') is-invalid @enderror">
                @foreach (\App\Models\Reptile::SEXES as $value => $label)
                    <option value="{{ $value }}" @selected(old('sex', $reptile->sex) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('sex')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-4 mb-3">
            <label for="date_of_birth" class="form-label">Date of Birth</label>
            <input
                type="date"
                id="date_of_birth"
                name="date_of_birth"
                class="form-control @error('date_of_birth') is-invalid @enderror"
                max="{{ now()->toDateString() }}"
                value="{{ old('date_of_birth', optional($reptile->date_of_birth)->toDateString()) }}"
            />
            @error('date_of_birth')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-4 mb-3">
            <label for="status" class="form-label">Status *</label>
            <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
                @foreach (\App\Models\Reptile::STATUSES as $value => $label)
                    <option value="{{ $value }}" @selected(old('status', $reptile->status) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('status')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="acquisition_date" class="form-label">Acquisition Date</label>
            <input
                type="date"
                id="acquisition_date"
                name="acquisition_date"
                class="form-control @error('acquisition_date') is-invalid @enderror"
                max="{{ now()->toDateString() }}"
                value="{{ old('acquisition_date', optional($reptile->acquisition_date)->toDateString()) }}"
            />
            @error('acquisition_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="acquisition_source" class="form-label">Acquisition Source</label>
            <input
                type="text"
                id="acquisition_source"
                name="acquisition_source"
                class="form-control @error('acquisition_source') is-invalid @enderror"
                placeholder="e.g. Breeder, Pet Store, Rescue"
                value="{{ old('acquisition_source', $reptile->acquisition_source) }}"
            />
            @error('acquisition_source')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-3 mb-3">
            <label for="current_weight" class="form-label">Current Weight</label>
            <input
                type="number"
                step="0.01"
                min="0"
                id="current_weight"
                name="current_weight"
                class="form-control @error('current_weight') is-invalid @enderror"
                value="{{ old('current_weight', $reptile->current_weight) }}"
            />
            @error('current_weight')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="weight_unit" class="form-label">Weight Unit</label>
            <select id="weight_unit" name="weight_unit" class="form-select @error('weight_unit') is-invalid @enderror">
                @foreach (\App\Models\Reptile::WEIGHT_UNITS as $value => $label)
                    <option value="{{ $value }}" @selected(old('weight_unit', $reptile->weight_unit ?? 'g') === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('weight_unit')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="length" class="form-label">Length</label>
            <input
                type="number"
                step="0.01"
                min="0"
                id="length"
                name="length"
                class="form-control @error('length') is-invalid @enderror"
                value="{{ old('length', $reptile->length) }}"
            />
            @error('length')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="length_unit" class="form-label">Length Unit</label>
            <select id="length_unit" name="length_unit" class="form-select @error('length_unit') is-invalid @enderror">
                @foreach (\App\Models\Reptile::LENGTH_UNITS as $value => $label)
                    <option value="{{ $value }}" @selected(old('length_unit', $reptile->length_unit ?? 'cm') === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('length_unit')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-4">
        <label for="notes" class="form-label">Notes</label>
        <textarea
            id="notes"
            name="notes"
            rows="4"
            class="form-control @error('notes') is-invalid @enderror"
            placeholder="e.g. Very active and handles well."
        >{{ old('notes', $reptile->notes) }}</textarea>
        @error('notes')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Reptile</button>
    <a href="{{ route('admin.reptiles.index') }}" class="btn btn-outline-secondary">Cancel</a>
</form>

<script>
    // Plain vanilla JS (no framework): show only the Varieties belonging to
    // whichever Species is currently selected, and clear the Variety pick
    // whenever it no longer matches. Runs once on load too, so a validation
    // reload or a pre-filled edit form starts filtered correctly.
    (function () {
        var speciesSelect = document.getElementById('species_id');
        var varietySelect = document.getElementById('species_variety_id');

        if (!speciesSelect || !varietySelect) {
            return;
        }

        var allOptions = Array.prototype.slice.call(varietySelect.options);

        function applyFilter() {
            var speciesId = speciesSelect.value;
            var previousValue = varietySelect.value;

            varietySelect.innerHTML = '';

            allOptions.forEach(function (option) {
                var optionSpeciesId = option.getAttribute('data-species-id');

                if (!optionSpeciesId || optionSpeciesId === speciesId) {
                    varietySelect.appendChild(option);
                }
            });

            if (Array.prototype.slice.call(varietySelect.options).some(function (o) { return o.value === previousValue; })) {
                varietySelect.value = previousValue;
            } else {
                varietySelect.value = '';
            }
        }

        speciesSelect.addEventListener('change', applyFilter);
        applyFilter();
    })();
</script>
