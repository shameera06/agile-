<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{{ $reptile->name }} — Complete History</title>
<style>
    /*
     * Module 12 — dedicated PDF stylesheet. Deliberately self-contained
     * (no Bootstrap/app CSS): dompdf renders a fixed HTML/CSS subset, so
     * this view never relies on the browser-only styling the on-screen
     * Complete History page (admin.reptiles.history) uses.
     */
    @page {
        margin: 30px 36px 70px 36px;
    }

    * { box-sizing: border-box; }

    body {
        font-family: 'Helvetica', 'Arial', sans-serif;
        font-size: 10px;
        color: #1d2939;
    }

    h1, h2, h3 { margin: 0 0 6px 0; }

    .doc-title {
        text-align: center;
        font-size: 20px;
        font-weight: bold;
        letter-spacing: 1px;
        color: #2b2d42;
        border-bottom: 2px solid #2b2d42;
        padding-bottom: 8px;
        margin-bottom: 14px;
    }

    .section-title {
        font-size: 13px;
        font-weight: bold;
        color: #fff;
        background-color: #405189;
        padding: 5px 8px;
        margin: 16px 0 8px 0;
    }

    .page-break { page-break-before: always; }

    /* Identification header block */
    .identity-wrap { width: 100%; margin-bottom: 4px; }
    .identity-photo-cell { width: 110px; vertical-align: top; }
    .identity-photo {
        width: 100px; height: 100px; object-fit: cover;
        border: 1px solid #d0d5dd;
    }
    .identity-photo-placeholder {
        width: 100px; height: 100px; border: 1px dashed #d0d5dd;
        text-align: center; vertical-align: middle; color: #98a2b3; font-size: 9px;
    }
    .identity-table { width: 100%; border-collapse: collapse; }
    .identity-table td { padding: 3px 6px; vertical-align: top; }
    .identity-label { color: #667085; font-size: 9px; text-transform: uppercase; }
    .identity-value { font-size: 12px; font-weight: bold; color: #101828; }

    table.data-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 10px;
        table-layout: fixed;
    }
    table.data-table th, table.data-table td {
        border: 1px solid #d0d5dd;
        padding: 4px 5px;
        font-size: 8.5px;
        text-align: left;
        word-wrap: break-word;
        overflow-wrap: break-word;
    }
    table.data-table thead th {
        background-color: #eef1f8;
        color: #1d2939;
        font-weight: bold;
    }
    table.data-table tr { page-break-inside: avoid; }
    tr.row-danger td { background-color: #fdecea; }

    table.info-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 6px;
    }
    table.info-table td {
        border: 1px solid #d0d5dd;
        padding: 4px 8px;
        font-size: 9.5px;
    }
    table.info-table td.info-field {
        width: 22%;
        background-color: #f7f8fa;
        font-weight: bold;
        color: #344054;
    }

    table.summary-grid { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
    table.summary-grid td {
        border: 1px solid #d0d5dd;
        padding: 6px 8px;
        width: 16.6%;
        text-align: center;
    }
    .summary-value { font-size: 14px; font-weight: bold; color: #101828; }
    .summary-label { font-size: 8px; color: #667085; text-transform: uppercase; }

    .muted { color: #98a2b3; }

    .badge {
        display: inline-block;
        padding: 1px 6px;
        border-radius: 3px;
        font-size: 8px;
        font-weight: bold;
        color: #fff;
    }
    .badge-success { background-color: #16a34a; }
    .badge-warning { background-color: #d97706; }
    .badge-danger  { background-color: #dc2626; }
    .badge-secondary { background-color: #667085; }
    .badge-info { background-color: #0284c7; }
    .badge-dark { background-color: #1d2939; }

    .alert-box {
        border: 1.5px solid #dc2626;
        background-color: #fdecea;
        color: #7a1f1f;
        padding: 8px 10px;
        margin-bottom: 10px;
        font-size: 10px;
    }
    .alert-box strong { display: block; font-size: 11px; margin-bottom: 3px; }
</style>
</head>
<body>

@php
    /**
     * Small local label helpers — pure display formatting only, never a
     * recalculation of any Module 7-10 business rule. Every value rendered
     * below is read straight from the record/constant already provided by
     * the controller/ReptileHistoryService.
     */
    $trendBadgeClass = [
        'gain' => 'badge-success',
        'no_gain' => 'badge-warning',
        'loss' => 'badge-danger',
    ];
    $sheddingBadgeClass = [
        'complete' => 'badge-success',
        'partial' => 'badge-warning',
        'incomplete' => 'badge-danger',
        'problematic' => 'badge-dark',
    ];
    $alertStatusBadgeClass = [
        'active' => 'badge-danger',
        'resolved' => 'badge-success',
        'dismissed' => 'badge-secondary',
    ];
    $alertSeverityBadgeClass = [
        'warning' => 'badge-warning',
        'critical' => 'badge-danger',
    ];
    $reptileStatusBadgeClass = [
        'active' => 'badge-success',
        'inactive' => 'badge-secondary',
        'transferred' => 'badge-info',
        'sold' => 'badge-warning',
        'deceased' => 'badge-dark',
    ];

    $fmtDate = fn ($date, $withTime = false) => $date ? $date->format($withTime ? 'M d, Y g:i A' : 'M d, Y') : 'Not recorded';
    $fmtWeight = fn ($value) => $value !== null ? rtrim(rtrim((string) $value, '0'), '.').' '.$reptile->weight_unit : 'Not recorded';
@endphp

{{-- The footer (with real "Page X of Y" numbers) is drawn directly on the
     canvas by the controller (see addFooter()) — dompdf cannot resolve a
     real page total from CSS alone. --}}

{{-- ============================= PAGE 1 ============================= --}}

<div class="doc-title">REPTILE COMPLETE HISTORY</div>

{{-- Reptile Identification --}}
<table class="identity-wrap">
    <tr>
        @if ($photoDataUri)
            <td class="identity-photo-cell">
                <img src="{{ $photoDataUri }}" class="identity-photo" alt="Photo">
            </td>
        @else
            <td class="identity-photo-cell">
                <table><tr><td class="identity-photo-placeholder">No Photo</td></tr></table>
            </td>
        @endif
        <td>
            <table class="identity-table">
                <tr>
                    <td style="width:33%">
                        <div class="identity-label">Animal Name</div>
                        <div class="identity-value">{{ $reptile->name }}</div>
                    </td>
                    <td style="width:33%">
                        <div class="identity-label">Animal ID</div>
                        <div class="identity-value">{{ $reptile->reptile_code }}</div>
                    </td>
                    <td style="width:33%">
                        <div class="identity-label">Status</div>
                        <div class="identity-value">
                            <span class="badge {{ $reptileStatusBadgeClass[$reptile->status] ?? 'badge-secondary' }}">
                                {{ strtoupper(\App\Models\Reptile::STATUSES[$reptile->status] ?? $reptile->status) }}
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="identity-label">Category</div>
                        <div class="identity-value">{{ $reptile->species?->category?->name ?? 'Not assigned' }}</div>
                    </td>
                    <td>
                        <div class="identity-label">Species Type</div>
                        <div class="identity-value">{{ $reptile->species?->name ?? 'Not assigned' }}</div>
                    </td>
                    <td>
                        <div class="identity-label">Variety / Morph</div>
                        <div class="identity-value">{{ $reptile->variety?->name ?? 'Not assigned' }}</div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="identity-label">Current Weight</div>
                        <div class="identity-value">{{ $fmtWeight($currentHealthStatus['currentWeight']) }}</div>
                    </td>
                    <td>
                        <div class="identity-label">Sex</div>
                        <div class="identity-value">{{ \App\Models\Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex) }}</div>
                    </td>
                    <td>
                        <div class="identity-label">Generated</div>
                        <div class="identity-value">{{ $generatedAt->format('M d, Y g:i A') }}</div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

{{-- Active Health Alerts — displayed, never generated here. --}}
@foreach ($activeHealthAlerts as $activeAlert)
    <div class="alert-box">
        <strong>{{ strtoupper($activeAlert->title) }}</strong>
        {{ $activeAlert->message }}
    </div>
@endforeach

{{-- Basic Information --}}
<div class="section-title">Basic Information</div>
<table class="info-table">
    <tr><td class="info-field">Animal Name</td><td>{{ $reptile->name }}</td></tr>
    <tr><td class="info-field">Animal ID</td><td>{{ $reptile->reptile_code }}</td></tr>
    <tr><td class="info-field">Category</td><td>{{ $reptile->species?->category?->name ?? 'Not assigned' }}</td></tr>
    <tr><td class="info-field">Species Type</td><td>{{ $reptile->species?->name ?? 'Not recorded' }}</td></tr>
    <tr><td class="info-field">Variety / Morph</td><td>{{ $reptile->variety?->name ?? 'Not assigned' }}</td></tr>
    <tr><td class="info-field">Sex</td><td>{{ \App\Models\Reptile::SEXES[$reptile->sex] ?? ucfirst($reptile->sex ?? '') ?: 'Not recorded' }}</td></tr>
    <tr><td class="info-field">DOB / Hatch Date</td><td>{{ $fmtDate($reptile->date_of_birth) }}</td></tr>
    <tr><td class="info-field">Current Weight</td><td>{{ $fmtWeight($currentHealthStatus['currentWeight']) }}</td></tr>
    <tr><td class="info-field">Length</td><td>{{ $reptile->length !== null ? rtrim(rtrim((string) $reptile->length, '0'), '.').' '.$reptile->length_unit : 'Not recorded' }}</td></tr>
    <tr><td class="info-field">Status</td><td>{{ \App\Models\Reptile::STATUSES[$reptile->status] ?? ucfirst($reptile->status) }}</td></tr>
    <tr><td class="info-field">Acquisition</td><td>{{ $fmtDate($reptile->acquisition_date) }}{{ $reptile->acquisition_source ? ' — '.$reptile->acquisition_source : '' }}</td></tr>
    <tr><td class="info-field">Notes</td><td>{{ $reptile->notes ?: 'Not recorded' }}</td></tr>
</table>

{{-- History Summary --}}
<div class="section-title">History Summary</div>
<table class="summary-grid">
    <tr>
        <td>
            <div class="summary-value">{{ $counts['totalFeedingRecords'] }}</div>
            <div class="summary-label">Feeding Records</div>
        </td>
        <td>
            <div class="summary-value">{{ $counts['totalSheddingRecords'] }}</div>
            <div class="summary-label">Shedding Records</div>
        </td>
        <td>
            <div class="summary-value">{{ $counts['totalMedicalRecords'] }}</div>
            <div class="summary-label">Medical Records</div>
        </td>
        <td>
            <div class="summary-value">{{ $counts['totalHealthAlerts'] }}</div>
            <div class="summary-label">Total Health Alerts</div>
        </td>
        <td>
            <div class="summary-value">{{ $counts['activeHealthAlerts'] }}</div>
            <div class="summary-label">Active Health Alerts</div>
        </td>
        <td>
            <div class="summary-value">{{ $fmtWeight($currentHealthStatus['currentWeight']) }}</div>
            <div class="summary-label">Current Weight</div>
        </td>
    </tr>
</table>
<table class="info-table">
    <tr><td class="info-field">Last Feeding Date</td><td>{{ $latestRecords['feeding'] ? $fmtDate($latestRecords['feeding']->feeding_date) : 'No feeding records recorded.' }}</td></tr>
    <tr><td class="info-field">Last Shedding Date</td><td>{{ $latestRecords['shedding'] ? $fmtDate($latestRecords['shedding']->shedding_date) : 'No shedding records recorded.' }}</td></tr>
    <tr><td class="info-field">Last Medical Record Date</td><td>{{ $latestRecords['medical'] ? $fmtDate($latestRecords['medical']->treatment_date) : 'No medical records recorded.' }}</td></tr>
</table>

{{-- ============================= PAGE 2+ ============================= --}}

<div class="page-break"></div>

{{-- Weight History + Feeding History: Module 7 stores both under the same
     feeding_records table (see FeedingHistoryDataTable) — one combined
     section here, exactly as the on-screen Complete History page does,
     rather than a second, invented data model. --}}
<div class="section-title">Weight History &amp; Feeding History</div>

@if ($highlightedFeedingIds->isNotEmpty())
    <div class="alert-box">
        <strong>WARNING</strong>
        {{ \App\Models\FeedingRecord::ALERT_MESSAGE }}
    </div>
@endif

@if ($feedingHistory->isEmpty())
    <p class="muted">No feeding records recorded.</p>
@else
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:9%">Feeding Date</th>
                <th style="width:12%">Food Type</th>
                <th style="width:8%">Quantity</th>
                <th style="width:7%">Before</th>
                <th style="width:7%">After</th>
                <th style="width:9%">After Defecation</th>
                <th style="width:8%">Effective Weight</th>
                <th style="width:7%">Weight Change</th>
                <th style="width:7%">Weight Trend</th>
                <th style="width:26%">Notes</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($feedingHistory as $record)
                <tr class="{{ $highlightedFeedingIds->contains($record->id) ? 'row-danger' : '' }}">
                    <td>{{ $fmtDate($record->feeding_date, true) }}</td>
                    <td>
                        {{ $record->foodType?->parent ? $record->foodType->parent->name.' → ' : '' }}{{ $record->foodType?->name ?? 'Not recorded' }}
                    </td>
                    <td>{{ rtrim(rtrim((string) $record->quantity, '0'), '.') }} {{ \App\Models\FeedingSchedule::QUANTITY_UNITS[$record->quantity_unit] ?? $record->quantity_unit }}</td>
                    <td>{{ $fmtWeight($record->weight_before) }}</td>
                    <td>{{ $fmtWeight($record->weight_after) }}</td>
                    <td>{{ $fmtWeight($record->weight_after_defecation) }}</td>
                    <td>{{ $history->getEffectiveWeight($record) }} {{ $reptile->weight_unit }}</td>
                    <td>{{ $record->weight_change !== null ? ($record->weight_change > 0 ? '+' : '').$record->weight_change.' '.$reptile->weight_unit : '—' }}</td>
                    <td>
                        @if ($record->weight_trend)
                            <span class="badge {{ $trendBadgeClass[$record->weight_trend] ?? 'badge-secondary' }}">
                                {{ \App\Models\FeedingRecord::WEIGHT_TRENDS[$record->weight_trend] ?? ucfirst($record->weight_trend) }}
                            </span>
                        @else
                            <span class="muted">First Record</span>
                        @endif
                    </td>
                    <td>{{ $record->notes ?: '—' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endif

{{-- Shedding History --}}
<div class="section-title">Shedding History</div>
@if ($sheddingHistory->isEmpty())
    <p class="muted">No shedding records recorded.</p>
@else
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:12%">Shedding Date</th>
                <th style="width:12%">Status</th>
                <th style="width:30%">Notes</th>
                <th style="width:30%">Observations</th>
                <th style="width:16%">Created By</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($sheddingHistory as $record)
                <tr>
                    <td>{{ $fmtDate($record->shedding_date) }}</td>
                    <td>
                        <span class="badge {{ $sheddingBadgeClass[$record->status] ?? 'badge-secondary' }}">
                            {{ \App\Models\SheddingRecord::STATUSES[$record->status] ?? ucfirst($record->status) }}
                        </span>
                    </td>
                    <td>{{ $record->notes ?: '—' }}</td>
                    <td>{{ $record->observations ?: '—' }}</td>
                    <td>{{ $record->createdBy?->name ?? '—' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endif

{{-- Medical History + Prescription Information --}}
<div class="section-title">Medical History &amp; Prescription Information</div>
@if ($medicalHistory->isEmpty())
    <p class="muted">No medical records recorded.</p>
@else
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:8%">Treatment Date</th>
                <th style="width:15%">Symptoms / Condition</th>
                <th style="width:10%">Medicine</th>
                <th style="width:8%">Dosage</th>
                <th style="width:16%">Treatment Details</th>
                <th style="width:10%">Veterinarian</th>
                <th style="width:10%">Vet Contact</th>
                <th style="width:13%">Notes</th>
                <th style="width:10%">Prescription</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($medicalHistory as $record)
                <tr>
                    <td>{{ $fmtDate($record->treatment_date) }}</td>
                    <td>{{ $record->symptoms_or_condition ?: '—' }}</td>
                    <td>{{ $record->medicine_name ?: '—' }}</td>
                    <td>{{ $record->dosage ?: '—' }}</td>
                    <td>{{ $record->treatment_details ?: '—' }}</td>
                    <td>{{ $record->veterinarian_name ?: '—' }}</td>
                    <td>{{ $record->veterinarian_contact ?: '—' }}</td>
                    <td>{{ $record->notes ?: '—' }}</td>
                    {{-- Never the storage path/URL — only whether one is attached (see
                         MedicalRecordController::prescription(), the only authenticated
                         route allowed to actually stream the file). --}}
                    <td>{{ $record->hasPrescription() ? 'Attached' : 'Not recorded' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endif

{{-- Health Alert History --}}
<div class="section-title">Health Alert History</div>
@if ($healthAlertHistory->isEmpty())
    <p class="muted">No health alerts recorded.</p>
@else
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:7%">Alert Type</th>
                <th style="width:12%">Title</th>
                <th style="width:20%">Message</th>
                <th style="width:7%">Severity</th>
                <th style="width:7%">Status</th>
                <th style="width:10%">Triggered At</th>
                <th style="width:8%">Source</th>
                <th style="width:9%">Resolved At</th>
                <th style="width:9%">Resolved By</th>
                <th style="width:11%">Evidence</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($healthAlertHistory as $alert)
                <tr>
                    <td>{{ \App\Models\HealthAlert::ALERT_TYPES[$alert->alert_type] ?? ucfirst($alert->alert_type) }}</td>
                    <td>{{ $alert->title }}</td>
                    <td>{{ $alert->message }}</td>
                    <td>
                        <span class="badge {{ $alertSeverityBadgeClass[$alert->severity] ?? 'badge-secondary' }}">
                            {{ strtoupper(\App\Models\HealthAlert::SEVERITIES[$alert->severity] ?? $alert->severity) }}
                        </span>
                    </td>
                    <td>
                        <span class="badge {{ $alertStatusBadgeClass[$alert->status] ?? 'badge-secondary' }}">
                            {{ strtoupper(\App\Models\HealthAlert::STATUSES[$alert->status] ?? $alert->status) }}
                        </span>
                    </td>
                    <td>{{ $fmtDate($alert->triggered_at, true) }}</td>
                    <td>{{ \App\Models\HealthAlert::SOURCES[$alert->source] ?? ucfirst($alert->source) }}</td>
                    <td>{{ $alert->resolved_at ? $fmtDate($alert->resolved_at, true) : '—' }}</td>
                    <td>{{ $alert->resolvedBy?->name ?? '—' }}</td>
                    {{-- Never the storage path/URL — only whether one is attached (see
                         HealthAlertController::evidence(), the only authenticated
                         route allowed to actually stream the file). --}}
                    <td>{{ $alert->hasEvidence() ? 'Attached' : 'Not recorded' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endif

{{-- Important Observations --}}
<div class="section-title">Important Observations</div>
<p>{{ $reptile->notes ?: 'Not recorded' }}</p>

</body>
</html>
