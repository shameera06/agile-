@extends('admin.layouts.master')
@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <h4 class="fw-bold py-3 mb-1">Reptile Management Dashboard</h4>
    <p class="text-muted mb-4">Monitor your reptiles, feeding records, weight progress, and alerts.</p>

    {{-- Primary summary cards --}}
    <div class="row">
        <div class="col-sm-6 col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded bg-label-primary"><i class="bx bx-collection"></i></span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Total Reptiles</span>
                    <h3 class="card-title mb-2">{{ $totalReptiles }}</h3>
                    <small class="text-muted">All registered reptiles</small>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded bg-label-success"><i class="bx bx-check-circle"></i></span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Active Reptiles</span>
                    <h3 class="card-title mb-2">{{ $activeReptiles }}</h3>
                    <small class="text-muted">Currently active</small>
                </div>
            </div>
        </div>
    </div>

    {{-- Secondary summary cards --}}
    <div class="row">
        <div class="col-sm-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded bg-label-warning"><i class="bx bx-body"></i></span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Weight Checks Due</span>
                    <h3 class="card-title mb-2">{{ $weightChecksDue }}</h3>
                    <small class="text-muted">Reptiles due a weight check</small>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded bg-label-warning"><i class="bx bx-trending-down"></i></span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Growth Warnings</span>
                    <h3 class="card-title mb-2">{{ $growthWarnings }}</h3>
                    <small class="text-muted">Below growth target</small>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded bg-label-danger"><i class="bx bx-shield-alt"></i></span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Critical Alerts</span>
                    <h3 class="card-title mb-2">{{ $criticalAlerts }}</h3>
                    <small class="text-muted">Need immediate review</small>
                </div>
            </div>
        </div>
    </div>

    {{-- Module 10: Health Monitoring + Alerts. "Attention Required" is
         sourced from active HealthAlert records only — never a second,
         independently computed health-status algorithm. --}}
    <div class="row">
        <div class="col-sm-6 col-lg-3 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded {{ $attentionRequiredReptiles > 0 ? 'bg-label-danger' : 'bg-label-success' }}">
                                <i class="bx bx-error-circle"></i>
                            </span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Attention Required</span>
                    <h3 class="card-title mb-2 {{ $attentionRequiredReptiles > 0 ? 'text-danger' : '' }}">{{ $attentionRequiredReptiles }}</h3>
                    <small class="{{ $attentionRequiredReptiles > 0 ? 'text-danger fw-semibold' : 'text-muted' }}">
                        Reptile{{ $attentionRequiredReptiles === 1 ? '' : 's' }} with an active health alert
                    </small>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="card-title d-flex align-items-start justify-content-between">
                        <div class="avatar flex-shrink-0">
                            <span class="avatar-initial rounded {{ $activeHealthAlerts > 0 ? 'bg-label-warning' : 'bg-label-secondary' }}">
                                <i class="bx bx-bell"></i>
                            </span>
                        </div>
                    </div>
                    <span class="fw-semibold d-block mb-1">Active Health Alerts</span>
                    <h3 class="card-title mb-2">{{ $activeHealthAlerts }}</h3>
                    <small class="text-muted">
                        <a href="{{ route('admin.health-alerts.index', ['status' => 'active']) }}">View Health Alerts</a>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        {{-- Reptile Status Overview --}}
        <div class="col-12 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-between pb-0">
                    <div class="card-title mb-0">
                        <h5 class="m-0 me-2">Reptile Status Overview</h5>
                        <small class="text-muted">{{ $statusOverview['total'] }} total reptiles</small>
                    </div>
                </div>
                <div class="card-body">
                    @if ($statusOverview['total'] > 0)
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div id="reptileStatusChart"></div>
                        </div>
                        <ul class="p-0 m-0">
                            <li class="d-flex mb-4 pb-1">
                                <div class="avatar flex-shrink-0 me-3">
                                    <span class="avatar-initial rounded bg-label-success"><i class="bx bx-check-circle"></i></span>
                                </div>
                                <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Active</h6>
                                    </div>
                                    <div class="user-progress">
                                        <span class="fw-semibold">{{ $statusOverview['active']['count'] }}</span>
                                        <small class="text-muted">({{ $statusOverview['active']['percentage'] }}%)</small>
                                    </div>
                                </div>
                            </li>
                            <li class="d-flex">
                                <div class="avatar flex-shrink-0 me-3">
                                    <span class="avatar-initial rounded bg-label-secondary"><i class="bx bx-x-circle"></i></span>
                                </div>
                                <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Inactive</h6>
                                    </div>
                                    <div class="user-progress">
                                        <span class="fw-semibold">{{ $statusOverview['inactive']['count'] }}</span>
                                        <small class="text-muted">({{ $statusOverview['inactive']['percentage'] }}%)</small>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    @else
                        <div class="text-center text-muted py-4">
                            No reptiles have been added yet.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        {{-- Weight / Growth Trend --}}
        <div class="col-12 col-lg-8 mb-4">
            <div class="card h-100">
                <div class="row row-bordered g-0">
                    <div class="col-md-8">
                        <h5 class="card-header m-0 me-2 pb-3">Reptile Weight Trend</h5>
                        @if (count($weightTrend['labels']) > 0)
                            <div id="weightTrendChart" class="px-2"></div>
                        @else
                            <div class="text-center text-muted py-5">
                                No weight data recorded yet.
                            </div>
                        @endif
                    </div>
                    <div class="col-md-4">
                        <div class="card-body">
                            <h6 class="text-center mb-0">Growth Monitoring</h6>
                        </div>
                        @php $growthTotal = $growthSummary['onTarget'] + $growthSummary['belowTarget'] + $growthSummary['critical']; @endphp
                        @if ($growthTotal > 0)
                            <div id="growthGaugeChart"></div>
                        @else
                            <div class="text-center text-muted py-3">No growth data yet.</div>
                        @endif

                        <div class="d-flex flex-column px-xxl-4 px-lg-2 p-4 gap-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-label-success p-2 me-2"><i class="bx bx-check-circle text-success"></i></span>
                                    <small>On Target</small>
                                </div>
                                <h6 class="mb-0">{{ $growthSummary['onTarget'] }}</h6>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-label-warning p-2 me-2"><i class="bx bx-trending-down text-warning"></i></span>
                                    <small>Below Target</small>
                                </div>
                                <h6 class="mb-0">{{ $growthSummary['belowTarget'] }}</h6>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-label-danger p-2 me-2"><i class="bx bx-error-circle text-danger"></i></span>
                                    <small>Critical</small>
                                </div>
                                <h6 class="mb-0">{{ $growthSummary['critical'] }}</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Alerts summary --}}
        <div class="col-12 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="card-title m-0 me-2">Alerts</h5>
                </div>
                <div class="card-body">
                    @if (count($alerts['critical']) + count($alerts['warning']) + count($alerts['info']) === 0)
                        <div class="text-center text-muted py-4">
                            No alerts at this time.
                        </div>
                    @else
                        @foreach ($alerts['critical'] as $alert)
                            <a href="{{ route('admin.reptiles.show', $alert['reptile_id']) }}" class="alert alert-danger d-flex align-items-center mb-2 text-reset text-decoration-none" role="alert">
                                <i class="bx bx-shield-alt me-2"></i>
                                <div><strong>Critical:</strong> {{ $alert['message'] }}</div>
                            </a>
                        @endforeach
                        @foreach ($alerts['warning'] as $alert)
                            <a href="{{ route('admin.reptiles.show', $alert['reptile_id']) }}" class="alert alert-warning d-flex align-items-center mb-2 text-reset text-decoration-none" role="alert">
                                <i class="bx bx-error-circle me-2"></i>
                                <div><strong>Warning:</strong> {{ $alert['message'] }}</div>
                            </a>
                        @endforeach
                        @foreach ($alerts['info'] as $alert)
                            <a href="{{ route('admin.reptiles.show', $alert['reptile_id']) }}" class="alert alert-info d-flex align-items-center mb-2 text-reset text-decoration-none" role="alert">
                                <i class="bx bx-info-circle me-2"></i>
                                <div><strong>Information:</strong> {{ $alert['message'] }}</div>
                            </a>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        {{-- Recent Activity --}}
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title m-0 me-2">Recent Activity</h5>
                </div>
                <div class="card-body">
                    @forelse ($recentActivity as $activity)
                        <div class="d-flex mb-4 pb-1">
                            <div class="avatar flex-shrink-0 me-3">
                                <span class="avatar-initial rounded bg-label-secondary"><i class="bx bx-history"></i></span>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <h6 class="mb-0">{{ $activity->description }}</h6>
                                    <small class="text-muted">{{ $activity->occurred_at_label }}</small>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="text-center text-muted py-4">
                            No recent activity.
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('page-scripts')
<script>
    (function () {
        var cardColor = config.colors.white;
        var headingColor = config.colors.headingColor;
        var axisColor = config.colors.axisColor;
        var borderColor = config.colors.borderColor;

        @if (count($weightTrend['labels']) > 0)
        // Reptile Weight Trend - Area/Line Chart
        var weightTrendData = @json($weightTrend);
        var weightTrendEl = document.querySelector('#weightTrendChart');
        if (weightTrendEl) {
            new ApexCharts(weightTrendEl, {
                series: [
                    { name: 'Average Weight', data: weightTrendData.averageWeight },
                    { name: 'Target Weight', data: weightTrendData.targetWeight }
                ],
                chart: { height: 300, type: 'line', toolbar: { show: false } },
                colors: [config.colors.primary, config.colors.info],
                dataLabels: { enabled: false },
                stroke: { curve: 'smooth', width: 3 },
                legend: { show: true, horizontalAlign: 'left', position: 'top' },
                grid: { borderColor: borderColor },
                xaxis: {
                    categories: weightTrendData.labels,
                    labels: { style: { fontSize: '13px', colors: axisColor } },
                    axisTicks: { show: false },
                    axisBorder: { show: false }
                },
                yaxis: { labels: { style: { fontSize: '13px', colors: axisColor } } }
            }).render();
        }
        @endif

        @if ($statusOverview['total'] > 0)
        // Reptile Status Overview - Donut Chart
        var statusOverviewData = @json($statusOverview);
        var reptileStatusEl = document.querySelector('#reptileStatusChart');
        if (reptileStatusEl) {
            new ApexCharts(reptileStatusEl, {
                chart: { height: 165, width: 220, type: 'donut' },
                labels: ['Active', 'Inactive'],
                series: [statusOverviewData.active.count, statusOverviewData.inactive.count],
                colors: [config.colors.success, config.colors.secondary],
                stroke: { width: 5, colors: cardColor },
                dataLabels: {
                    enabled: false,
                    formatter: function (val) { return parseInt(val) + '%'; }
                },
                legend: { show: false },
                plotOptions: {
                    pie: {
                        donut: {
                            size: '75%',
                            labels: {
                                show: true,
                                value: {
                                    fontSize: '1.5rem',
                                    color: headingColor,
                                    offsetY: -15,
                                    formatter: function (val) { return parseInt(val) + '%'; }
                                },
                                total: {
                                    show: true,
                                    fontSize: '0.8125rem',
                                    color: axisColor,
                                    label: 'Total',
                                    formatter: function () { return statusOverviewData.total; }
                                }
                            }
                        }
                    }
                }
            }).render();
        }
        @endif

        @php $growthTotal = $growthSummary['onTarget'] + $growthSummary['belowTarget'] + $growthSummary['critical']; @endphp
        @if ($growthTotal > 0)
        // Growth Monitoring - Radial Gauge
        var growthGaugeEl = document.querySelector('#growthGaugeChart');
        if (growthGaugeEl) {
            new ApexCharts(growthGaugeEl, {
                series: [{{ round(($growthSummary['onTarget'] / $growthTotal) * 100, 1) }}],
                labels: ['On Target'],
                chart: { height: 200, type: 'radialBar' },
                plotOptions: {
                    radialBar: {
                        hollow: { size: '55%' },
                        track: { background: cardColor },
                        dataLabels: {
                            name: { fontSize: '13px', color: headingColor },
                            value: { fontSize: '20px', color: headingColor }
                        }
                    }
                },
                colors: [config.colors.success]
            }).render();
        }
        @endif
    })();
</script>
@endpush
