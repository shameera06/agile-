@php
    $isEdit = $category->exists;
    $action = $isEdit ? route('admin.species-categories.update', $category) : route('admin.species-categories.store');
@endphp

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Category Name *</label>
            <input
                type="text"
                id="name"
                name="name"
                class="form-control @error('name') is-invalid @enderror"
                placeholder="e.g. Snake"
                value="{{ old('name', $category->name) }}"
                autofocus
            />
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="status" class="form-label">Status</label>
            <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
                <option value="1" @selected(old('status', (int) $category->status) == 1)>Active</option>
                <option value="0" @selected(old('status', (int) $category->status) == 0)>Inactive</option>
            </select>
            @error('status')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Save Category</button>
    <a href="{{ route('admin.species.browse') }}" class="btn btn-outline-secondary">Cancel</a>
</form>
