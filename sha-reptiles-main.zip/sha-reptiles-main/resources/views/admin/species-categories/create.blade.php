@extends('admin.layouts.master')

@section('title', 'Add Category')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
            <li class="breadcrumb-item active">Add Category</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Add Category</h4>

    <div class="card">
        <div class="card-body">
            @include('admin.species-categories._form', ['category' => $category])
        </div>
    </div>
</div>
@endsection
