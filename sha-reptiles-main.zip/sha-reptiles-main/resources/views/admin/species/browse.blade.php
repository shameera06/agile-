@extends('admin.layouts.master')

@section('title', 'Species')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Species</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <div>
            <h4 class="fw-bold mb-1">Species</h4>
            <p class="text-muted mb-0">Browse Category &rarr; Species Type &rarr; Variety/Morph to find an individual reptile.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.species.index') }}" class="btn btn-outline-secondary">
                <i class="bx bx-cog me-1"></i> Manage Species Catalog
            </a>
            <a href="{{ route('admin.species-categories.create') }}" class="btn btn-primary">
                <i class="bx bx-plus me-1"></i> Add Category
            </a>
        </div>
    </div>

    <div class="row">
        @forelse ($categories as $category)
            <div class="col-sm-6 col-lg-4 mb-4">
                <div class="card h-100">
                    <div class="card-body position-relative">
                        <div class="d-flex align-items-start justify-content-between mb-2">
                            <div class="avatar flex-shrink-0">
                                <span class="avatar-initial rounded {{ $category->status ? 'bg-label-primary' : 'bg-label-secondary' }}">
                                    <i class="bx bx-spa"></i>
                                </span>
                            </div>
                            <x-admin.action-menu>
                                <a href="{{ route('admin.species-categories.edit', $category) }}" class="dropdown-item">
                                    <i class="bx bx-edit-alt"></i> Edit
                                </a>
                                <form method="POST" action="{{ route('admin.species-categories.destroy', $category) }}"
                                    onsubmit="return confirm('Delete this category?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bx bx-trash"></i> Delete
                                    </button>
                                </form>
                            </x-admin.action-menu>
                        </div>
                        <h5 class="mb-1">{{ $category->name }}</h5>
                        <p class="text-muted mb-2">{{ $category->species_types_count }} species type{{ $category->species_types_count === 1 ? '' : 's' }}</p>
                        @unless ($category->status)
                            <span class="badge bg-label-secondary mb-2">Inactive</span>
                        @endunless
                        <a href="{{ route('admin.species.category', $category) }}" class="stretched-link fw-semibold">
                            View Species <i class="bx bx-right-arrow-alt"></i>
                        </a>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <p class="mb-1 fw-semibold">No categories yet.</p>
                        <p class="text-muted mb-0">Add your first category (e.g. Snake, Iguana, Bearded Dragon) to begin organizing species.</p>
                    </div>
                </div>
            </div>
        @endforelse
    </div>
</div>
@endsection
