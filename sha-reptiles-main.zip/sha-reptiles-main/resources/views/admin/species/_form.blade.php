@php
    $isEdit = $species->exists;
    $action = $isEdit ? route('admin.species.update', $species) : route('admin.species.store');
@endphp

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="category_id" class="form-label">Category</label>
            <select id="category_id" name="category_id" class="form-select @error('category_id') is-invalid @enderror">
                <option value="">Uncategorized</option>
                @foreach ($categoryOptions as $option)
                    <option value="{{ $option->id }}" @selected((int) old('category_id', $species->category_id) === $option->id)>
                        {{ $option->name }}
                    </option>
                @endforeach
            </select>
            <small class="text-muted d-block mt-1">The top-level Category this species type belongs to under Species &rarr; Category &rarr; Type &rarr; Variety (e.g. Snake, Iguana). Optional.</small>
            @error('category_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Species Name *</label>
            <input
                type="text"
                id="name"
                name="name"
                class="form-control @error('name') is-invalid @enderror"
                placeholder="e.g. Ball Python"
                value="{{ old('name', $species->name) }}"
                autofocus
            />
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="scientific_name" class="form-label">Scientific Name</label>
            <input
                type="text"
                id="scientific_name"
                name="scientific_name"
                class="form-control @error('scientific_name') is-invalid @enderror"
                placeholder="e.g. Python regius"
                value="{{ old('scientific_name', $species->scientific_name) }}"
            />
            @error('scientific_name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea
            id="description"
            name="description"
            rows="4"
            class="form-control @error('description') is-invalid @enderror"
            placeholder="A short description of this species"
        >{{ old('description', $species->description) }}</textarea>
        @error('description')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-4 col-md-6">
        <label for="status" class="form-label">Status</label>
        <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
            <option value="1" @selected(old('status', (int) $species->status) == 1)>Active</option>
            <option value="0" @selected(old('status', (int) $species->status) == 0)>Inactive</option>
        </select>
        @error('status')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Species</button>
    <a href="{{ route('admin.species.index') }}" class="btn btn-outline-secondary">Cancel</a>
</form>
