@extends('admin.layouts.master')

@section('title', $category->name)

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
            <li class="breadcrumb-item active">{{ $category->name }}</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">{{ $category->name }}</h4>
        <a href="{{ route('admin.species.create', ['category_id' => $category->id]) }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Species Type
        </a>
    </div>

    <div class="row">
        @forelse ($speciesTypes as $species)
            <div class="col-sm-6 col-lg-4 mb-4">
                <div class="card h-100">
                    <div class="card-body position-relative">
                        <div class="d-flex align-items-start justify-content-between mb-2">
                            <div class="avatar flex-shrink-0">
                                <span class="avatar-initial rounded {{ $species->status ? 'bg-label-info' : 'bg-label-secondary' }}">
                                    <i class="bx bx-leaf"></i>
                                </span>
                            </div>
                            <x-admin.action-menu>
                                <a href="{{ route('admin.species.edit', $species) }}" class="dropdown-item">
                                    <i class="bx bx-edit-alt"></i> Edit
                                </a>
                                <form method="POST" action="{{ route('admin.species.destroy', $species) }}"
                                    onsubmit="return confirm('Delete this species type?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bx bx-trash"></i> Delete
                                    </button>
                                </form>
                            </x-admin.action-menu>
                        </div>
                        <h5 class="mb-1">{{ $species->name }}</h5>
                        <p class="text-muted mb-2">{{ $species->varieties_count }} variet{{ $species->varieties_count === 1 ? 'y' : 'ies' }}</p>
                        @unless ($species->status)
                            <span class="badge bg-label-secondary mb-2">Inactive</span>
                        @endunless
                        <a href="{{ route('admin.species.type', $species) }}" class="stretched-link fw-semibold">
                            View Varieties <i class="bx bx-right-arrow-alt"></i>
                        </a>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <p class="mb-1 fw-semibold">No species types in {{ $category->name }} yet.</p>
                        <p class="text-muted mb-0">Add a species type (e.g. Corn Snake, Python Snake) to begin registering varieties and reptiles.</p>
                    </div>
                </div>
            </div>
        @endforelse
    </div>
</div>
@endsection
