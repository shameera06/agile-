@extends('admin.layouts.master')

@section('title', 'Species')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Species</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Species</h4>
        <a href="{{ route('admin.species.create') }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Species
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.species.index') }}" class="row g-3 align-items-end">
                <div class="col-md-5">
                    <label for="search" class="form-label">Search</label>
                    <input
                        type="text"
                        id="search"
                        name="search"
                        class="form-control"
                        placeholder="Search by species or scientific name"
                        value="{{ $search }}"
                    />
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="" @selected($status === '')>All</option>
                        <option value="active" @selected($status === 'active')>Active</option>
                        <option value="inactive" @selected($status === 'inactive')>Inactive</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="bx bx-search me-1"></i> Filter
                    </button>
                    @if ($search !== '' || $status !== '')
                        <a href="{{ route('admin.species.index') }}" class="btn btn-outline-secondary">Reset</a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Species Name</th>
                        <th>Scientific Name</th>
                        <th>Status</th>
                        <th>Created Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($species as $item)
                        <tr>
                            <td>{{ $loop->iteration + ($species->currentPage() - 1) * $species->perPage() }}</td>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->scientific_name ?? '—' }}</td>
                            <td>
                                @if ($item->status)
                                    <span class="badge bg-label-success">Active</span>
                                @else
                                    <span class="badge bg-label-secondary">Inactive</span>
                                @endif
                            </td>
                            <td>{{ $item->created_at->format('M d, Y') }}</td>
                            <td>
                                <x-admin.action-menu>
                                    <a href="{{ route('admin.species.edit', $item) }}" class="dropdown-item">
                                        <i class="bx bx-edit-alt"></i> Edit
                                    </a>
                                    <form
                                        method="POST"
                                        action="{{ route('admin.species.destroy', $item) }}"
                                        onsubmit="return confirm('Are you sure you want to delete this species?');"
                                    >
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="bx bx-trash"></i> Delete
                                        </button>
                                    </form>
                                </x-admin.action-menu>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <p class="mb-1 fw-semibold">No species found.</p>
                                <p class="text-muted mb-0">Add your first species to begin managing reptile records.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($species->hasPages())
            <div class="card-footer">
                {{ $species->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
