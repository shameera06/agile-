@extends('admin.layouts.master')

@section('title', $species->name)

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
            @if ($species->category)
                <li class="breadcrumb-item"><a href="{{ route('admin.species.category', $species->category) }}">{{ $species->category->name }}</a></li>
            @endif
            <li class="breadcrumb-item active">{{ $species->name }}</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">{{ $species->name }}</h4>
        <a href="{{ route('admin.species-varieties.create', ['species_id' => $species->id]) }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Variety
        </a>
    </div>

    @if ($unassignedReptileCount > 0)
        <div class="alert alert-info d-flex align-items-center justify-content-between mb-4" role="alert">
            <div>
                <i class="bx bx-info-circle me-2"></i>
                {{ $unassignedReptileCount }} reptile{{ $unassignedReptileCount === 1 ? '' : 's' }} of this species type {{ $unassignedReptileCount === 1 ? 'is' : 'are' }} not yet assigned to a variety.
            </div>
            <a href="{{ route('admin.reptiles.index', ['species_id' => $species->id]) }}" class="btn btn-sm btn-outline-primary">View in Reptile Management</a>
        </div>
    @endif

    <div class="row">
        @forelse ($varieties as $variety)
            <div class="col-sm-6 col-lg-4 mb-4">
                <div class="card h-100">
                    <div class="card-body position-relative">
                        <div class="d-flex align-items-start justify-content-between mb-2">
                            <div class="avatar flex-shrink-0">
                                <span class="avatar-initial rounded {{ $variety->status ? 'bg-label-warning' : 'bg-label-secondary' }}">
                                    <i class="bx bx-dna"></i>
                                </span>
                            </div>
                            <x-admin.action-menu>
                                <a href="{{ route('admin.species-varieties.edit', $variety) }}" class="dropdown-item">
                                    <i class="bx bx-edit-alt"></i> Edit
                                </a>
                                <form method="POST" action="{{ route('admin.species-varieties.destroy', $variety) }}"
                                    onsubmit="return confirm('Delete this variety?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bx bx-trash"></i> Delete
                                    </button>
                                </form>
                            </x-admin.action-menu>
                        </div>
                        <h5 class="mb-1">{{ $variety->name }}</h5>
                        <p class="text-muted mb-2">{{ $variety->reptiles_count }} reptile{{ $variety->reptiles_count === 1 ? '' : 's' }}</p>
                        @unless ($variety->status)
                            <span class="badge bg-label-secondary mb-2">Inactive</span>
                        @endunless
                        <a href="{{ route('admin.species.variety', [$species, $variety]) }}" class="stretched-link fw-semibold">
                            View Reptiles <i class="bx bx-right-arrow-alt"></i>
                        </a>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <p class="mb-1 fw-semibold">No varieties registered under {{ $species->name }} yet.</p>
                        <p class="text-muted mb-0">Add a variety/morph (e.g. Albino, Royal) to begin registering individual reptiles under it.</p>
                    </div>
                </div>
            </div>
        @endforelse
    </div>
</div>
@endsection
