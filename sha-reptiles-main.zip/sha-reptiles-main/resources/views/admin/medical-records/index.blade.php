@extends('admin.layouts.master')

@section('title', 'Medical Records')

@push('page-styles')
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css') }}" />
@endpush

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Medical Records</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Medical Records</h4>
        <a href="{{ route('admin.medical-records.create') }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Medical Record
        </a>
    </div>

    <div class="card">
        <div class="card-body table-responsive text-nowrap">
            {!! $dataTable->table(['class' => 'table']) !!}
        </div>
    </div>
</div>
@endsection

@push('page-scripts')
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.js') }}"></script>
<script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.js') }}"></script>
{!! $dataTable->scripts() !!}
@endpush
