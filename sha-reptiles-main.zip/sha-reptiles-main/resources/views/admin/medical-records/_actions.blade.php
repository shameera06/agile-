{{-- Rendered server-side by MedicalRecordDataTable::actionButtons() for each row. --}}
<x-admin.action-menu>
    <a href="{{ route('admin.medical-records.show', $record) }}" class="dropdown-item">
        <i class="bx bx-show"></i> View
    </a>
    <a href="{{ route('admin.medical-records.edit', $record) }}" class="dropdown-item">
        <i class="bx bx-edit-alt"></i> Edit
    </a>
    @if (auth()->user()?->isAdmin())
        <form action="{{ route('admin.medical-records.destroy', $record) }}" method="POST"
            onsubmit="return confirm('Delete this medical record? This cannot be undone.');">
            @csrf
            @method('DELETE')
            <button type="submit" class="dropdown-item text-danger">
                <i class="bx bx-trash"></i> Delete
            </button>
        </form>
    @endif
</x-admin.action-menu>
