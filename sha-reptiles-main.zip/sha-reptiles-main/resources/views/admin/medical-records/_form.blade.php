@php
    $isEdit = $medicalRecord->exists;
    $action = $isEdit ? route('admin.medical-records.update', $medicalRecord) : route('admin.medical-records.store');
    $cancelRoute = $lockedReptile
        ? route('admin.reptiles.show', $lockedReptile)
        : route('admin.medical-records.index');
@endphp

<form method="POST" action="{{ $action }}" enctype="multipart/form-data">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="reptile_id" class="form-label">Reptile *</label>
            @if ($lockedReptile)
                <input type="text" class="form-control" disabled
                    value="{{ $lockedReptile->name }} — {{ $lockedReptile->reptile_code }} — {{ $lockedReptile->species->name }}" />
                <input type="hidden" name="reptile_id" value="{{ $lockedReptile->id }}" />
            @else
                <select id="reptile_id" name="reptile_id" class="form-select @error('reptile_id') is-invalid @enderror">
                    <option value="">Select a reptile</option>
                    @foreach ($reptileOptions as $option)
                        <option value="{{ $option->id }}" @selected((int) old('reptile_id', $medicalRecord->reptile_id) === $option->id)>
                            {{ $option->name }} — {{ $option->reptile_code }} — {{ $option->species->name }}
                            {{ $option->status !== 'active' ? ' (' . \App\Models\Reptile::STATUSES[$option->status] . ')' : '' }}
                        </option>
                    @endforeach
                </select>
                @error('reptile_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            @endif
        </div>

        <div class="col-md-3 mb-3">
            <label for="treatment_date" class="form-label">Treatment Date *</label>
            <input
                type="date"
                id="treatment_date"
                name="treatment_date"
                class="form-control @error('treatment_date') is-invalid @enderror"
                value="{{ old('treatment_date', optional($medicalRecord->treatment_date)->format('Y-m-d')) }}"
            />
            @error('treatment_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-3">
        <label for="symptoms_or_condition" class="form-label">Symptoms / Health Condition *</label>
        <textarea
            id="symptoms_or_condition"
            name="symptoms_or_condition"
            rows="2"
            class="form-control @error('symptoms_or_condition') is-invalid @enderror"
            placeholder="e.g. Lethargy and reduced appetite for the past 3 days."
        >{{ old('symptoms_or_condition', $medicalRecord->symptoms_or_condition) }}</textarea>
        @error('symptoms_or_condition')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="medicine_name" class="form-label">Medicine</label>
            <input
                type="text"
                id="medicine_name"
                name="medicine_name"
                class="form-control @error('medicine_name') is-invalid @enderror"
                value="{{ old('medicine_name', $medicalRecord->medicine_name) }}"
            />
            @error('medicine_name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="dosage" class="form-label">Dosage</label>
            <input
                type="text"
                id="dosage"
                name="dosage"
                class="form-control @error('dosage') is-invalid @enderror"
                placeholder="e.g. 5mg/kg once daily"
                value="{{ old('dosage', $medicalRecord->dosage) }}"
            />
            @error('dosage')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-3">
        <label for="treatment_details" class="form-label">Treatment Details</label>
        <textarea
            id="treatment_details"
            name="treatment_details"
            rows="3"
            class="form-control @error('treatment_details') is-invalid @enderror"
        >{{ old('treatment_details', $medicalRecord->treatment_details) }}</textarea>
        @error('treatment_details')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="veterinarian_name" class="form-label">Veterinarian Name</label>
            <input
                type="text"
                id="veterinarian_name"
                name="veterinarian_name"
                class="form-control @error('veterinarian_name') is-invalid @enderror"
                value="{{ old('veterinarian_name', $medicalRecord->veterinarian_name) }}"
            />
            @error('veterinarian_name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="veterinarian_contact" class="form-label">Veterinarian Contact</label>
            <input
                type="text"
                id="veterinarian_contact"
                name="veterinarian_contact"
                class="form-control @error('veterinarian_contact') is-invalid @enderror"
                value="{{ old('veterinarian_contact', $medicalRecord->veterinarian_contact) }}"
            />
            @error('veterinarian_contact')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-3">
        <label for="prescription" class="form-label">Prescription</label>

        @if ($isEdit && $medicalRecord->hasPrescription())
            <div class="mb-2">
                <span class="badge bg-label-info"><i class="bx bx-file me-1"></i>Prescription already attached</span>
                <a href="{{ route('admin.medical-records.prescription', $medicalRecord) }}" target="_blank" class="btn btn-sm btn-outline-primary ms-2">
                    View / Download
                </a>
            </div>
        @endif

        <input
            type="file"
            id="prescription"
            name="prescription"
            class="form-control @error('prescription') is-invalid @enderror"
            accept=".jpg,.jpeg,.png,.webp,.pdf"
        />
        <small class="text-muted d-block mt-1">
            Allowed formats: JPG, PNG, WEBP, PDF (max 5MB).
            @if ($isEdit)
                Uploading a new file replaces the existing prescription.
            @endif
        </small>
        @error('prescription')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-4">
        <label for="notes" class="form-label">Notes</label>
        <textarea
            id="notes"
            name="notes"
            rows="3"
            class="form-control @error('notes') is-invalid @enderror"
        >{{ old('notes', $medicalRecord->notes) }}</textarea>
        @error('notes')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Medical Record</button>
    <a href="{{ $cancelRoute }}" class="btn btn-outline-secondary">Cancel</a>
</form>
