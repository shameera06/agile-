@extends('admin.layouts.master')

@section('title', 'Medical Record Details')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.medical-records.index') }}">Medical Records</a></li>
            <li class="breadcrumb-item active">Medical Record Details</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Medical Record Details</h4>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.medical-records.edit', $medicalRecord) }}" class="btn btn-primary">
                <i class="bx bx-edit-alt me-1"></i> Edit
            </a>
            @if (auth()->user()?->isAdmin())
                <form action="{{ route('admin.medical-records.destroy', $medicalRecord) }}" method="POST"
                    onsubmit="return confirm('Delete this medical record? This cannot be undone.');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-outline-danger">
                        <i class="bx bx-trash me-1"></i> Delete
                    </button>
                </form>
            @endif
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title m-0">
                {{ $medicalRecord->reptile->name }}
                <small class="text-muted">{{ $medicalRecord->reptile->reptile_code }} — {{ $medicalRecord->reptile->species->name }}</small>
            </h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-borderless mb-0">
                    <tbody>
                        <tr>
                            <th class="text-muted" style="width: 220px;">Treatment Date</th>
                            <td>{{ $medicalRecord->treatment_date->format('M d, Y') }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Symptoms / Condition</th>
                            <td>{{ $medicalRecord->symptoms_or_condition }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Medicine</th>
                            <td>{{ $medicalRecord->medicine_name ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Dosage</th>
                            <td>{{ $medicalRecord->dosage ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Treatment Details</th>
                            <td>{{ $medicalRecord->treatment_details ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Veterinarian</th>
                            <td>{{ $medicalRecord->veterinarian_name ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Veterinarian Contact</th>
                            <td>{{ $medicalRecord->veterinarian_contact ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Notes</th>
                            <td>{{ $medicalRecord->notes ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Prescription</th>
                            <td>
                                @if ($medicalRecord->hasPrescription())
                                    <a href="{{ route('admin.medical-records.prescription', $medicalRecord) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="bx bx-file me-1"></i> View / Download
                                    </a>
                                @else
                                    <span class="text-muted">—</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th class="text-muted">Created By</th>
                            <td>{{ $medicalRecord->createdBy->name ?? '—' }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Created Date</th>
                            <td>{{ $medicalRecord->created_at->format('M d, Y g:i A') }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
