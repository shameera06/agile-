@php
    $isEdit = $feedingRecord->exists;
    $action = $isEdit ? route('admin.feeding-records.update', $feedingRecord) : route('admin.feeding-records.store');
    $reptile = $isEdit ? $feedingRecord->reptile : ($feedingSchedule?->reptile ?? $reptile);
    $foodType = $isEdit ? $feedingRecord->foodType : $feedingSchedule?->foodType;
@endphp

<div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title m-0">{{ $feedingSchedule ? 'Scheduled Feeding' : 'Reptile' }}</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-borderless mb-0">
                <tbody>
                    <tr>
                        <th class="text-muted" style="width: 220px;">Reptile</th>
                        <td>{{ $reptile->name }} — {{ $reptile->reptile_code }} ({{ $reptile->species->name }})</td>
                    </tr>
                    @if ($foodType)
                        <tr>
                            <th class="text-muted">Food Type</th>
                            <td>{{ $foodType->parent ? $foodType->parent->name.' → '.$foodType->name : $foodType->name }}</td>
                        </tr>
                    @endif
                    @if ($feedingSchedule)
                        <tr>
                            <th class="text-muted">Scheduled Quantity</th>
                            <td>{{ rtrim(rtrim($feedingSchedule->quantity, '0'), '.') }} {{ \App\Models\FeedingSchedule::QUANTITY_UNITS[$feedingSchedule->quantity_unit] ?? $feedingSchedule->quantity_unit }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Scheduled Interval</th>
                            <td>Every {{ $feedingSchedule->interval_days }} {{ Str::plural('day', $feedingSchedule->interval_days) }}</td>
                        </tr>
                        <tr>
                            <th class="text-muted">Scheduled Feeding Date</th>
                            <td>{{ $feedingSchedule->next_due_at->format('M d, Y g:i A') }}</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @elseif ($feedingSchedule)
        <input type="hidden" name="feeding_schedule_id" value="{{ $feedingSchedule->id }}" />
    @else
        <input type="hidden" name="reptile_id" value="{{ $reptile->id }}" />
    @endif

    @if (! $isEdit && ! $feedingSchedule)
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="food_type_id" class="form-label">Food Type *</label>
                <select id="food_type_id" name="food_type_id" class="form-select @error('food_type_id') is-invalid @enderror">
                    <option value="">Select Food Type</option>
                    @foreach ($foodTypeOptions as $option)
                        <option value="{{ $option->id }}" @selected((int) old('food_type_id') === $option->id)>
                            {{ $option->parent ? $option->parent->name . ' → ' . $option->name : $option->name }}
                        </option>
                    @endforeach
                </select>
                @error('food_type_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="feeding_date" class="form-label">Actual Feeding Date/Time *</label>
            <input
                type="datetime-local"
                id="feeding_date"
                name="feeding_date"
                class="form-control @error('feeding_date') is-invalid @enderror"
                value="{{ old('feeding_date', optional($feedingRecord->feeding_date)->format('Y-m-d\TH:i')) }}"
            />
            @error('feeding_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-3">
            <label for="quantity" class="form-label">Actual Quantity *</label>
            <input
                type="number"
                step="0.01"
                min="0.01"
                id="quantity"
                name="quantity"
                class="form-control @error('quantity') is-invalid @enderror"
                value="{{ old('quantity', $feedingRecord->quantity) }}"
            />
            @error('quantity')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-4 mb-3">
            <label for="quantity_unit" class="form-label">Quantity Unit *</label>
            <select id="quantity_unit" name="quantity_unit" class="form-select @error('quantity_unit') is-invalid @enderror">
                @foreach (\App\Models\FeedingSchedule::QUANTITY_UNITS as $value => $label)
                    <option value="{{ $value }}" @selected(old('quantity_unit', $feedingRecord->quantity_unit) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('quantity_unit')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-3">
            <label for="weight_before" class="form-label">Weight Before Feeding (g) *</label>
            <input
                type="number"
                step="0.01"
                min="0.01"
                id="weight_before"
                name="weight_before"
                class="form-control @error('weight_before') is-invalid @enderror"
                value="{{ old('weight_before', $feedingRecord->weight_before) }}"
            />
            @error('weight_before')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-4 mb-3">
            <label for="weight_after" class="form-label">Weight After Feeding (g) *</label>
            <input
                type="number"
                step="0.01"
                min="0.01"
                id="weight_after"
                name="weight_after"
                class="form-control @error('weight_after') is-invalid @enderror"
                value="{{ old('weight_after', $feedingRecord->weight_after) }}"
            />
            @error('weight_after')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-4 mb-3">
            <label for="weight_after_defecation" class="form-label">Weight After Defecation (g)</label>
            <input
                type="number"
                step="0.01"
                min="0.01"
                id="weight_after_defecation"
                name="weight_after_defecation"
                class="form-control @error('weight_after_defecation') is-invalid @enderror"
                value="{{ old('weight_after_defecation', $feedingRecord->weight_after_defecation) }}"
            />
            <small class="text-muted d-block mt-1">Leave blank if not yet available.</small>
            @error('weight_after_defecation')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-4">
        <label for="notes" class="form-label">Notes</label>
        <textarea
            id="notes"
            name="notes"
            rows="3"
            class="form-control @error('notes') is-invalid @enderror"
        >{{ old('notes', $feedingRecord->notes) }}</textarea>
        @error('notes')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Feeding Record</button>
    <a href="{{ route('admin.feeding-records.index') }}" class="btn btn-outline-secondary">Cancel</a>
</form>
