@extends('admin.layouts.master')

@section('title', 'Record Feeding')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.feeding-records.index') }}">Feeding Records</a></li>
            <li class="breadcrumb-item active">Record Feeding</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Record Feeding</h4>

    @include('admin.feeding-records._form')
</div>
@endsection
