@php
    $trendBadgeClasses = [
        'gain' => 'bg-label-success',
        'no_gain' => 'bg-label-warning',
        'loss' => 'bg-label-danger',
    ];
@endphp
@if ($trend)
    <span class="badge {{ $trendBadgeClasses[$trend] ?? 'bg-label-secondary' }}">
        {{ \App\Models\FeedingRecord::WEIGHT_TRENDS[$trend] ?? ucfirst($trend) }}
    </span>
@else
    <span class="text-muted">First Record</span>
@endif
