@extends('admin.layouts.master')

@section('title', 'Feeding Records')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Feeding Records</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Feeding Records</h4>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.feeding-records.index') }}" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="search" class="form-label">Search</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Reptile name, code, or food" value="{{ $search }}" />
                </div>
                <div class="col-md-2">
                    <label for="reptile_id" class="form-label">Reptile</label>
                    <select id="reptile_id" name="reptile_id" class="form-select">
                        <option value="">All Reptiles</option>
                        @foreach ($reptileOptions as $option)
                            <option value="{{ $option->id }}" @selected($reptileId === $option->id)>{{ $option->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="food_type_id" class="form-label">Food</label>
                    <select id="food_type_id" name="food_type_id" class="form-select">
                        <option value="">All Food Types</option>
                        @foreach ($foodTypeOptions as $option)
                            <option value="{{ $option->id }}" @selected($foodTypeId === $option->id)>
                                {{ $option->parent ? $option->parent->name . ' → ' . $option->name : $option->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="trend" class="form-label">Weight Trend</label>
                    <select id="trend" name="trend" class="form-select">
                        <option value="" @selected($trend === '')>All</option>
                        @foreach (\App\Models\FeedingRecord::WEIGHT_TRENDS as $value => $label)
                            <option value="{{ $value }}" @selected($trend === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="alert" class="form-label">Alert</label>
                    <select id="alert" name="alert" class="form-select">
                        <option value="" @selected($alert === '')>All</option>
                        <option value="alerts" @selected($alert === 'alerts')>Alerts Only</option>
                        <option value="none" @selected($alert === 'none')>No Alerts</option>
                    </select>
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary" title="Filter"><i class="bx bx-search"></i></button>
                </div>
                <div class="col-md-3">
                    <label for="date_from" class="form-label">From</label>
                    <input type="date" id="date_from" name="date_from" class="form-control" value="{{ $dateFrom }}" />
                </div>
                <div class="col-md-3">
                    <label for="date_to" class="form-label">To</label>
                    <input type="date" id="date_to" name="date_to" class="form-control" value="{{ $dateTo }}" />
                </div>
            </form>
            @if ($search !== '' || $reptileId || $foodTypeId || $trend !== '' || $alert !== '' || $dateFrom !== '' || $dateTo !== '')
                <a href="{{ route('admin.feeding-records.index') }}" class="btn btn-outline-secondary btn-sm mt-3">Reset filters</a>
            @endif
        </div>
    </div>

    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Reptile</th><th>Food</th><th>Feeding Date</th><th>Quantity</th>
                        <th>Before</th><th>After</th><th>After Defecation</th><th>Weight Change</th>
                        <th>Trend</th><th>Alert</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($feedingRecords as $record)
                        <tr>
                            <td>
                                <h6 class="mb-0">{{ $record->reptile->name }}</h6>
                                <small class="text-muted">{{ $record->reptile->reptile_code }}</small>
                            </td>
                            <td>{{ $record->foodType->parent ? $record->foodType->parent->name . ' → ' . $record->foodType->name : $record->foodType->name }}</td>
                            <td>{{ $record->feeding_date->format('M d, Y g:i A') }}</td>
                            <td>{{ rtrim(rtrim($record->quantity, '0'), '.') }} {{ \App\Models\FeedingSchedule::QUANTITY_UNITS[$record->quantity_unit] ?? $record->quantity_unit }}</td>
                            <td>{{ $record->weight_before }} g</td>
                            <td>{{ $record->weight_after }} g</td>
                            <td>
                                @if ($record->weight_after_defecation !== null)
                                    {{ $record->weight_after_defecation }} g
                                    @if ((float) $record->weight_after_defecation > (float) $record->weight_after)
                                        <i class="bx bx-error text-warning" title="After-defecation weight is higher than after-feeding weight — please double-check these measurements."></i>
                                    @endif
                                @else
                                    <span class="text-muted">—</span>
                                @endif
                            </td>
                            <td>
                                @if ($record->weight_change !== null)
                                    <span class="{{ $record->weight_change > 0 ? 'text-success' : ($record->weight_change < 0 ? 'text-danger' : '') }}">
                                        {{ $record->weight_change > 0 ? '+' : '' }}{{ $record->weight_change }} g
                                    </span>
                                @else
                                    <span class="text-muted">—</span>
                                @endif
                            </td>
                            <td>@include('admin.feeding-records._trend_badge', ['trend' => $record->weight_trend])</td>
                            <td>@include('admin.feeding-records._alert_badge', ['alertTriggered' => $record->weight_alert_triggered, 'alertMessage' => $record->weight_alert_message])</td>
                            <td>
                                <x-admin.action-menu>
                                    <a href="{{ route('admin.feeding-records.edit', $record) }}" class="dropdown-item">
                                        <i class="bx bx-edit-alt"></i> Edit
                                    </a>
                                </x-admin.action-menu>
                            </td>
                        </tr>
                        @if ($record->weight_alert_triggered)
                            <tr>
                                <td colspan="11" class="pt-0">
                                    <div class="alert alert-danger d-flex align-items-center mb-0 py-2" role="alert">
                                        <i class="bx bx-error-circle me-2"></i>
                                        <div>{{ $record->weight_alert_message }}</div>
                                    </div>
                                </td>
                            </tr>
                        @endif
                    @empty
                        <tr>
                            <td colspan="11" class="text-center py-5">
                                <p class="mb-1 fw-semibold">No feeding records found.</p>
                                <p class="text-muted mb-0">Add a feeding record from a reptile's profile to begin tracking history.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($feedingRecords->hasPages())
            <div class="card-footer">{{ $feedingRecords->links() }}</div>
        @endif
    </div>
</div>
@endsection
