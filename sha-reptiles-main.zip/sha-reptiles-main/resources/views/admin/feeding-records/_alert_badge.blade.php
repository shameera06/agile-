@if ($alertTriggered)
    <span class="badge bg-label-danger" title="{{ $alertMessage }}">
        <i class="bx bx-error-circle"></i> Weight Alert
    </span>
@else
    <span class="text-muted">—</span>
@endif
