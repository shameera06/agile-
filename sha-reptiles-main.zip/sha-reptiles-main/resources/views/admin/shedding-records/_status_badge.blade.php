@php
    $statusBadgeClasses = [
        'complete' => 'bg-label-success',
        'partial' => 'bg-label-warning',
        'incomplete' => 'bg-label-danger',
        'problematic' => 'bg-label-dark',
    ];
@endphp
<span class="badge {{ $statusBadgeClasses[$status] ?? 'bg-label-secondary' }}">
    {{ \App\Models\SheddingRecord::STATUSES[$status] ?? ucfirst($status) }}
</span>
