@php
    $isEdit = $sheddingRecord->exists;
    $action = $isEdit ? route('admin.shedding-records.update', $sheddingRecord) : route('admin.shedding-records.store');
    $cancelRoute = $lockedReptile
        ? route('admin.reptiles.show', $lockedReptile)
        : route('admin.shedding-records.index');
@endphp

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="reptile_id" class="form-label">Reptile *</label>
            @if ($lockedReptile)
                <input type="text" class="form-control" disabled
                    value="{{ $lockedReptile->name }} — {{ $lockedReptile->reptile_code }} — {{ $lockedReptile->species->name }}" />
                <input type="hidden" name="reptile_id" value="{{ $lockedReptile->id }}" />
            @else
                <select id="reptile_id" name="reptile_id" class="form-select @error('reptile_id') is-invalid @enderror">
                    <option value="">Select a reptile</option>
                    @foreach ($reptileOptions as $option)
                        <option value="{{ $option->id }}" @selected((int) old('reptile_id', $sheddingRecord->reptile_id) === $option->id)>
                            {{ $option->name }} — {{ $option->reptile_code }} — {{ $option->species->name }}
                            {{ $option->status !== 'active' ? ' (' . \App\Models\Reptile::STATUSES[$option->status] . ')' : '' }}
                        </option>
                    @endforeach
                </select>
                @error('reptile_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            @endif
        </div>

        <div class="col-md-3 mb-3">
            <label for="shedding_date" class="form-label">Shedding Date *</label>
            <input
                type="date"
                id="shedding_date"
                name="shedding_date"
                class="form-control @error('shedding_date') is-invalid @enderror"
                value="{{ old('shedding_date', optional($sheddingRecord->shedding_date)->format('Y-m-d')) }}"
            />
            @error('shedding_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-3 mb-3">
            <label for="status" class="form-label">Status *</label>
            <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
                @foreach (\App\Models\SheddingRecord::STATUSES as $value => $label)
                    <option value="{{ $value }}" @selected(old('status', $sheddingRecord->status) === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('status')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-3">
        <label for="notes" class="form-label">Notes</label>
        <textarea
            id="notes"
            name="notes"
            rows="3"
            class="form-control @error('notes') is-invalid @enderror"
            placeholder="e.g. Normal shedding behavior. Reptile remained active."
        >{{ old('notes', $sheddingRecord->notes) }}</textarea>
        @error('notes')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-4">
        <label for="observations" class="form-label">Observations</label>
        <textarea
            id="observations"
            name="observations"
            rows="3"
            class="form-control @error('observations') is-invalid @enderror"
            placeholder="e.g. Small amount of retained skin observed around the tail."
        >{{ old('observations', $sheddingRecord->observations) }}</textarea>
        @error('observations')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Shedding Record</button>
    <a href="{{ $cancelRoute }}" class="btn btn-outline-secondary">Cancel</a>
</form>
