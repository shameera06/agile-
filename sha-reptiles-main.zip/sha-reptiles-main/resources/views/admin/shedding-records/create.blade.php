@extends('admin.layouts.master')

@section('title', 'Add Shedding Record')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.shedding-records.index') }}">Shedding Records</a></li>
            <li class="breadcrumb-item active">Add Shedding Record</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Add Shedding Record</h4>

    <div class="card">
        <div class="card-body">
            @include('admin.shedding-records._form')
        </div>
    </div>
</div>
@endsection
