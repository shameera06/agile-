@extends('admin.layouts.master')

@section('title', 'Shedding Records')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Shedding Records</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
        <h4 class="fw-bold mb-0">Shedding Records</h4>
        <a href="{{ route('admin.shedding-records.create') }}" class="btn btn-primary">
            <i class="bx bx-plus me-1"></i> Add Shedding Record
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.shedding-records.index') }}" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="search" class="form-label">Search</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Reptile name, code, or species" value="{{ $search }}" />
                </div>
                <div class="col-md-2">
                    <label for="reptile_id" class="form-label">Reptile</label>
                    <select id="reptile_id" name="reptile_id" class="form-select">
                        <option value="">All Reptiles</option>
                        @foreach ($reptileOptions as $option)
                            <option value="{{ $option->id }}" @selected($reptileId === $option->id)>{{ $option->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="" @selected($status === '')>All</option>
                        @foreach (\App\Models\SheddingRecord::STATUSES as $value => $label)
                            <option value="{{ $value }}" @selected($status === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="from" class="form-label">From Date</label>
                    <input type="date" id="from" name="from" class="form-control" value="{{ $dateFrom }}" />
                </div>
                <div class="col-md-2">
                    <label for="to" class="form-label">To Date</label>
                    <input type="date" id="to" name="to" class="form-control" value="{{ $dateTo }}" />
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary" title="Filter"><i class="bx bx-search"></i></button>
                </div>
            </form>
            @if ($search !== '' || $reptileId || $status !== '' || $dateFrom !== '' || $dateTo !== '')
                <a href="{{ route('admin.shedding-records.index') }}" class="btn btn-outline-secondary btn-sm mt-3">Reset filters</a>
            @endif
        </div>
    </div>

    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Reptile</th><th>Species</th><th>Shedding Date</th><th>Status</th>
                        <th>Notes</th><th>Created By</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse ($sheddingRecords as $record)
                        <tr>
                            <td>
                                <h6 class="mb-0">{{ $record->reptile->name }}</h6>
                                <small class="text-muted">{{ $record->reptile->reptile_code }}</small>
                            </td>
                            <td>{{ $record->reptile->species->name }}</td>
                            <td>{{ $record->shedding_date->format('M d, Y') }}</td>
                            <td>@include('admin.shedding-records._status_badge', ['status' => $record->status])</td>
                            <td class="text-truncate" style="max-width: 260px;">{{ $record->notes ?? '—' }}</td>
                            <td>{{ $record->createdBy->name ?? '—' }}</td>
                            <td>
                                <x-admin.action-menu>
                                    <a href="{{ route('admin.shedding-records.edit', $record) }}" class="dropdown-item">
                                        <i class="bx bx-edit-alt"></i> Edit
                                    </a>
                                </x-admin.action-menu>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <p class="mb-1 fw-semibold">No shedding records found.</p>
                                <p class="text-muted mb-0">Add a shedding record to begin tracking shedding history.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($sheddingRecords->hasPages())
            <div class="card-footer">{{ $sheddingRecords->links() }}</div>
        @endif
    </div>
</div>
@endsection
