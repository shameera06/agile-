@extends('admin.layouts.master')

@section('title', 'Add Variety')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.species.browse') }}">Species</a></li>
            <li class="breadcrumb-item active">Add Variety</li>
        </ol>
    </nav>

    <h4 class="fw-bold py-3 mb-4">Add Variety</h4>

    <div class="card">
        <div class="card-body">
            @include('admin.species-varieties._form')
        </div>
    </div>
</div>
@endsection
