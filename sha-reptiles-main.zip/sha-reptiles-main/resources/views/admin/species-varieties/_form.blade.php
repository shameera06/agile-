@php
    $isEdit = $variety->exists;
    $action = $isEdit ? route('admin.species-varieties.update', $variety) : route('admin.species-varieties.store');
@endphp

<form method="POST" action="{{ $action }}">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="species_id" class="form-label">Species Type *</label>
            @if ($lockedSpecies)
                <input type="text" class="form-control" value="{{ $lockedSpecies->name }}" disabled />
                <input type="hidden" name="species_id" value="{{ $lockedSpecies->id }}" />
            @else
                <select id="species_id" name="species_id" class="form-select @error('species_id') is-invalid @enderror">
                    <option value="">Select a species type</option>
                    @foreach ($speciesOptions as $option)
                        <option value="{{ $option->id }}" @selected((int) old('species_id', $variety->species_id) === $option->id)>
                            {{ $option->name }}
                        </option>
                    @endforeach
                </select>
            @endif
            @error('species_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Variety / Morph Name *</label>
            <input
                type="text"
                id="name"
                name="name"
                class="form-control @error('name') is-invalid @enderror"
                placeholder="e.g. Royal Python"
                value="{{ old('name', $variety->name) }}"
                autofocus
            />
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="mb-4 col-md-6">
        <label for="status" class="form-label">Status</label>
        <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
            <option value="1" @selected(old('status', (int) $variety->status) == 1)>Active</option>
            <option value="0" @selected(old('status', (int) $variety->status) == 0)>Inactive</option>
        </select>
        @error('status')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary">Save Variety</button>
    <a href="{{ $lockedSpecies ? route('admin.species.type', $lockedSpecies) : route('admin.species.browse') }}" class="btn btn-outline-secondary">Cancel</a>
</form>
