<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Weight Concern: {{ $healthAlert->reptile->name }}</title>
</head>
<body style="font-family: Arial, sans-serif; color: #1d2939; margin: 0; padding: 24px; background-color: #f4f5f7;">
    <div style="max-width: 560px; margin: 0 auto; background-color: #ffffff; border: 1px solid #d0d5dd; border-radius: 6px; padding: 24px;">
        <h2 style="margin-top: 0; color: #dc2626;">New Weight Concern</h2>

        <p>
            <strong>{{ $healthAlert->reptile->name }}</strong>
            ({{ $healthAlert->reptile->reptile_code }})
            has not been gaining weight properly and requires attention.
        </p>

        <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
            <tr>
                <td style="padding: 6px 0; color: #667085; width: 140px;">Reptile</td>
                <td style="padding: 6px 0;">{{ $healthAlert->reptile->name }} ({{ $healthAlert->reptile->reptile_code }})</td>
            </tr>
            <tr>
                <td style="padding: 6px 0; color: #667085;">Message</td>
                <td style="padding: 6px 0;">{{ $healthAlert->message }}</td>
            </tr>
            <tr>
                <td style="padding: 6px 0; color: #667085;">Severity</td>
                <td style="padding: 6px 0;">{{ \App\Models\HealthAlert::SEVERITIES[$healthAlert->severity] ?? ucfirst($healthAlert->severity) }}</td>
            </tr>
            <tr>
                <td style="padding: 6px 0; color: #667085;">Triggered At</td>
                <td style="padding: 6px 0;">{{ $healthAlert->triggered_at->format('M d, Y g:i A') }}</td>
            </tr>
        </table>

        <p>
            <a href="{{ route('admin.health-alerts.show', $healthAlert) }}"
                style="display: inline-block; background-color: #405189; color: #ffffff; text-decoration: none; padding: 10px 18px; border-radius: 4px;">
                View Weight Concern
            </a>
        </p>

        <p style="color: #667085; font-size: 12px; margin-top: 24px;">
            Please document the action taken and resolve this concern once addressed.
        </p>
    </div>
</body>
</html>
