{{--
    Reusable "actions" column control: a compact three-dot dropdown, matching
    the reference DataTable design. Built on a plain Bootstrap 5 dropdown —
    `bootstrap.js` (already loaded on every admin page) wires up
    `data-bs-toggle="dropdown"` automatically, no extra JS required.

    Usage — put whatever the module is actually authorized to do inside the
    slot; conditionals (e.g. Admin-only Delete) are just plain @if/@endif,
    same as before:

        <x-admin.action-menu>
            <a href="{{ route('admin.species.edit', $species) }}" class="dropdown-item">
                <i class="bx bx-edit-alt"></i> Edit
            </a>
            @if (auth()->user()?->isAdmin())
                <form action="{{ route('admin.species.destroy', $species) }}" method="POST"
                    onsubmit="return confirm('Delete this record?');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="dropdown-item text-danger">
                        <i class="bx bx-trash"></i> Delete
                    </button>
                </form>
            @endif
        </x-admin.action-menu>
--}}
@props([
    'label' => 'Actions',
])

<div {{ $attributes->merge(['class' => 'dropdown action-menu']) }}>
    <button
        type="button"
        class="btn btn-icon btn-sm dropdown-toggle action-menu-toggle"
        data-bs-toggle="dropdown"
        aria-expanded="false"
        aria-label="{{ $label }}"
    >
        <i class="bx bx-dots-vertical-rounded"></i>
    </button>
    <div class="dropdown-menu dropdown-menu-end">
        {{ $slot }}
    </div>
</div>
