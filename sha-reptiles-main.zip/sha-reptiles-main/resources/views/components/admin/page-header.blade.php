{{--
    Reusable page header: breadcrumb + title row, matching the pattern every
    module's index/create/edit/show page already follows by hand.

    Usage:
        <x-admin.page-header title="Species Management">
            <x-slot:actions>
                <a href="{{ route('admin.species.create') }}" class="btn btn-primary">
                    <i class="bx bx-plus me-1"></i> Add Species
                </a>
            </x-slot:actions>
        </x-admin.page-header>

    Pass intermediate breadcrumb links (between "Dashboard" and the current
    page) as `:breadcrumbs="['Species' => route('admin.species.index')]"`.
--}}
@props([
    'title',
    'breadcrumbs' => [],
])

<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-style1">
        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
        @foreach ($breadcrumbs as $label => $url)
            <li class="breadcrumb-item"><a href="{{ $url }}">{{ $label }}</a></li>
        @endforeach
        <li class="breadcrumb-item active">{{ $title }}</li>
    </ol>
</nav>

<div class="d-flex flex-wrap justify-content-between align-items-center py-3 mb-4 gap-2">
    <h4 class="fw-bold mb-0">{{ $title }}</h4>
    @isset($actions)
        <div class="d-flex gap-2">{{ $actions }}</div>
    @endisset
</div>
