{{--
    Reusable card container: white background, rounded corners, subtle
    shadow/border (all already provided by the vendor theme's `.card`) with
    an optional titled header and header-right action slot.

    Usage:
        <x-admin.card title="Basic Information">
            ... body content ...
        </x-admin.card>

        <x-admin.card title="Feeding History">
            <x-slot:actions>
                <a href="..." class="btn btn-sm btn-outline-primary">View All</a>
            </x-slot:actions>
            ... body content ...
        </x-admin.card>
--}}
@props([
    'title' => null,
])

<div {{ $attributes->merge(['class' => 'card']) }}>
    @if ($title || isset($actions))
        <div class="card-header d-flex align-items-center justify-content-between">
            @if ($title)
                <h5 class="card-title m-0">{{ $title }}</h5>
            @endif
            @isset($actions)
                <div class="d-flex gap-2">{{ $actions }}</div>
            @endisset
        </div>
    @endif

    <div class="card-body">
        {{ $slot }}
    </div>
</div>
