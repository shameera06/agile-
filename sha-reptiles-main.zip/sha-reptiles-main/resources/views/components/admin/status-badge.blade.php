{{--
    Reusable status badge: a small rounded pill (see .status-badge in
    admin-custom.css), colored by semantic variant.

    Usage:
        <x-admin.status-badge status="active" label="Active" />
        <x-admin.status-badge status="no_gain" label="No Gain" variant="no-gain" />

    `status` is the raw stored value (used to infer the variant when
    `variant` is omitted — underscores/spaces are normalized to dashes, e.g.
    "no_gain" and "no gain" both resolve to the "no-gain" variant below).
    `label` is the human-readable text to display; defaults to a
    title-cased version of `status`.
    `variant` overrides the inferred color when a module's own status value
    doesn't already match one of the names below (e.g. a "sold"/"transferred"
    reptile status can pass variant="inactive" to reuse the neutral color).

    Recognized variants (each maps to a color defined once in
    admin-custom.css): active, success, gain, completed/complete — green;
    inactive — neutral; pending, info — blue; warning, partial, no-gain —
    amber; danger, incomplete, problematic, loss — red.
--}}
@props([
    'status' => null,
    'label' => null,
    'variant' => null,
])

@php
    $key = strtolower(str_replace([' ', '_'], '-', $variant ?? $status ?? ''));

    $variantClasses = [
        'active' => 'status-active',
        'success' => 'status-success',
        'gain' => 'status-gain',
        'completed' => 'status-completed',
        'complete' => 'status-completed',

        'inactive' => 'status-inactive',

        'pending' => 'status-pending',
        'info' => 'status-info',

        'warning' => 'status-warning',
        'partial' => 'status-partial',
        'no-gain' => 'status-no-gain',

        'danger' => 'status-danger',
        'incomplete' => 'status-incomplete',
        'problematic' => 'status-problematic',
        'loss' => 'status-loss',
    ];

    $variantClass = $variantClasses[$key] ?? 'status-inactive';
    $text = $label ?? \Illuminate\Support\Str::headline($status ?? '');
@endphp

<span {{ $attributes->merge(['class' => "badge status-badge {$variantClass}"]) }}>{{ $text }}</span>
