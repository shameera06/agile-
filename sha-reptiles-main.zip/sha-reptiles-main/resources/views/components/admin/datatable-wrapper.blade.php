{{--
    Reusable listing card: a titled card containing a responsive table — the
    same white-card-with-uppercase-header look used for both a plain
    Bootstrap `.table` (manually paginated) and a Yajra/DataTables table (see
    admin-custom.css, which styles both identically).

    Usage with a plain Bootstrap table (manual pagination):
        <x-admin.datatable-wrapper title="Species List">
            <x-slot:actions>
                <a href="{{ route('admin.species.create') }}" class="btn btn-primary">+ Add Species</a>
            </x-slot:actions>
            <thead><tr><th>Name</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                @foreach ($species as $row)
                    <tr><td>{{ $row->name }}</td> ... </tr>
                @endforeach
            </tbody>
        </x-admin.datatable-wrapper>
        {{ $species->links() }}

    Usage with a Yajra DataTable (server-side ajax): pass the DataTable's own
    id/columns via `id`, and render the DataTable's `<thead>` normally — the
    DataTables JS (see assets/js/datatable-init.js) takes over pagination/
    search/sort once initialized against this same table id.
        <x-admin.datatable-wrapper id="medical-records-table" title="Medical Records">
            ...
        </x-admin.datatable-wrapper>
--}}
@props([
    'id' => null,
    'title' => null,
])

<div class="card">
    @if ($title || isset($actions))
        <div class="card-header d-flex align-items-center justify-content-between">
            @if ($title)
                <h5 class="card-title m-0">{{ $title }}</h5>
            @endif
            @isset($actions)
                <div class="d-flex gap-2">{{ $actions }}</div>
            @endisset
        </div>
    @endif

    <div class="card-body">
        <div class="table-responsive">
            <table {{ $attributes->merge(['class' => 'table']) }} @if ($id) id="{{ $id }}" @endif>
                {{ $slot }}
            </table>
        </div>
    </div>
</div>
