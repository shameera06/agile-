<?php

namespace Tests\Feature\Admin;

use App\Models\FoodType;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FoodTypeManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_cannot_access_food_types_index(): void
    {
        $response = $this->get(route('admin.food-types.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_access_food_types_index(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.food-types.index'));

        $response->assertOk();
        $response->assertViewIs('admin.food-types.index');
    }

    public function test_admin_can_open_create_page(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.food-types.create'));

        $response->assertOk();
        $response->assertViewIs('admin.food-types.create');
    }

    public function test_admin_can_create_a_top_level_food_type(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Mouse',
            'status' => '1',
        ]);

        $response->assertRedirect(route('admin.food-types.index'));
        $response->assertSessionHas('success', 'Food type created successfully.');
        $this->assertDatabaseHas('food_types', ['name' => 'Mouse', 'parent_id' => null]);
    }

    public function test_admin_can_create_a_child_food_type_under_an_active_parent(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);

        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Pinky',
            'parent_id' => $mouse->id,
            'status' => '1',
        ]);

        $response->assertRedirect(route('admin.food-types.index'));
        $this->assertDatabaseHas('food_types', ['name' => 'Pinky', 'parent_id' => $mouse->id]);
    }

    public function test_name_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => '',
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('name');
    }

    public function test_name_must_be_unique_within_the_same_parent(): void
    {
        FoodType::factory()->create(['name' => 'Mouse', 'parent_id' => null]);

        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Mouse',
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('name');
    }

    public function test_same_name_is_allowed_under_different_parents(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        $rat = FoodType::factory()->create(['name' => 'Rat', 'status' => true]);
        FoodType::factory()->create(['name' => 'Adult', 'parent_id' => $mouse->id]);

        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Adult',
            'parent_id' => $rat->id,
            'status' => '1',
        ]);

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('food_types', ['name' => 'Adult', 'parent_id' => $rat->id]);
    }

    public function test_only_active_top_level_categories_can_be_selected_as_parent(): void
    {
        $inactive = FoodType::factory()->create(['name' => 'Mouse', 'status' => false]);

        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Pinky',
            'parent_id' => $inactive->id,
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('parent_id');
    }

    public function test_a_child_cannot_be_selected_as_a_parent(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        $pinky = FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id, 'status' => true]);

        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Tiny',
            'parent_id' => $pinky->id,
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('parent_id');
    }

    public function test_description_is_optional(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.food-types.store'), [
            'name' => 'Cricket',
            'status' => '1',
        ]);

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('food_types', ['name' => 'Cricket', 'description' => null]);
    }

    public function test_admin_can_edit_food_type(): void
    {
        $foodType = FoodType::factory()->create(['name' => 'Mouse']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.food-types.edit', $foodType));

        $response->assertOk();
        $response->assertViewIs('admin.food-types.edit');
        $response->assertSee('Mouse');
    }

    public function test_admin_can_update_food_type(): void
    {
        $foodType = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);

        $response = $this->actingAs(User::factory()->create())->put(route('admin.food-types.update', $foodType), [
            'name' => 'Mouse',
            'status' => '0',
        ]);

        $response->assertRedirect(route('admin.food-types.index'));
        $response->assertSessionHas('success', 'Food type updated successfully.');
        $this->assertDatabaseHas('food_types', ['id' => $foodType->id, 'status' => false]);
    }

    public function test_updating_a_food_type_with_children_cannot_be_given_a_parent(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id]);
        $rat = FoodType::factory()->create(['name' => 'Rat', 'status' => true]);

        $response = $this->actingAs(User::factory()->create())->put(route('admin.food-types.update', $mouse), [
            'name' => 'Mouse',
            'parent_id' => $rat->id,
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('parent_id');
    }

    public function test_updating_keeps_an_inactive_current_parent_valid(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        $pinky = FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id]);
        $mouse->update(['status' => false]);

        $response = $this->actingAs(User::factory()->create())->put(route('admin.food-types.update', $pinky), [
            'name' => 'Pinky',
            'parent_id' => $mouse->id,
            'status' => '1',
        ]);

        $response->assertSessionDoesntHaveErrors();
    }

    public function test_admin_can_delete_a_leaf_food_type(): void
    {
        $foodType = FoodType::factory()->create();

        $response = $this->actingAs(User::factory()->create())->delete(route('admin.food-types.destroy', $foodType));

        $response->assertRedirect(route('admin.food-types.index'));
        $response->assertSessionHas('success', 'Food type deleted successfully.');
        $this->assertDatabaseMissing('food_types', ['id' => $foodType->id]);
    }

    public function test_a_category_with_sub_types_cannot_be_deleted(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse']);
        FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id]);

        $response = $this->actingAs(User::factory()->create())->delete(route('admin.food-types.destroy', $mouse));

        $response->assertRedirect(route('admin.food-types.index'));
        $response->assertSessionHas('error');
        $this->assertDatabaseHas('food_types', ['id' => $mouse->id]);
    }

    public function test_search_works_for_both_categories_and_sub_types(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse']);
        FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id]);
        FoodType::factory()->create(['name' => 'Cricket']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.food-types.index', ['search' => 'pinky']));

        $response->assertOk();
        // Checked against the actual result set rather than raw page text, since
        // "Cricket" also legitimately appears in the (unfiltered) category dropdown.
        $response->assertViewHas('foodTypes', function ($foodTypes) {
            return $foodTypes->total() === 1 && $foodTypes->first()->name === 'Pinky';
        });
    }

    public function test_status_filter_works(): void
    {
        FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        FoodType::factory()->create(['name' => 'Cricket', 'status' => false]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.food-types.index', ['status' => 'inactive']));

        $response->assertOk();
        // Checked against the actual result set rather than raw page text, since
        // "Mouse" also legitimately appears in the (unfiltered) category dropdown.
        $response->assertViewHas('foodTypes', function ($foodTypes) {
            return $foodTypes->total() === 1 && $foodTypes->first()->name === 'Cricket';
        });
    }

    public function test_top_level_only_filter_works(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse']);
        FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.food-types.index', ['parent_id' => 'top-level']));

        $response->assertOk();
        $response->assertSee('Mouse');
        $response->assertDontSee('Pinky');
    }

    public function test_category_filter_works(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse']);
        $rat = FoodType::factory()->create(['name' => 'Rat']);
        FoodType::factory()->create(['name' => 'Pinky', 'parent_id' => $mouse->id]);
        FoodType::factory()->create(['name' => 'Pup', 'parent_id' => $rat->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.food-types.index', ['parent_id' => $mouse->id]));

        $response->assertOk();
        $response->assertSee('Pinky');
        $response->assertDontSee('Pup');
    }

    public function test_pagination_preserves_query_parameters(): void
    {
        FoodType::factory()->count(20)->sequence(
            fn ($sequence) => ['name' => 'Snack '.$sequence->index]
        )->create();

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.food-types.index', ['search' => 'snack', 'page' => 2]));

        $response->assertOk();
        $response->assertViewHas('foodTypes', fn ($foodTypes) => $foodTypes->currentPage() === 2 && $foodTypes->total() === 20);
        $response->assertSee('search=snack');
    }

    public function test_empty_food_type_list_displays_successfully(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.food-types.index'));

        $response->assertOk();
        $response->assertSee('No food types found.');
        $response->assertSee('Add your first food type to begin managing feeding options.');
    }
}
