<?php

namespace Tests\Feature\Admin;

use App\Models\Species;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SpeciesManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_cannot_access_species_index(): void
    {
        $response = $this->get(route('admin.species.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_access_species_index(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.index'));

        $response->assertOk();
        $response->assertViewIs('admin.species.index');
    }

    public function test_admin_can_open_create_species_page(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.create'));

        $response->assertOk();
        $response->assertViewIs('admin.species.create');
    }

    public function test_admin_can_create_a_species(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.species.store'), [
            'name' => 'Ball Python',
            'scientific_name' => 'Python regius',
            'description' => 'A docile, commonly kept python species.',
            'status' => '1',
        ]);

        $response->assertRedirect(route('admin.species.index'));
        $response->assertSessionHas('success', 'Species created successfully.');

        $this->assertDatabaseHas('species', [
            'name' => 'Ball Python',
            'scientific_name' => 'Python regius',
            'status' => true,
        ]);
    }

    public function test_species_name_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.species.store'), [
            'name' => '',
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('name');
        $this->assertDatabaseCount('species', 0);
    }

    public function test_species_name_must_be_unique(): void
    {
        Species::factory()->create(['name' => 'Ball Python']);

        $response = $this->actingAs(User::factory()->create())->post(route('admin.species.store'), [
            'name' => 'Ball Python',
            'status' => '1',
        ]);

        $response->assertSessionHasErrors('name');
        $this->assertDatabaseCount('species', 1);
    }

    public function test_scientific_name_is_optional(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.species.store'), [
            'name' => 'Corn Snake',
            'status' => '1',
        ]);

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('species', [
            'name' => 'Corn Snake',
            'scientific_name' => null,
        ]);
    }

    public function test_description_is_optional(): void
    {
        $response = $this->actingAs(User::factory()->create())->post(route('admin.species.store'), [
            'name' => 'Corn Snake',
            'status' => '1',
        ]);

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('species', [
            'name' => 'Corn Snake',
            'description' => null,
        ]);
    }

    public function test_status_can_be_active_or_inactive(): void
    {
        $this->actingAs(User::factory()->create())->post(route('admin.species.store'), [
            'name' => 'Leopard Gecko',
            'status' => '0',
        ]);

        $this->assertDatabaseHas('species', [
            'name' => 'Leopard Gecko',
            'status' => false,
        ]);
    }

    public function test_admin_can_edit_a_species(): void
    {
        $species = Species::factory()->create(['name' => 'Ball Python']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.edit', $species));

        $response->assertOk();
        $response->assertViewIs('admin.species.edit');
        $response->assertSee('Ball Python');
    }

    public function test_admin_can_update_a_species(): void
    {
        $species = Species::factory()->create(['name' => 'Ball Python', 'status' => true]);

        $response = $this->actingAs(User::factory()->create())->put(route('admin.species.update', $species), [
            'name' => 'Ball Python',
            'scientific_name' => 'Python regius',
            'status' => '0',
        ]);

        $response->assertRedirect(route('admin.species.index'));
        $response->assertSessionHas('success', 'Species updated successfully.');

        $this->assertDatabaseHas('species', [
            'id' => $species->id,
            'status' => false,
        ]);
    }

    public function test_updating_a_species_ignores_its_own_name_for_uniqueness(): void
    {
        $species = Species::factory()->create(['name' => 'Ball Python']);

        $response = $this->actingAs(User::factory()->create())->put(route('admin.species.update', $species), [
            'name' => 'Ball Python',
            'status' => '1',
        ]);

        $response->assertSessionDoesntHaveErrors();
    }

    public function test_admin_can_delete_a_species(): void
    {
        $species = Species::factory()->create();

        $response = $this->actingAs(User::factory()->create())->delete(route('admin.species.destroy', $species));

        $response->assertRedirect(route('admin.species.index'));
        $response->assertSessionHas('success', 'Species deleted successfully.');
        $this->assertDatabaseMissing('species', ['id' => $species->id]);
    }

    public function test_search_works(): void
    {
        Species::factory()->create(['name' => 'Ball Python', 'scientific_name' => 'Python regius']);
        Species::factory()->create(['name' => 'Green Iguana', 'scientific_name' => 'Iguana iguana']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.species.index', ['search' => 'python']));

        $response->assertOk();
        $response->assertSee('Ball Python');
        $response->assertDontSee('Green Iguana');
    }

    public function test_status_filter_works(): void
    {
        Species::factory()->create(['name' => 'Ball Python', 'status' => true]);
        Species::factory()->create(['name' => 'Green Iguana', 'status' => false]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.species.index', ['status' => 'inactive']));

        $response->assertOk();
        $response->assertSee('Green Iguana');
        $response->assertDontSee('Ball Python');
    }

    public function test_pagination_works(): void
    {
        Species::factory()->count(20)->sequence(
            fn ($sequence) => ['name' => 'Species '.$sequence->index]
        )->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.index'));

        $response->assertOk();
        $response->assertViewHas('species', function ($species) {
            return $species->count() === 15 && $species->hasMorePages();
        });
    }

    public function test_query_parameters_are_preserved_during_pagination(): void
    {
        Species::factory()->count(20)->sequence(
            fn ($sequence) => ['name' => 'Python Species '.$sequence->index]
        )->create();

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.species.index', ['search' => 'python', 'page' => 2]));

        $response->assertOk();
        // The remaining 5 matches should be on page 2.
        $response->assertViewHas('species', fn ($species) => $species->currentPage() === 2 && $species->total() === 20);
        // The pagination links (e.g. "Previous") must still carry the search term.
        $response->assertSee('search=python');
    }

    public function test_empty_species_list_displays_successfully(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.index'));

        $response->assertOk();
        $response->assertSee('No species found.');
        $response->assertSee('Add your first species to begin managing reptile records.');
    }
}
