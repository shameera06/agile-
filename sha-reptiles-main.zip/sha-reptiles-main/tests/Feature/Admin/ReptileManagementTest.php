<?php

namespace Tests\Feature\Admin;

use App\Models\Reptile;
use App\Models\Species;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ReptileManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function validPayload(array $overrides = []): array
    {
        return array_merge([
            'species_id' => Species::factory()->create(['status' => true])->id,
            'name' => 'Rocky',
            'sex' => 'male',
            'status' => 'active',
        ], $overrides);
    }

    public function test_guest_cannot_access_reptiles(): void
    {
        $response = $this->get(route('admin.reptiles.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_view_reptile_index(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.index'));

        $response->assertOk();
        $response->assertViewIs('admin.reptiles.index');
    }

    public function test_admin_can_open_create_page(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.create'));

        $response->assertOk();
        $response->assertViewIs('admin.reptiles.create');
    }

    public function test_admin_can_create_reptile(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload([
                'name' => 'Rocky',
                'current_weight' => 450,
                'weight_unit' => 'g',
            ]));

        $reptile = Reptile::first();

        $response->assertRedirect(route('admin.reptiles.show', $reptile));
        $response->assertSessionHas('success', 'Reptile created successfully.');
        $this->assertDatabaseHas('reptiles', [
            'name' => 'Rocky',
            'current_weight' => 450,
        ]);
    }

    public function test_species_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['species_id' => '']));

        $response->assertSessionHasErrors('species_id');
        $this->assertDatabaseCount('reptiles', 0);
    }

    public function test_only_existing_species_can_be_selected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['species_id' => 999999]));

        $response->assertSessionHasErrors('species_id');
        $this->assertDatabaseCount('reptiles', 0);
    }

    public function test_only_active_species_can_be_selected_for_new_reptiles(): void
    {
        $inactiveSpecies = Species::factory()->create(['status' => false]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['species_id' => $inactiveSpecies->id]));

        $response->assertSessionHasErrors('species_id');
        $this->assertDatabaseCount('reptiles', 0);
    }

    public function test_reptile_name_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['name' => '']));

        $response->assertSessionHasErrors('name');
    }

    public function test_sex_validation_works(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['sex' => 'not-a-sex']));

        $response->assertSessionHasErrors('sex');
    }

    public function test_future_date_of_birth_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload([
                'date_of_birth' => now()->addDay()->toDateString(),
            ]));

        $response->assertSessionHasErrors('date_of_birth');
    }

    public function test_future_acquisition_date_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload([
                'acquisition_date' => now()->addDay()->toDateString(),
            ]));

        $response->assertSessionHasErrors('acquisition_date');
    }

    public function test_weight_cannot_be_negative(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['current_weight' => -5]));

        $response->assertSessionHasErrors('current_weight');
    }

    public function test_length_cannot_be_negative(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['length' => -1]));

        $response->assertSessionHasErrors('length');
    }

    public function test_invalid_status_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload(['status' => 'hibernating']));

        $response->assertSessionHasErrors('status');
    }

    public function test_invalid_image_type_is_rejected(): void
    {
        Storage::fake('public');

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload([
                'photo' => UploadedFile::fake()->create('document.pdf', 100, 'application/pdf'),
            ]));

        $response->assertSessionHasErrors('photo');
    }

    public function test_image_larger_than_configured_limit_is_rejected(): void
    {
        Storage::fake('public');

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.reptiles.store'), $this->validPayload([
                'photo' => UploadedFile::fake()->image('too-big.jpg')->size(5121),
            ]));

        $response->assertSessionHasErrors('photo');
    }

    public function test_reptile_code_is_generated_automatically(): void
    {
        $this->actingAs(User::factory()->create())->post(route('admin.reptiles.store'), $this->validPayload());

        $reptile = Reptile::first();

        $this->assertNotNull($reptile->reptile_code);
        $this->assertSame('REP-'.str_pad((string) $reptile->id, 6, '0', STR_PAD_LEFT), $reptile->reptile_code);
    }

    public function test_reptile_code_is_unique(): void
    {
        $user = $this->actingAs(User::factory()->create());

        $user->post(route('admin.reptiles.store'), $this->validPayload());
        $user->post(route('admin.reptiles.store'), $this->validPayload());

        $codes = Reptile::pluck('reptile_code');

        $this->assertCount(2, $codes);
        $this->assertCount(2, $codes->unique());
    }

    public function test_admin_can_view_reptile_details(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptile));

        $response->assertOk();
        $response->assertViewIs('admin.reptiles.show');
        $response->assertSee('Rocky');
        $response->assertSee($reptile->reptile_code);
    }

    public function test_admin_can_edit_reptile(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.edit', $reptile));

        $response->assertOk();
        $response->assertViewIs('admin.reptiles.edit');
        $response->assertSee('Rocky');
    }

    public function test_admin_can_update_reptile(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);

        $response = $this->actingAs(User::factory()->create())
            ->put(route('admin.reptiles.update', $reptile), [
                'species_id' => $reptile->species_id,
                'name' => 'Rocky Updated',
                'sex' => $reptile->sex,
                'status' => 'active',
            ]);

        $response->assertRedirect(route('admin.reptiles.show', $reptile));
        $response->assertSessionHas('success', 'Reptile updated successfully.');
        $this->assertDatabaseHas('reptiles', ['id' => $reptile->id, 'name' => 'Rocky Updated']);
    }

    public function test_admin_can_archive_reptile(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->patch(route('admin.reptiles.archive', $reptile));

        $response->assertRedirect(route('admin.reptiles.index'));
        $response->assertSessionHas('success', 'Reptile archived successfully.');
        $this->assertDatabaseHas('reptiles', ['id' => $reptile->id, 'status' => 'inactive']);
    }

    public function test_archiving_does_not_clear_other_reptile_fields(): void
    {
        $reptile = Reptile::factory()->create([
            'status' => 'active',
            'current_weight' => 450,
            'notes' => 'Very active and handles well.',
        ]);

        $this->actingAs(User::factory()->create())->patch(route('admin.reptiles.archive', $reptile));

        $this->assertDatabaseHas('reptiles', [
            'id' => $reptile->id,
            'status' => 'inactive',
            'current_weight' => 450,
            'notes' => 'Very active and handles well.',
        ]);
    }

    public function test_search_by_name_works(): void
    {
        Reptile::factory()->create(['name' => 'Rocky']);
        Reptile::factory()->create(['name' => 'Luna']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.index', ['search' => 'rocky']));

        $response->assertOk();
        $response->assertSee('Rocky');
        $response->assertDontSee('Luna');
    }

    public function test_search_by_reptile_code_works(): void
    {
        $rocky = Reptile::factory()->create(['name' => 'Rocky', 'reptile_code' => 'REP-000001']);
        Reptile::factory()->create(['name' => 'Luna', 'reptile_code' => 'REP-000002']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.index', ['search' => 'REP-000001']));

        $response->assertOk();
        $response->assertSee($rocky->name);
        $response->assertDontSee('Luna');
    }

    public function test_species_filtering_works(): void
    {
        $ballPython = Species::factory()->create(['name' => 'Ball Python']);
        $iguana = Species::factory()->create(['name' => 'Green Iguana']);

        Reptile::factory()->create(['name' => 'Rocky', 'species_id' => $ballPython->id]);
        Reptile::factory()->create(['name' => 'Luna', 'species_id' => $iguana->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.index', ['species_id' => $ballPython->id]));

        $response->assertOk();
        $response->assertSee('Rocky');
        $response->assertDontSee('Luna');
    }

    public function test_status_filtering_works(): void
    {
        Reptile::factory()->create(['name' => 'Rocky', 'status' => 'active']);
        Reptile::factory()->create(['name' => 'Luna', 'status' => 'inactive']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.index', ['status' => 'inactive']));

        $response->assertOk();
        $response->assertSee('Luna');
        $response->assertDontSee('Rocky');
    }

    public function test_sex_filtering_works(): void
    {
        Reptile::factory()->create(['name' => 'Rocky', 'sex' => 'male']);
        Reptile::factory()->create(['name' => 'Luna', 'sex' => 'female']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.index', ['sex' => 'female']));

        $response->assertOk();
        $response->assertSee('Luna');
        $response->assertDontSee('Rocky');
    }

    public function test_multiple_filters_work_together(): void
    {
        $ballPython = Species::factory()->create(['name' => 'Ball Python']);

        Reptile::factory()->create([
            'name' => 'Rocky', 'species_id' => $ballPython->id, 'status' => 'active', 'sex' => 'male',
        ]);
        Reptile::factory()->create([
            'name' => 'Rocky', 'species_id' => $ballPython->id, 'status' => 'inactive', 'sex' => 'male',
        ]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.index', [
            'search' => 'rocky',
            'species_id' => $ballPython->id,
            'status' => 'active',
            'sex' => 'male',
        ]));

        $response->assertOk();
        $response->assertViewHas('reptiles', fn ($reptiles) => $reptiles->total() === 1);
    }

    public function test_pagination_preserves_query_parameters(): void
    {
        Reptile::factory()->count(20)->sequence(
            fn ($sequence) => [
                'name' => 'Rocky '.$sequence->index,
                'reptile_code' => 'REP-'.str_pad((string) ($sequence->index + 1), 6, '0', STR_PAD_LEFT),
            ]
        )->create();

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.index', ['search' => 'rocky', 'page' => 2]));

        $response->assertOk();
        $response->assertViewHas('reptiles', fn ($reptiles) => $reptiles->currentPage() === 2 && $reptiles->total() === 20);
        $response->assertSee('search=rocky');
    }

    public function test_dashboard_reptile_count_is_correct(): void
    {
        Reptile::factory()->count(3)->create(['status' => 'active']);
        Reptile::factory()->count(2)->create(['status' => 'inactive']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.dashboard'));

        $response->assertOk();
        $response->assertViewHas('totalReptiles', 5);
        $response->assertViewHas('activeReptiles', 3);
    }

    public function test_referenced_species_cannot_be_deleted(): void
    {
        $species = Species::factory()->create();
        Reptile::factory()->create(['species_id' => $species->id]);

        $response = $this->actingAs(User::factory()->create())
            ->delete(route('admin.species.destroy', $species));

        $response->assertRedirect(route('admin.species.index'));
        $response->assertSessionHas('error');
        $this->assertDatabaseHas('species', ['id' => $species->id]);
    }

    public function test_empty_reptile_list_displays_correctly(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.index'));

        $response->assertOk();
        $response->assertSee('No reptiles found.');
        $response->assertSee('Add your first reptile to begin managing your collection.');
    }
}
