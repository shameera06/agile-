<?php

namespace Tests\Feature\Admin;

use App\Mail\WeightConcernCreated;
use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\HealthAlert;
use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\SpeciesVariety;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

/**
 * Module 10 — Health Monitoring + Alerts. Reuses Module 7's existing
 * WeightMonitoringService/FeedingRecord logic as the sole source of truth
 * for weight calculations — see HealthAlertService — and never duplicates
 * that algorithm here.
 */
class HealthAlertManagementTest extends TestCase
{
    use RefreshDatabase;

    // 1-3: access -----------------------------------------------------------

    public function test_guest_cannot_access_health_alerts(): void
    {
        $response = $this->get(route('admin.health-alerts.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_access_health_alerts(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())->get(route('admin.health-alerts.index'));

        $response->assertOk();
        $response->assertViewIs('admin.health-alerts.index');
    }

    public function test_staff_can_access_health_alerts(): void
    {
        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))->get(route('admin.health-alerts.index'));

        $response->assertOk();
    }

    // 4-9, realistic scenario: weight alert generation -----------------------

    /**
     * Posts one feeding record for the given schedule through the real
     * admin.feeding-records.store endpoint — i.e. through Module 7's actual
     * existing controller/service, never by hand-crafting a FeedingRecord
     * row — so the weight_trend/weight_alert_triggered result (and
     * therefore the HealthAlert this test asserts on) is produced by the
     * real, unmodified Module 7 logic.
     */
    protected function postFeedingRecord(User $user, FeedingSchedule $schedule, float $weightBefore, float $weightAfter): TestResponse
    {
        return $this->actingAs($user)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id,
            'feeding_date' => now()->toDateTimeString(),
            'quantity' => $schedule->quantity,
            'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => $weightBefore,
            'weight_after' => $weightAfter,
        ]);
    }

    public function test_weight_alert_is_created_when_module_7_weight_logic_triggers_it(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        // A baseline record first: the very first feeding record of a
        // reptile's history has no previous record to compare against, so
        // WeightMonitoringService leaves its trend null (neither a gain nor
        // a poor-gain) — matching its own documented behavior. That's still
        // one of the three records the alert evaluates: the alert fires on
        // the record that completes a three-record sequence with no gain,
        // which here is record 3 itself.
        $this->postFeedingRecord($admin, $schedule, 400, 400); // baseline
        $this->postFeedingRecord($admin, $schedule, 400, 400); // Record 2: no_gain

        $this->assertDatabaseCount('health_alerts', 0);

        // Record 3: 400 -> 395, a loss. Together with the baseline and
        // record 2 this completes a three-record no-gain sequence — the
        // alert must trigger immediately on this record.
        $this->postFeedingRecord($admin, $schedule, 400, 395);

        $record3 = FeedingRecord::where('reptile_id', $reptile->id)->orderByDesc('id')->first();
        $this->assertTrue((bool) $record3->weight_alert_triggered);

        $this->assertDatabaseCount('health_alerts', 1);

        $alert = HealthAlert::first();
        $this->assertSame($reptile->id, $alert->reptile_id);
        $this->assertSame($record3->id, $alert->feeding_record_id);
        $this->assertSame('weight', $alert->alert_type);
        $this->assertSame('active', $alert->status);
        $this->assertSame('warning', $alert->severity);
        $this->assertSame('feeding_record', $alert->source);
    }

    public function test_weight_alert_message_exactly_matches_the_module_7_warning(): void
    {
        [$reptile, $schedule, $admin] = $this->buildTriggeringHistory();

        $this->postFeedingRecord($admin, $schedule, 395, 396);

        $alert = HealthAlert::first();
        $this->assertSame(
            'The reptile is not gaining weight properly. Please consult a veterinarian.',
            $alert->message
        );
    }

    public function test_fewer_than_three_previous_poor_gain_records_does_not_create_an_alert(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        // Only two records exist — one short of the three-record sequence
        // required to trigger the alert.
        $this->postFeedingRecord($admin, $schedule, 400, 400); // baseline
        $this->postFeedingRecord($admin, $schedule, 400, 400); // no_gain

        $this->assertDatabaseCount('health_alerts', 0);
    }

    public function test_duplicate_alert_is_not_created_for_the_same_feeding_record(): void
    {
        [$reptile, $schedule, $admin] = $this->buildTriggeringHistory();

        // Record 3: 395 -> 396, a loss relative to the 400 baseline — this
        // completes the no-gain sequence and triggers the alert.
        $this->postFeedingRecord($admin, $schedule, 395, 396);
        $record3 = FeedingRecord::where('reptile_id', $reptile->id)->orderByDesc('id')->first();
        $this->assertDatabaseCount('health_alerts', 1);

        // Record 4: an actual gain, which breaks the no-gain streak (the
        // window for record 4 now includes a gain) — must not duplicate
        // record 3's existing alert, even though saving it reprocesses the
        // reptile's entire weight history.
        $this->postFeedingRecord($admin, $schedule, 396, 410);

        $this->assertDatabaseCount('health_alerts', 1);
        $this->assertDatabaseHas('health_alerts', ['feeding_record_id' => $record3->id]);
    }

    // Weight Concern email notifications --------------------------------------

    public function test_creating_a_weight_alert_emails_every_admin_user(): void
    {
        Mail::fake();

        $admin1 = User::factory()->admin()->create();
        $admin2 = User::factory()->admin()->create();
        User::factory()->create(['role' => 'staff']); // must NOT receive the email

        [, $schedule, $poster] = $this->buildTriggeringHistory();
        $this->postFeedingRecord($poster, $schedule, 395, 396);

        $alert = HealthAlert::first();

        Mail::assertSent(WeightConcernCreated::class, function ($mail) use ($alert, $admin1, $admin2) {
            return $mail->healthAlert->is($alert)
                && $mail->hasTo($admin1->email)
                && $mail->hasTo($admin2->email);
        });
    }

    public function test_staff_users_never_receive_the_weight_concern_email(): void
    {
        Mail::fake();

        $staff = User::factory()->create(['role' => 'staff']);
        [, $schedule, $poster] = $this->buildTriggeringHistory();
        $this->postFeedingRecord($poster, $schedule, 395, 396);

        Mail::assertSent(WeightConcernCreated::class, function ($mail) use ($staff) {
            return ! $mail->hasTo($staff->email);
        });
    }

    public function test_resaving_a_record_that_creates_no_new_alert_sends_no_extra_email(): void
    {
        Mail::fake();

        User::factory()->admin()->create();
        [$reptile, $schedule, $admin] = $this->buildTriggeringHistory();
        $this->postFeedingRecord($admin, $schedule, 395, 396);

        Mail::assertSentCount(1);

        // A further feeding record that does NOT meet the previous-three
        // condition must not create (or email about) a second alert.
        $this->postFeedingRecord($admin, $schedule, 396, 410);

        Mail::assertSentCount(1);
    }

    /**
     * Builds a reptile with exactly the "baseline + no_gain" history that
     * the next feeding record (record 3) will complete a three-record
     * no-gain sequence from and trigger an alert — shared setup for several
     * scenarios above.
     *
     * @return array{0: Reptile, 1: FeedingSchedule, 2: User}
     */
    protected function buildTriggeringHistory(): array
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        $this->postFeedingRecord($admin, $schedule, 400, 400); // baseline
        $this->postFeedingRecord($admin, $schedule, 400, 400); // no_gain

        return [$reptile, $schedule, $admin];
    }

    // 10-11: reptile isolation / species hierarchy ---------------------------

    public function test_alert_belongs_to_the_correct_reptile_and_is_isolated_from_another_reptiles_alerts(): void
    {
        $reptileA = Reptile::factory()->create(['name' => 'Royal Python 001']);
        $reptileB = Reptile::factory()->create(['name' => 'Royal Python 002']);

        HealthAlert::factory()->create(['reptile_id' => $reptileA->id, 'title' => 'Alert A only']);
        HealthAlert::factory()->create(['reptile_id' => $reptileB->id, 'title' => 'Alert B only']);

        $user = $this->actingAs(User::factory()->create());

        $pageA = $user->get(route('admin.reptiles.show', $reptileA));
        $pageA->assertViewHas('healthAlerts', fn ($alerts) => $alerts->count() === 1 && $alerts->first()->reptile_id === $reptileA->id);
        $pageA->assertSee('Alert A only');
        $pageA->assertDontSee('Alert B only');

        $pageB = $user->get(route('admin.reptiles.show', $reptileB));
        $pageB->assertViewHas('healthAlerts', fn ($alerts) => $alerts->count() === 1 && $alerts->first()->reptile_id === $reptileB->id);
        $pageB->assertSee('Alert B only');
        $pageB->assertDontSee('Alert A only');
    }

    public function test_nested_species_hierarchy_access_keeps_health_alerts_isolated_per_individual(): void
    {
        $snake = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $pythonSnake = Species::factory()->create(['name' => 'Python Snake', 'category_id' => $snake->id]);
        $royalPython = SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Royal Python']);

        $rp001 = Reptile::factory()->create([
            'name' => 'Royal Python 001', 'species_id' => $pythonSnake->id, 'species_variety_id' => $royalPython->id,
        ]);
        $rp002 = Reptile::factory()->create([
            'name' => 'Royal Python 002', 'species_id' => $pythonSnake->id, 'species_variety_id' => $royalPython->id,
        ]);

        HealthAlert::factory()->create(['reptile_id' => $rp001->id, 'message' => 'RP001 alert only']);
        HealthAlert::factory()->create(['reptile_id' => $rp002->id, 'message' => 'RP002 alert only']);

        $user = $this->actingAs(User::factory()->create());

        // Reached via Snake > Python Snake > Royal Python > Royal Python 001.
        $profile001 = $user->get(route('admin.reptiles.show', $rp001));
        $profile001->assertSee('RP001 alert only');
        $profile001->assertDontSee('RP002 alert only');

        $profile002 = $user->get(route('admin.reptiles.show', $rp002));
        $profile002->assertSee('RP002 alert only');
        $profile002->assertDontSee('RP001 alert only');
    }

    // 12-15: resolve --------------------------------------------------------

    public function test_admin_can_resolve_an_alert(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->admin()->create())
            ->patch(route('admin.health-alerts.resolve', $alert), ['notes' => 'Vet confirmed improvement.']);

        $response->assertRedirect(route('admin.health-alerts.show', $alert));
        $response->assertSessionHas('success', 'Health alert resolved successfully.');
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'resolved']);
    }

    public function test_resolved_alert_stores_resolved_at_and_resolved_by(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active']);
        $admin = User::factory()->admin()->create();

        $this->actingAs($admin)->patch(route('admin.health-alerts.resolve', $alert), ['notes' => 'Vet confirmed improvement.']);

        $alert->refresh();
        $this->assertNotNull($alert->resolved_at);
        $this->assertSame($admin->id, $alert->resolved_by);
    }

    public function test_resolved_alert_remains_in_history(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active']);

        $this->actingAs(User::factory()->admin()->create())
            ->patch(route('admin.health-alerts.resolve', $alert), ['notes' => 'Vet confirmed improvement.']);

        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'resolved']);
        $this->assertDatabaseCount('health_alerts', 1);
    }

    // 12b: resolving without documentation is blocked ------------------------

    public function test_resolving_without_any_documentation_is_blocked(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active', 'notes' => null]);

        $response = $this->actingAs(User::factory()->admin()->create())
            ->patch(route('admin.health-alerts.resolve', $alert));

        $response->assertSessionHasErrors('notes');
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'active']);
    }

    public function test_resolving_succeeds_when_notes_were_already_documented_earlier(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active', 'notes' => 'Staff observed reptile eating normally again.']);
        $admin = User::factory()->admin()->create();

        // No notes submitted with the resolve request itself — the
        // already-stored documentation is sufficient.
        $response = $this->actingAs($admin)->patch(route('admin.health-alerts.resolve', $alert));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'resolved']);
    }

    // 16-17: staff cannot resolve/dismiss/delete -----------------------------

    public function test_staff_cannot_resolve_an_alert(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->patch(route('admin.health-alerts.resolve', $alert));

        $response->assertForbidden();
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'active']);
    }

    public function test_staff_cannot_dismiss_an_alert(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->patch(route('admin.health-alerts.dismiss', $alert));

        $response->assertForbidden();
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'active']);
    }

    public function test_alert_cannot_be_deleted_through_the_normal_ui(): void
    {
        $alert = HealthAlert::factory()->create();

        // No destroy route is registered at all (health-alerts resource is
        // ->only(['index', 'show'])) — the same URI only answers to GET.
        $response = $this->actingAs(User::factory()->admin()->create())
            ->delete('/admin/health-alerts/'.$alert->id);

        $response->assertStatus(405);
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id]);
    }

    // 18-23: DataTable --------------------------------------------------------------

    protected function ajaxDataTableRequest(string $url, User $user): TestResponse
    {
        return $this->actingAs($user)
            ->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
            ->getJson($url);
    }

    /**
     * The `columns[i][...]` request parameters a real DataTables client
     * always sends alongside `order`/`search`, describing each of the
     * DataTable's 8 columns (see HealthAlertDataTable::getColumns()) so the
     * server can resolve an `order` column index to a column name.
     */
    protected function dataTableColumnsParam(): array
    {
        $names = [
            'reptile_name', 'alert_type_label', 'title', 'severity_badge',
            'status_badge', 'triggered_at', 'source_label', 'actions',
        ];

        return collect($names)->map(fn ($name) => [
            'data' => $name,
            'name' => '',
            'searchable' => 'true',
            'orderable' => ! in_array($name, ['severity_badge', 'status_badge', 'actions']) ? 'true' : 'false',
            'search' => ['value' => '', 'regex' => 'false'],
        ])->all();
    }

    public function test_datatable_loads_correctly(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);
        HealthAlert::factory()->create(['reptile_id' => $reptile->id, 'title' => 'Test alert title']);

        $response = $this->ajaxDataTableRequest(
            route('admin.health-alerts.index', [
                'draw' => 1, 'start' => 0, 'length' => 10, 'columns' => $this->dataTableColumnsParam(),
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 1);
        $response->assertSee('Test alert title', false);
    }

    public function test_datatable_search_works(): void
    {
        $rocky = Reptile::factory()->create(['name' => 'UniqueRockyName']);
        $luna = Reptile::factory()->create(['name' => 'UniqueLunaName']);
        HealthAlert::factory()->create(['reptile_id' => $rocky->id]);
        HealthAlert::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->ajaxDataTableRequest(
            route('admin.health-alerts.index', [
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(),
                'search' => ['value' => 'UniqueRockyName', 'regex' => 'false'],
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsFiltered', 1);
    }

    public function test_datatable_pagination_works(): void
    {
        HealthAlert::factory()->count(20)->create();

        $response = $this->ajaxDataTableRequest(
            route('admin.health-alerts.index', [
                'draw' => 1, 'start' => 0, 'length' => 10, 'columns' => $this->dataTableColumnsParam(),
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 20);
        $this->assertCount(10, $response->json('data'));
    }

    public function test_datatable_sorting_works(): void
    {
        $older = HealthAlert::factory()->create(['triggered_at' => now()->subDays(10)]);
        $newer = HealthAlert::factory()->create(['triggered_at' => now()->subDay()]);

        // Column index 5 = triggered_at, dir desc (matches the default order).
        $response = $this->ajaxDataTableRequest(
            route('admin.health-alerts.index', [
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(),
                'order' => [['column' => 5, 'dir' => 'desc']],
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $data = $response->json('data');
        $this->assertSame((string) $newer->id, (string) $data[0]['DT_RowId']);
    }

    public function test_datatable_filters_work(): void
    {
        HealthAlert::factory()->create(['severity' => 'warning', 'status' => 'active']);
        HealthAlert::factory()->create(['severity' => 'warning', 'status' => 'resolved']);

        $response = $this->ajaxDataTableRequest(
            route('admin.health-alerts.index', [
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(),
                'status' => 'active',
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 1);
    }

    public function test_datatable_query_avoids_n_plus_one_queries(): void
    {
        HealthAlert::factory()->count(10)->create();

        DB::enableQueryLog();

        $this->ajaxDataTableRequest(
            route('admin.health-alerts.index', [
                'draw' => 1, 'start' => 0, 'length' => 10, 'columns' => $this->dataTableColumnsParam(),
            ]),
            User::factory()->create()
        )->assertOk();

        $queryCount = count(DB::getQueryLog());
        DB::disableQueryLog();

        // A handful of fixed queries (count, filtered count, page of rows,
        // eager-loaded reptiles, eager-loaded resolvers, session/auth)
        // rather than one additional query per row.
        $this->assertLessThan(15, $queryCount);
    }

    // 24: reptile profile ------------------------------------------------------------

    public function test_reptile_profile_displays_active_alerts(): void
    {
        $reptile = Reptile::factory()->create();
        HealthAlert::factory()->create([
            'reptile_id' => $reptile->id,
            'status' => 'active',
            'title' => 'Weight Gain Alert',
            'message' => 'The reptile is not gaining weight properly. Please consult a veterinarian.',
        ]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptile));

        $response->assertOk();
        $response->assertSee('Weight Gain Alert');
        $response->assertSee('The reptile is not gaining weight properly. Please consult a veterinarian.');
    }

    // 25-26: dashboard ----------------------------------------------------------------

    public function test_dashboard_active_alert_count_is_correct(): void
    {
        HealthAlert::factory()->count(3)->create(['status' => 'active']);
        HealthAlert::factory()->count(2)->create(['status' => 'resolved']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.dashboard'));

        $response->assertOk();
        $response->assertViewHas('activeHealthAlerts', 3);
    }

    public function test_dashboard_attention_required_count_matches_reptiles_with_active_alerts(): void
    {
        $reptileWithAlert = Reptile::factory()->create();
        $reptileWithTwoAlerts = Reptile::factory()->create();
        $reptileWithoutAlert = Reptile::factory()->create();

        HealthAlert::factory()->create(['reptile_id' => $reptileWithAlert->id, 'status' => 'active']);
        HealthAlert::factory()->create(['reptile_id' => $reptileWithTwoAlerts->id, 'status' => 'active']);
        HealthAlert::factory()->create(['reptile_id' => $reptileWithTwoAlerts->id, 'status' => 'active']);
        HealthAlert::factory()->create(['reptile_id' => $reptileWithoutAlert->id, 'status' => 'resolved']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.dashboard'));

        $response->assertOk();
        // Two distinct reptiles have an active alert — resolved-only and
        // no-alert reptiles don't count, and a reptile with two active
        // alerts is still counted once.
        $response->assertViewHas('attentionRequiredReptiles', 2);
    }

    public function test_reptile_management_list_shows_attention_badge_for_reptiles_with_active_alerts(): void
    {
        $normal = Reptile::factory()->create(['name' => 'Normal Reptile']);
        $needsAttention = Reptile::factory()->create(['name' => 'Attention Reptile']);
        HealthAlert::factory()->create(['reptile_id' => $needsAttention->id, 'status' => 'active']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.index'));

        $response->assertOk();
        $response->assertSee('Attention');
        $response->assertSee('Normal');
    }

    // Document action taken (any authenticated user) --------------------------

    public function test_staff_can_document_action_taken_on_an_active_concern(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'active', 'notes' => null]);

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->patch(route('admin.health-alerts.update', $alert), ['notes' => 'Offered food, reptile refused.']);

        $response->assertRedirect(route('admin.health-alerts.show', $alert));
        $response->assertSessionHas('success', 'Action notes saved.');
        $this->assertDatabaseHas('health_alerts', [
            'id' => $alert->id,
            'status' => 'active',
            'notes' => 'Offered food, reptile refused.',
        ]);
    }

    public function test_documenting_action_can_include_a_valid_evidence_file(): void
    {
        Storage::fake('private');
        $alert = HealthAlert::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create())->patch(route('admin.health-alerts.update', $alert), [
            'notes' => 'Photo of enclosure attached.',
            'evidence' => UploadedFile::fake()->image('enclosure.jpg'),
        ]);

        $response->assertRedirect(route('admin.health-alerts.show', $alert));
        $alert->refresh();
        $this->assertTrue($alert->hasEvidence());
        Storage::disk('private')->assertExists($alert->evidence_path);
    }

    public function test_documenting_action_rejects_an_invalid_file_type(): void
    {
        Storage::fake('private');
        $alert = HealthAlert::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create())->patch(route('admin.health-alerts.update', $alert), [
            'evidence' => UploadedFile::fake()->create('malware.exe', 10),
        ]);

        $response->assertSessionHasErrors('evidence');
        $this->assertFalse($alert->fresh()->hasEvidence());
    }

    public function test_a_resolved_concern_can_no_longer_be_updated_with_action_notes(): void
    {
        $alert = HealthAlert::factory()->create(['status' => 'resolved']);

        $response = $this->actingAs(User::factory()->create())
            ->patch(route('admin.health-alerts.update', $alert), ['notes' => 'Too late.']);

        $response->assertSessionHasErrors('status');
    }

    public function test_evidence_is_only_reachable_through_the_authenticated_route(): void
    {
        Storage::fake('private');
        $alert = HealthAlert::factory()->create();
        $alert->update(['evidence_path' => Storage::disk('private')->putFile('weight-concern-evidence', UploadedFile::fake()->image('proof.jpg'))]);

        $guestResponse = $this->get(route('admin.health-alerts.evidence', $alert));
        $guestResponse->assertRedirect(route('admin.login'));

        $userResponse = $this->actingAs(User::factory()->create())->get(route('admin.health-alerts.evidence', $alert));
        $userResponse->assertOk();
    }

    public function test_evidence_route_404s_when_none_is_attached(): void
    {
        $alert = HealthAlert::factory()->create(['evidence_path' => null]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.health-alerts.evidence', $alert));

        $response->assertNotFound();
    }
}
