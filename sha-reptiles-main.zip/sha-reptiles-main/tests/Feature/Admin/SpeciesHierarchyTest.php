<?php

namespace Tests\Feature\Admin;

use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\SpeciesVariety;
use App\Models\SheddingRecord;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Covers the Species → Category → Species Type → Variety → Individual
 * Reptile browse hierarchy added alongside (not replacing) Modules 3/4.
 * See SpeciesManagementTest/ReptileManagementTest for the untouched, still
 * fully passing, flat CRUD coverage.
 */
class SpeciesHierarchyTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_cannot_access_species_browse(): void
    {
        $response = $this->get(route('admin.species.browse'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_species_browse_page_lists_categories(): void
    {
        SpeciesCategory::factory()->create(['name' => 'Snake']);
        SpeciesCategory::factory()->create(['name' => 'Iguana']);
        SpeciesCategory::factory()->create(['name' => 'Bearded Dragon']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.browse'));

        $response->assertOk();
        $response->assertViewIs('admin.species.browse');
        $response->assertSee('Snake');
        $response->assertSee('Iguana');
        $response->assertSee('Bearded Dragon');
    }

    public function test_snake_category_displays_only_its_own_species_types(): void
    {
        $snake = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $iguana = SpeciesCategory::factory()->create(['name' => 'Iguana']);

        Species::factory()->create(['name' => 'Corn Snake', 'category_id' => $snake->id]);
        Species::factory()->create(['name' => 'Python Snake', 'category_id' => $snake->id]);
        Species::factory()->create(['name' => 'King Snake', 'category_id' => $snake->id]);
        Species::factory()->create(['name' => 'Green Iguana', 'category_id' => $iguana->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.category', $snake));

        $response->assertOk();
        $response->assertSee('Corn Snake');
        $response->assertSee('Python Snake');
        $response->assertSee('King Snake');
        $response->assertDontSee('Green Iguana');
    }

    public function test_iguana_category_displays_only_its_own_species_types(): void
    {
        $iguana = SpeciesCategory::factory()->create(['name' => 'Iguana']);
        $snake = SpeciesCategory::factory()->create(['name' => 'Snake']);

        Species::factory()->create(['name' => 'Red Iguana', 'category_id' => $iguana->id]);
        Species::factory()->create(['name' => 'Blue Iguana', 'category_id' => $iguana->id]);
        Species::factory()->create(['name' => 'Green Iguana', 'category_id' => $iguana->id]);
        Species::factory()->create(['name' => 'Corn Snake', 'category_id' => $snake->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.category', $iguana));

        $response->assertOk();
        $response->assertSee('Red Iguana');
        $response->assertSee('Blue Iguana');
        $response->assertSee('Green Iguana');
        $response->assertDontSee('Corn Snake');
    }

    public function test_bearded_dragon_category_displays_only_its_own_species_types(): void
    {
        $dragon = SpeciesCategory::factory()->create(['name' => 'Bearded Dragon']);
        $snake = SpeciesCategory::factory()->create(['name' => 'Snake']);

        Species::factory()->create(['name' => 'White Dragon', 'category_id' => $dragon->id]);
        Species::factory()->create(['name' => 'Creamino Dragon', 'category_id' => $dragon->id]);
        Species::factory()->create(['name' => 'Corn Snake', 'category_id' => $snake->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.category', $dragon));

        $response->assertOk();
        $response->assertSee('White Dragon');
        $response->assertSee('Creamino Dragon');
        $response->assertDontSee('Corn Snake');
    }

    public function test_python_snake_type_page_displays_only_its_own_varieties(): void
    {
        $pythonSnake = Species::factory()->create(['name' => 'Python Snake']);
        $cornSnake = Species::factory()->create(['name' => 'Corn Snake']);

        SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Royal Python']);
        SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Albino Python']);
        SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Banana Python']);
        SpeciesVariety::factory()->create(['species_id' => $cornSnake->id, 'name' => 'Albino Corn Snake']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.type', $pythonSnake));

        $response->assertOk();
        $response->assertSee('Royal Python');
        $response->assertSee('Albino Python');
        $response->assertSee('Banana Python');
        $response->assertDontSee('Albino Corn Snake');
    }

    public function test_corn_snake_type_page_displays_only_its_own_varieties(): void
    {
        $cornSnake = Species::factory()->create(['name' => 'Corn Snake']);
        $pythonSnake = Species::factory()->create(['name' => 'Python Snake']);

        SpeciesVariety::factory()->create(['species_id' => $cornSnake->id, 'name' => 'Albino Corn Snake']);
        SpeciesVariety::factory()->create(['species_id' => $cornSnake->id, 'name' => 'Tessera Corn Snake']);
        SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Royal Python']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.type', $cornSnake));

        $response->assertOk();
        $response->assertSee('Albino Corn Snake');
        $response->assertSee('Tessera Corn Snake');
        $response->assertDontSee('Royal Python');
    }

    public function test_variety_page_datatable_lists_only_reptiles_of_that_variety(): void
    {
        $species = Species::factory()->create(['name' => 'Python Snake']);
        $royalPython = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);
        $bananaPython = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Banana Python']);

        Reptile::factory()->create(['name' => 'Royal Python 001', 'species_id' => $species->id, 'species_variety_id' => $royalPython->id]);
        Reptile::factory()->create(['name' => 'Royal Python 002', 'species_id' => $species->id, 'species_variety_id' => $royalPython->id]);
        Reptile::factory()->create(['name' => 'Banana Python 001', 'species_id' => $species->id, 'species_variety_id' => $bananaPython->id]);

        $user = $this->actingAs(User::factory()->create());

        $page = $user->get(route('admin.species.variety', [$species, $royalPython]));
        $page->assertOk();
        $page->assertViewIs('admin.species.variety');

        $ajax = $user->get(route('admin.species.variety', [$species, $royalPython]), ['X-Requested-With' => 'XMLHttpRequest']);
        $ajax->assertOk();
        $names = collect($ajax->json('data'))->pluck('name');

        $this->assertTrue($names->contains('Royal Python 001'));
        $this->assertTrue($names->contains('Royal Python 002'));
        $this->assertFalse($names->contains('Banana Python 001'));
    }

    public function test_searching_the_variety_datatable_finds_the_matching_individual(): void
    {
        $species = Species::factory()->create(['name' => 'Python Snake']);
        $variety = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);

        Reptile::factory()->create(['name' => 'Royal Python 001', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);
        Reptile::factory()->create(['name' => 'Royal Python 002', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);
        Reptile::factory()->create(['name' => 'Royal Python 003', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);

        $response = $this->actingAs(User::factory()->create())->get(
            route('admin.species.variety', [$species, $variety], false).'?'.http_build_query(['search' => ['value' => 'Royal Python 003']]),
            ['X-Requested-With' => 'XMLHttpRequest']
        );

        $response->assertOk();
        $names = collect($response->json('data'))->pluck('name');

        $this->assertCount(1, $names);
        $this->assertTrue($names->contains('Royal Python 003'));
    }

    public function test_a_variety_that_does_not_belong_to_the_given_species_type_returns_404(): void
    {
        $pythonSnake = Species::factory()->create(['name' => 'Python Snake']);
        $cornSnake = Species::factory()->create(['name' => 'Corn Snake']);
        $albinoCornSnake = SpeciesVariety::factory()->create(['species_id' => $cornSnake->id, 'name' => 'Albino Corn Snake']);

        // Snake > Python Snake > Albino Corn Snake is not a real path — Albino
        // Corn Snake actually belongs to Corn Snake, not Python Snake.
        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.species.variety', [$pythonSnake, $albinoCornSnake]));

        $response->assertNotFound();
    }

    public function test_reptile_profile_displays_its_category_species_type_and_variety(): void
    {
        $category = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $species = Species::factory()->create(['name' => 'Python Snake', 'category_id' => $category->id]);
        $variety = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);
        $reptile = Reptile::factory()->create([
            'name' => 'Royal Python 001',
            'species_id' => $species->id,
            'species_variety_id' => $variety->id,
        ]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptile));

        $response->assertOk();
        $response->assertSee('Snake');
        $response->assertSee('Python Snake');
        $response->assertSee('Royal Python');
        // Breadcrumb reflects the full hierarchy trail.
        $response->assertSee(route('admin.species.browse'), false);
        $response->assertSee(route('admin.species.category', $category), false);
        $response->assertSee(route('admin.species.type', $species), false);
        $response->assertSee(route('admin.species.variety', [$species, $variety]), false);
    }

    public function test_reptile_without_a_category_or_variety_still_shows_its_profile(): void
    {
        // Pre-existing reptile: species has no category, reptile has no variety.
        $reptile = Reptile::factory()->create(['species_variety_id' => null]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptile));

        $response->assertOk();
        $response->assertSee($reptile->name);
        // Falls back to the original breadcrumb instead of dead-ending.
        $response->assertSee(route('admin.reptiles.index'), false);
    }

    public function test_feeding_and_shedding_records_stay_scoped_to_the_correct_reptile_through_the_hierarchy(): void
    {
        $species = Species::factory()->create(['name' => 'Python Snake']);
        $variety = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);

        $reptileA = Reptile::factory()->create(['name' => 'Royal Python 001', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);
        $reptileB = Reptile::factory()->create(['name' => 'Royal Python 002', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);

        SheddingRecord::factory()->create(['reptile_id' => $reptileA->id, 'notes' => 'Shed belonging to Reptile A only']);
        SheddingRecord::factory()->create(['reptile_id' => $reptileB->id, 'notes' => 'Shed belonging to Reptile B only']);

        $user = $this->actingAs(User::factory()->create());

        $pageA = $user->get(route('admin.reptiles.show', $reptileA));
        $pageA->assertSee('Shed belonging to Reptile A only');
        $pageA->assertDontSee('Shed belonging to Reptile B only');

        $pageB = $user->get(route('admin.reptiles.show', $reptileB));
        $pageB->assertSee('Shed belonging to Reptile B only');
        $pageB->assertDontSee('Shed belonging to Reptile A only');
    }

    public function test_species_type_page_reports_reptiles_not_yet_assigned_to_a_variety(): void
    {
        $species = Species::factory()->create(['name' => 'Ball Python']);
        Reptile::factory()->create(['species_id' => $species->id, 'species_variety_id' => null]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.species.type', $species));

        $response->assertOk();
        $response->assertViewHas('unassignedReptileCount', 1);
    }
}
