<?php

namespace Tests\Feature\Admin;

use App\Models\MedicalRecord;
use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\SpeciesVariety;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

class MedicalRecordManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Storage::fake('private');
    }

    /**
     * Build a valid store/update payload. Every scenario in this suite either
     * uses these defaults directly or overrides exactly the field it's testing.
     */
    protected function validPayload(array $overrides = []): array
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);

        return array_merge([
            'reptile_id' => $reptile->id,
            'treatment_date' => now()->toDateString(),
            'symptoms_or_condition' => 'Lethargy and reduced appetite.',
            'medicine_name' => 'Baytril',
            'dosage' => '5mg/kg once daily',
            'treatment_details' => 'Administered orally for 7 days.',
            'veterinarian_name' => 'Dr. Smith',
            'veterinarian_contact' => '555-0100',
            'notes' => 'Reptile responded well.',
        ], $overrides);
    }

    // 1-3: access -------------------------------------------------------------

    public function test_guest_cannot_access_medical_records(): void
    {
        $response = $this->get(route('admin.medical-records.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_view_medical_records(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())->get(route('admin.medical-records.index'));

        $response->assertOk();
        $response->assertViewIs('admin.medical-records.index');
    }

    public function test_staff_can_view_medical_records(): void
    {
        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))->get(route('admin.medical-records.index'));

        $response->assertOk();
    }

    // 4-5: create ---------------------------------------------------------------

    public function test_admin_can_create_medical_records(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), $this->validPayload());

        $response->assertRedirect();
        $response->assertSessionHas('success', 'Medical record created successfully.');
        $this->assertDatabaseCount('medical_records', 1);
    }

    public function test_staff_can_create_medical_records(): void
    {
        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->post(route('admin.medical-records.store'), $this->validPayload());

        $response->assertRedirect();
        $this->assertDatabaseCount('medical_records', 1);
    }

    // 6-7: edit -----------------------------------------------------------------

    public function test_admin_can_edit_medical_records(): void
    {
        $record = MedicalRecord::factory()->create();

        $response = $this->actingAs(User::factory()->admin()->create())
            ->put(route('admin.medical-records.update', $record), $this->validPayload([
                'reptile_id' => $record->reptile_id,
                'symptoms_or_condition' => 'Updated condition.',
            ]));

        $response->assertRedirect(route('admin.medical-records.show', $record));
        $this->assertDatabaseHas('medical_records', ['id' => $record->id, 'symptoms_or_condition' => 'Updated condition.']);
    }

    public function test_staff_can_edit_medical_records(): void
    {
        $record = MedicalRecord::factory()->create();

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->put(route('admin.medical-records.update', $record), $this->validPayload([
                'reptile_id' => $record->reptile_id,
                'symptoms_or_condition' => 'Updated by staff.',
            ]));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('medical_records', ['id' => $record->id, 'symptoms_or_condition' => 'Updated by staff.']);
    }

    // 8-9: delete authorization ---------------------------------------------------

    public function test_admin_can_delete_medical_records(): void
    {
        $record = MedicalRecord::factory()->create();

        $response = $this->actingAs(User::factory()->admin()->create())
            ->delete(route('admin.medical-records.destroy', $record));

        $response->assertRedirect(route('admin.medical-records.index'));
        $response->assertSessionHas('success', 'Medical record deleted successfully.');
        $this->assertDatabaseMissing('medical_records', ['id' => $record->id]);
    }

    public function test_staff_cannot_delete_medical_records(): void
    {
        $record = MedicalRecord::factory()->create();

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->delete(route('admin.medical-records.destroy', $record));

        $response->assertForbidden();
        $this->assertDatabaseHas('medical_records', ['id' => $record->id]);
    }

    // 10-13: validation -----------------------------------------------------------

    public function test_required_fields_are_validated(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), $this->validPayload([
                'reptile_id' => '',
                'treatment_date' => '',
                'symptoms_or_condition' => '',
            ]));

        $response->assertSessionHasErrors(['reptile_id', 'treatment_date', 'symptoms_or_condition']);
        $this->assertDatabaseCount('medical_records', 0);
    }

    public function test_invalid_prescription_file_type_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
                'prescription' => UploadedFile::fake()->create('malware.exe', 10),
            ]));

        $response->assertSessionHasErrors('prescription');
        $this->assertDatabaseCount('medical_records', 0);
    }

    public function test_svg_prescription_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
                'prescription' => UploadedFile::fake()->create('image.svg', 10, 'image/svg+xml'),
            ]));

        $response->assertSessionHasErrors('prescription');
    }

    public function test_valid_pdf_prescription_can_be_uploaded(): void
    {
        $file = UploadedFile::fake()->create('prescription.pdf', 100, 'application/pdf');

        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
                'prescription' => $file,
            ]));

        $response->assertSessionDoesntHaveErrors();
        $record = MedicalRecord::first();
        $this->assertNotNull($record->prescription_path);
        Storage::disk('private')->assertExists($record->prescription_path);
    }

    public function test_valid_image_prescription_can_be_uploaded(): void
    {
        $file = UploadedFile::fake()->image('prescription.jpg');

        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
                'prescription' => $file,
            ]));

        $response->assertSessionDoesntHaveErrors();
        $record = MedicalRecord::first();
        Storage::disk('private')->assertExists($record->prescription_path);
    }

    /**
     * @dataProvider imagePrescriptionExtensions
     */
    public function test_every_allowed_image_extension_is_accepted_as_a_prescription(string $extension): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
                'prescription' => UploadedFile::fake()->image("prescription.{$extension}"),
            ]));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseCount('medical_records', 1);
    }

    public static function imagePrescriptionExtensions(): array
    {
        return [
            'jpg' => ['jpg'],
            'jpeg' => ['jpeg'],
            'png' => ['png'],
            'webp' => ['webp'],
        ];
    }

    // 14-15: prescription privacy ---------------------------------------------------

    public function test_prescription_is_stored_privately_with_a_generated_filename(): void
    {
        $file = UploadedFile::fake()->create('my-secret-prescription.pdf', 100, 'application/pdf');

        $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
                'prescription' => $file,
            ]));

        $record = MedicalRecord::first();

        $this->assertStringNotContainsString('my-secret-prescription', $record->prescription_path);
        $this->assertStringStartsWith('medical-prescriptions/', $record->prescription_path);
    }

    public function test_prescription_cannot_be_accessed_without_authentication(): void
    {
        $record = MedicalRecord::factory()->create(['prescription_path' => 'medical-prescriptions/secret.pdf']);
        Storage::disk('private')->put($record->prescription_path, 'fake-pdf-content');

        $response = $this->get(route('admin.medical-records.prescription', $record));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_user_can_view_the_prescription(): void
    {
        $record = MedicalRecord::factory()->create();
        $record->update(['prescription_path' => 'medical-prescriptions/'.Str::uuid().'.pdf']);
        Storage::disk('private')->put($record->prescription_path, 'fake-pdf-content');

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.medical-records.prescription', $record));

        $response->assertOk();
    }

    public function test_missing_prescription_returns_404(): void
    {
        $record = MedicalRecord::factory()->create(['prescription_path' => null]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.medical-records.prescription', $record));

        $response->assertNotFound();
    }

    // 16-17: association / IDOR -------------------------------------------------

    public function test_medical_record_is_correctly_associated_with_the_selected_reptile(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);

        $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), $this->validPayload(['reptile_id' => $reptile->id]));

        $this->assertDatabaseHas('medical_records', ['reptile_id' => $reptile->id]);
    }

    public function test_invalid_reptile_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->admin()->create())
            ->post(route('admin.medical-records.store'), $this->validPayload(['reptile_id' => 999999]));

        $response->assertSessionHasErrors('reptile_id');
    }

    public function test_accessing_another_reptiles_medical_record_by_id_shows_only_that_records_own_data(): void
    {
        $reptileA = Reptile::factory()->create(['name' => 'Reptile A']);
        $reptileB = Reptile::factory()->create(['name' => 'Reptile B']);
        $recordA = MedicalRecord::factory()->create(['reptile_id' => $reptileA->id, 'symptoms_or_condition' => 'A condition']);
        $recordB = MedicalRecord::factory()->create(['reptile_id' => $reptileB->id, 'symptoms_or_condition' => 'B condition']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.medical-records.show', $recordB));

        $response->assertOk();
        $response->assertViewHas('medicalRecord', fn ($record) => $record->id === $recordB->id && $record->reptile_id === $reptileB->id);
        $response->assertDontSee('A condition');
    }

    public function test_nonexistent_medical_record_returns_404(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.medical-records.show', 999999));

        $response->assertNotFound();
    }

    // 18: reptile profile scoping ------------------------------------------------

    public function test_reptile_profile_only_shows_that_reptiles_medical_records(): void
    {
        $reptileA = Reptile::factory()->create();
        $reptileB = Reptile::factory()->create();
        MedicalRecord::factory()->create(['reptile_id' => $reptileA->id, 'symptoms_or_condition' => 'Belongs to A']);
        MedicalRecord::factory()->create(['reptile_id' => $reptileB->id, 'symptoms_or_condition' => 'Belongs to B']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptileB));

        $response->assertOk();
        $response->assertViewHas('medicalRecords', fn ($records) => $records->count() === 1
            && $records->first()->reptile_id === $reptileB->id);
        $response->assertDontSee('Belongs to A');
        $response->assertSee('Belongs to B');
    }

    // 19: prescription replacement -----------------------------------------------

    public function test_replacing_a_prescription_removes_the_old_file_after_successful_replacement(): void
    {
        $original = UploadedFile::fake()->create('original.pdf', 100, 'application/pdf');
        $admin = User::factory()->admin()->create();

        $this->actingAs($admin)->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
            'prescription' => $original,
        ]));

        $record = MedicalRecord::first();
        $oldPath = $record->prescription_path;
        Storage::disk('private')->assertExists($oldPath);

        $replacement = UploadedFile::fake()->create('replacement.pdf', 100, 'application/pdf');

        $this->actingAs($admin)->put(route('admin.medical-records.update', $record), array_merge(
            $this->validPayload(['reptile_id' => $record->reptile_id]),
            ['prescription' => $replacement]
        ));

        $record->refresh();
        $this->assertNotSame($oldPath, $record->prescription_path);
        Storage::disk('private')->assertMissing($oldPath);
        Storage::disk('private')->assertExists($record->prescription_path);
    }

    public function test_editing_without_a_new_prescription_keeps_the_existing_one(): void
    {
        $file = UploadedFile::fake()->create('original.pdf', 100, 'application/pdf');
        $admin = User::factory()->admin()->create();

        $this->actingAs($admin)->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
            'prescription' => $file,
        ]));

        $record = MedicalRecord::first();
        $originalPath = $record->prescription_path;

        $this->actingAs($admin)->put(
            route('admin.medical-records.update', $record),
            $this->validPayload(['reptile_id' => $record->reptile_id, 'symptoms_or_condition' => 'Follow-up visit.'])
        );

        $record->refresh();
        $this->assertSame($originalPath, $record->prescription_path);
        Storage::disk('private')->assertExists($originalPath);
    }

    // 20: deletion cleanup ---------------------------------------------------------

    public function test_deleting_a_medical_record_removes_its_prescription_file(): void
    {
        $file = UploadedFile::fake()->create('to-delete.pdf', 100, 'application/pdf');
        $admin = User::factory()->admin()->create();

        $this->actingAs($admin)->post(route('admin.medical-records.store'), array_merge($this->validPayload(), [
            'prescription' => $file,
        ]));

        $record = MedicalRecord::first();
        $path = $record->prescription_path;
        Storage::disk('private')->assertExists($path);

        $this->actingAs($admin)->delete(route('admin.medical-records.destroy', $record));

        Storage::disk('private')->assertMissing($path);
        $this->assertDatabaseMissing('medical_records', ['id' => $record->id]);
    }

    /**
     * The full ticket example end to end: Snake > Python Snake > Royal
     * Python > Royal Python 001 vs 002 — reached through the Species
     * hierarchy, not just two bare factory reptiles, must still keep
     * medical history strictly per-individual.
     */
    public function test_medical_history_is_isolated_between_individuals_reached_through_the_species_hierarchy(): void
    {
        $snake = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $pythonSnake = Species::factory()->create(['name' => 'Python Snake', 'category_id' => $snake->id]);
        $royalPython = SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Royal Python']);

        $rp001 = Reptile::factory()->create([
            'name' => 'Royal Python 001', 'species_id' => $pythonSnake->id, 'species_variety_id' => $royalPython->id,
        ]);
        $rp002 = Reptile::factory()->create([
            'name' => 'Royal Python 002', 'species_id' => $pythonSnake->id, 'species_variety_id' => $royalPython->id,
        ]);

        MedicalRecord::factory()->create(['reptile_id' => $rp001->id, 'symptoms_or_condition' => 'RP001 only condition']);
        MedicalRecord::factory()->create(['reptile_id' => $rp002->id, 'symptoms_or_condition' => 'RP002 only condition']);

        $user = $this->actingAs(User::factory()->create());

        $profile001 = $user->get(route('admin.reptiles.show', $rp001));
        $profile001->assertOk();
        $profile001->assertViewHas('medicalRecords', fn ($records) => $records->count() === 1 && $records->first()->reptile_id === $rp001->id);
        $profile001->assertSee('RP001 only condition');
        $profile001->assertDontSee('RP002 only condition');

        $profile002 = $user->get(route('admin.reptiles.show', $rp002));
        $profile002->assertOk();
        $profile002->assertViewHas('medicalRecords', fn ($records) => $records->count() === 1 && $records->first()->reptile_id === $rp002->id);
        $profile002->assertSee('RP002 only condition');
        $profile002->assertDontSee('RP001 only condition');
    }

    // 21-24: DataTable ---------------------------------------------------------------

    protected function ajaxDataTableRequest(string $url, User $user): TestResponse
    {
        return $this->actingAs($user)
            ->withHeaders(['X-Requested-With' => 'XMLHttpRequest'])
            ->getJson($url);
    }

    /**
     * The `columns[i][...]` request parameters a real DataTables client
     * always sends alongside `order`/`search`, describing each of the
     * DataTable's 9 columns (see MedicalRecordDataTable::getColumns()) so
     * the server can resolve an `order` column index to a column name.
     */
    protected function dataTableColumnsParam(): array
    {
        $names = [
            'reptile_name', 'treatment_date', 'symptoms_or_condition', 'medicine_name',
            'dosage', 'veterinarian_name', 'prescription', 'created_by_name', 'actions',
        ];

        return collect($names)->map(fn ($name) => [
            'data' => $name,
            'name' => '',
            'searchable' => 'true',
            'orderable' => ! in_array($name, ['prescription', 'actions']) ? 'true' : 'false',
            'search' => ['value' => '', 'regex' => 'false'],
        ])->all();
    }

    public function test_datatable_returns_correct_data(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);
        MedicalRecord::factory()->create(['reptile_id' => $reptile->id, 'symptoms_or_condition' => 'Test condition']);

        $response = $this->ajaxDataTableRequest(
            route('admin.medical-records.index', [
                'draw' => 1, 'start' => 0, 'length' => 10, 'columns' => $this->dataTableColumnsParam(),
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 1);
        $response->assertJsonPath('recordsFiltered', 1);
        $response->assertSee('Test condition', false);
    }

    public function test_datatable_search_works(): void
    {
        $rocky = Reptile::factory()->create(['name' => 'UniqueRockyName']);
        $luna = Reptile::factory()->create(['name' => 'UniqueLunaName']);
        MedicalRecord::factory()->create(['reptile_id' => $rocky->id]);
        MedicalRecord::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->ajaxDataTableRequest(
            route('admin.medical-records.index', [
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(),
                'search' => ['value' => 'UniqueRockyName', 'regex' => 'false'],
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsFiltered', 1);
    }

    public function test_datatable_pagination_works(): void
    {
        MedicalRecord::factory()->count(20)->create();

        $response = $this->ajaxDataTableRequest(
            route('admin.medical-records.index', [
                'draw' => 1, 'start' => 0, 'length' => 10, 'columns' => $this->dataTableColumnsParam(),
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 20);
        $this->assertCount(10, $response->json('data'));
    }

    public function test_datatable_sorting_works(): void
    {
        $older = MedicalRecord::factory()->create(['treatment_date' => now()->subDays(10)]);
        $newer = MedicalRecord::factory()->create(['treatment_date' => now()->subDay()]);

        // Column index 1 = treatment_date, dir desc (matches the default order).
        $response = $this->ajaxDataTableRequest(
            route('admin.medical-records.index', [
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(),
                'order' => [['column' => 1, 'dir' => 'desc']],
            ]),
            User::factory()->create()
        );

        $response->assertOk();
        $data = $response->json('data');
        $this->assertSame((string) $newer->id, (string) $data[0]['DT_RowId']);
    }

    public function test_datatable_query_avoids_n_plus_one_queries(): void
    {
        MedicalRecord::factory()->count(10)->create();

        DB::enableQueryLog();

        $this->ajaxDataTableRequest(
            route('admin.medical-records.index', [
                'draw' => 1, 'start' => 0, 'length' => 10, 'columns' => $this->dataTableColumnsParam(),
            ]),
            User::factory()->create()
        )->assertOk();

        $queryCount = count(DB::getQueryLog());
        DB::disableQueryLog();

        // A handful of fixed queries (count, filtered count, page of rows,
        // eager-loaded reptiles, eager-loaded creators, session/auth) rather
        // than one additional query per row.
        $this->assertLessThan(15, $queryCount);
    }
}
