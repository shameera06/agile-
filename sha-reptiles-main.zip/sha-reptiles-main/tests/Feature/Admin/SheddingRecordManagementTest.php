<?php

namespace Tests\Feature\Admin;

use App\Models\Reptile;
use App\Models\SheddingRecord;
use App\Models\Species;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SheddingRecordManagementTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Build a valid store/update payload. Every scenario in this suite either
     * uses these defaults directly or overrides exactly the field it's testing.
     */
    protected function validPayload(array $overrides = []): array
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);

        return array_merge([
            'reptile_id' => $reptile->id,
            'shedding_date' => now()->toDateString(),
            'status' => 'complete',
            'notes' => 'Normal shedding behavior.',
            'observations' => null,
        ], $overrides);
    }

    // 1-3: access -------------------------------------------------------------

    public function test_guest_cannot_access_shedding_records(): void
    {
        $response = $this->get(route('admin.shedding-records.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_view_shedding_records(): void
    {
        // No Staff/Admin distinction exists in this app's auth implementation —
        // this exercises the same route any authenticated user would, standing
        // in for "Admin".
        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.index'));

        $response->assertOk();
        $response->assertViewIs('admin.shedding-records.index');
    }

    public function test_authenticated_staff_can_view_shedding_records(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.index'));

        $response->assertOk();
    }

    // 4-5: create ---------------------------------------------------------------

    public function test_admin_can_create_a_shedding_record(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload());

        $response->assertRedirect(route('admin.shedding-records.index'));
        $response->assertSessionHas('success', 'Shedding record created successfully.');
        $this->assertDatabaseCount('shedding_records', 1);
    }

    public function test_staff_can_create_a_shedding_record(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload());

        $response->assertRedirect(route('admin.shedding-records.index'));
        $this->assertDatabaseCount('shedding_records', 1);
    }

    // 6-7: reptile validation ---------------------------------------------------

    public function test_reptile_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['reptile_id' => '']));

        $response->assertSessionHasErrors('reptile_id');
    }

    public function test_invalid_reptile_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['reptile_id' => 999999]));

        $response->assertSessionHasErrors('reptile_id');
    }

    public function test_inactive_reptile_cannot_receive_a_new_shedding_record(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'inactive']);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['reptile_id' => $reptile->id]));

        $response->assertSessionHasErrors('reptile_id');
        $this->assertDatabaseCount('shedding_records', 0);
    }

    // 8-9: shedding date ---------------------------------------------------------

    public function test_shedding_date_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['shedding_date' => '']));

        $response->assertSessionHasErrors('shedding_date');
    }

    public function test_historical_shedding_dates_are_allowed(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['shedding_date' => now()->subMonths(3)->toDateString()]));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseCount('shedding_records', 1);
    }

    // 10-11: status ---------------------------------------------------------------

    public function test_status_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['status' => '']));

        $response->assertSessionHasErrors('status');
    }

    public function test_invalid_status_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['status' => 'excellent']));

        $response->assertSessionHasErrors('status');
    }

    public function test_every_valid_status_can_be_saved(): void
    {
        foreach (array_keys(SheddingRecord::STATUSES) as $status) {
            $response = $this->actingAs(User::factory()->create())
                ->post(route('admin.shedding-records.store'), $this->validPayload(['status' => $status]));

            $response->assertSessionDoesntHaveErrors();
            $this->assertDatabaseHas('shedding_records', ['status' => $status]);
        }
    }

    // 12-13: notes / observations -------------------------------------------------

    public function test_notes_are_optional(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['notes' => null]));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('shedding_records', ['notes' => null]);
    }

    public function test_observations_are_optional(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload(['observations' => null]));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('shedding_records', ['observations' => null]);
    }

    public function test_observations_are_saved_when_provided(): void
    {
        $this->actingAs(User::factory()->create())
            ->post(route('admin.shedding-records.store'), $this->validPayload([
                'observations' => 'Small amount of retained skin observed around the tail.',
            ]));

        $this->assertDatabaseHas('shedding_records', [
            'observations' => 'Small amount of retained skin observed around the tail.',
        ]);
    }

    // 14-15: created_by -------------------------------------------------------------

    public function test_created_by_is_assigned_from_the_authenticated_user(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('admin.shedding-records.store'), $this->validPayload());

        $this->assertDatabaseHas('shedding_records', ['created_by' => $user->id]);
    }

    public function test_staff_cannot_spoof_created_by(): void
    {
        $user = User::factory()->create();
        $otherUser = User::factory()->create();

        $this->actingAs($user)->post(route('admin.shedding-records.store'), $this->validPayload([
            'created_by' => $otherUser->id,
        ]));

        $this->assertDatabaseHas('shedding_records', ['created_by' => $user->id]);
        $this->assertDatabaseMissing('shedding_records', ['created_by' => $otherUser->id]);
    }

    // 16-17: editing ----------------------------------------------------------------

    public function test_admin_can_edit_a_shedding_record(): void
    {
        $record = SheddingRecord::factory()->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.edit', $record));

        $response->assertOk();
        $response->assertViewIs('admin.shedding-records.edit');
    }

    public function test_staff_can_edit_a_shedding_record(): void
    {
        $record = SheddingRecord::factory()->create(['status' => 'complete']);

        $response = $this->actingAs(User::factory()->create())->put(
            route('admin.shedding-records.update', $record),
            [
                'reptile_id' => $record->reptile_id,
                'shedding_date' => $record->shedding_date->toDateString(),
                'status' => 'partial',
                'notes' => 'Updated notes.',
                'observations' => null,
            ]
        );

        $response->assertRedirect(route('admin.shedding-records.index'));
        $response->assertSessionHas('success', 'Shedding record updated successfully.');
        $this->assertDatabaseHas('shedding_records', ['id' => $record->id, 'status' => 'partial', 'notes' => 'Updated notes.']);
    }

    public function test_editing_never_changes_created_by(): void
    {
        $creator = User::factory()->create();
        $record = SheddingRecord::factory()->create(['created_by' => $creator->id]);
        $editor = User::factory()->create();

        $this->actingAs($editor)->put(route('admin.shedding-records.update', $record), [
            'reptile_id' => $record->reptile_id,
            'shedding_date' => $record->shedding_date->toDateString(),
            'status' => 'partial',
            'notes' => null,
            'observations' => null,
        ]);

        $this->assertDatabaseHas('shedding_records', ['id' => $record->id, 'created_by' => $creator->id]);
    }

    // 18-19: reptile profile integration ---------------------------------------------

    public function test_reptile_profile_displays_shedding_history(): void
    {
        $reptile = Reptile::factory()->create();
        SheddingRecord::factory()->create(['reptile_id' => $reptile->id, 'notes' => 'Normal shed.']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptile));

        $response->assertOk();
        $response->assertSee('Shedding History');
        $response->assertSee('Normal shed.');
    }

    public function test_reptile_profile_displays_only_that_reptiles_shedding_records(): void
    {
        $reptileA = Reptile::factory()->create();
        $reptileB = Reptile::factory()->create();
        SheddingRecord::factory()->create(['reptile_id' => $reptileA->id]);
        SheddingRecord::factory()->create(['reptile_id' => $reptileB->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptileA));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->count() === 1
            && $records->first()->reptile_id === $reptileA->id);
    }

    // Data isolation test (mandatory) -------------------------------------------------

    public function test_shedding_records_are_never_mixed_between_reptiles(): void
    {
        $reptileA = Reptile::factory()->create(['name' => 'Reptile A']);
        $reptileB = Reptile::factory()->create(['name' => 'Reptile B']);

        SheddingRecord::factory()->create(['reptile_id' => $reptileA->id, 'notes' => 'Belongs to A']);

        $responseB = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptileB));
        $responseB->assertOk();
        $responseB->assertDontSee('Belongs to A');
        $responseB->assertViewHas('sheddingRecords', fn ($records) => $records->isEmpty());

        SheddingRecord::factory()->create(['reptile_id' => $reptileB->id, 'notes' => 'Belongs to B']);

        $responseB = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptileB));
        $responseB->assertOk();
        $responseB->assertViewHas('sheddingRecords', fn ($records) => $records->count() === 1
            && $records->first()->notes === 'Belongs to B');
        $responseB->assertDontSee('Belongs to A');
    }

    // 20-23: search & filters ---------------------------------------------------------

    public function test_search_by_reptile_name_works(): void
    {
        $rocky = Reptile::factory()->create(['name' => 'Rocky']);
        $luna = Reptile::factory()->create(['name' => 'Luna']);
        SheddingRecord::factory()->create(['reptile_id' => $rocky->id]);
        SheddingRecord::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.shedding-records.index', ['search' => 'rocky']));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_search_by_reptile_code_works(): void
    {
        $rocky = Reptile::factory()->create(['reptile_code' => 'REP-000001']);
        $luna = Reptile::factory()->create(['reptile_code' => 'REP-000002']);
        SheddingRecord::factory()->create(['reptile_id' => $rocky->id]);
        SheddingRecord::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.shedding-records.index', ['search' => 'REP-000001']));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_search_by_species_works(): void
    {
        $python = Species::factory()->create(['name' => 'UniqueBallPython']);
        $gecko = Species::factory()->create(['name' => 'UniqueLeopardGecko']);
        $reptileA = Reptile::factory()->create(['species_id' => $python->id]);
        $reptileB = Reptile::factory()->create(['species_id' => $gecko->id]);
        SheddingRecord::factory()->create(['reptile_id' => $reptileA->id]);
        SheddingRecord::factory()->create(['reptile_id' => $reptileB->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.shedding-records.index', ['search' => 'UniqueBallPython']));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_reptile_filter_works(): void
    {
        $rocky = Reptile::factory()->create();
        $luna = Reptile::factory()->create();
        SheddingRecord::factory()->create(['reptile_id' => $rocky->id]);
        SheddingRecord::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.shedding-records.index', ['reptile_id' => $rocky->id]));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_status_filter_works(): void
    {
        SheddingRecord::factory()->create(['status' => 'complete']);
        SheddingRecord::factory()->create(['status' => 'problematic']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.shedding-records.index', ['status' => 'problematic']));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_date_range_filter_works(): void
    {
        SheddingRecord::factory()->create(['shedding_date' => now()->subDays(2)]);
        SheddingRecord::factory()->create(['shedding_date' => now()->subDays(60)]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.index', [
            'from' => now()->subDays(10)->toDateString(),
            'to' => now()->toDateString(),
        ]));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_combined_filters_work(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);
        SheddingRecord::factory()->create([
            'reptile_id' => $reptile->id, 'status' => 'complete', 'shedding_date' => now()->subDays(2),
        ]);
        SheddingRecord::factory()->create([
            'reptile_id' => $reptile->id, 'status' => 'partial', 'shedding_date' => now()->subDays(2),
        ]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.index', [
            'search' => 'rocky',
            'status' => 'complete',
            'from' => now()->subDays(10)->toDateString(),
            'to' => now()->toDateString(),
        ]));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->total() === 1);
    }

    // 27-29: pagination & sorting -----------------------------------------------------

    public function test_pagination_works(): void
    {
        SheddingRecord::factory()->count(20)->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.index'));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->count() === 15 && $records->hasMorePages());
    }

    public function test_pagination_preserves_query_parameters(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);
        SheddingRecord::factory()->count(20)->create(['reptile_id' => $reptile->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.shedding-records.index', ['search' => 'rocky', 'page' => 2]));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->currentPage() === 2 && $records->total() === 20);
        $response->assertSee('search=rocky');
    }

    public function test_records_are_sorted_newest_first(): void
    {
        $older = SheddingRecord::factory()->create(['shedding_date' => now()->subDays(10)]);
        $newer = SheddingRecord::factory()->create(['shedding_date' => now()->subDay()]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.shedding-records.index'));

        $response->assertOk();
        $response->assertViewHas('sheddingRecords', function ($records) use ($older, $newer) {
            $ids = $records->pluck('id')->all();

            return array_search($newer->id, $ids) < array_search($older->id, $ids);
        });
    }

    // 30: historical integrity ---------------------------------------------------------

    public function test_historical_shedding_records_remain_after_reptile_status_changes(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $record = SheddingRecord::factory()->create(['reptile_id' => $reptile->id]);

        $reptile->update(['status' => 'deceased']);

        $this->assertDatabaseHas('shedding_records', ['id' => $record->id, 'reptile_id' => $reptile->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.show', $reptile));
        $response->assertOk();
        $response->assertViewHas('sheddingRecords', fn ($records) => $records->count() === 1);
    }
}
