<?php

namespace Tests\Feature\Admin;

use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\HealthAlert;
use App\Models\MedicalRecord;
use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\SpeciesVariety;
use App\Models\SheddingRecord;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

/**
 * Module 11 — Complete Reptile History. A read-only aggregation over
 * Modules 7-10's existing tables (feeding_records, shedding_records,
 * medical_records, health_alerts) — no new business logic, no new tables.
 */
class ReptileHistoryTest extends TestCase
{
    use RefreshDatabase;

    // 1-3: access -------------------------------------------------------------

    public function test_guest_cannot_access_complete_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->get(route('admin.reptiles.history', $reptile));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_access_complete_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->admin()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertOk();
        $response->assertViewIs('admin.reptiles.history');
    }

    public function test_staff_can_access_complete_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))->get(route('admin.reptiles.history', $reptile));

        $response->assertOk();
    }

    // 4-9: header / identity ---------------------------------------------------

    public function test_correct_reptile_information_is_displayed(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Royal Python 001', 'current_weight' => 450, 'weight_unit' => 'g']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertOk();
        $response->assertSee('Royal Python 001');
        $response->assertSee($reptile->reptile_code);
        $response->assertSee('450');
    }

    public function test_category_is_displayed_when_assigned(): void
    {
        $category = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $species = Species::factory()->create(['name' => 'Python Snake', 'category_id' => $category->id]);
        $reptile = Reptile::factory()->create(['species_id' => $species->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertOk();
        $response->assertSee('Snake');
    }

    public function test_species_type_is_displayed(): void
    {
        $species = Species::factory()->create(['name' => 'Python Snake']);
        $reptile = Reptile::factory()->create(['species_id' => $species->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertOk();
        $response->assertSee('Python Snake');
    }

    public function test_variety_is_displayed_when_assigned(): void
    {
        $species = Species::factory()->create(['name' => 'Python Snake']);
        $variety = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);
        $reptile = Reptile::factory()->create(['species_id' => $species->id, 'species_variety_id' => $variety->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertOk();
        $response->assertSee('Royal Python');
    }

    public function test_dob_hatch_date_is_displayed_or_not_recorded(): void
    {
        $withDob = Reptile::factory()->create(['date_of_birth' => '2023-05-01']);
        $withoutDob = Reptile::factory()->create(['date_of_birth' => null]);

        $user = $this->actingAs(User::factory()->create());

        $user->get(route('admin.reptiles.history', $withDob))->assertSee('May 01, 2023');
        $user->get(route('admin.reptiles.history', $withoutDob))->assertSee('Not recorded');
    }

    public function test_current_weight_is_displayed(): void
    {
        $reptile = Reptile::factory()->create(['current_weight' => 512.50, 'weight_unit' => 'g']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('512.50');
        $response->assertSee('g');
    }

    // 10-15: sections present -----------------------------------------------

    public function test_feeding_history_section_is_displayed(): void
    {
        $reptile = Reptile::factory()->create();
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('Weight &amp; Feeding History', false);
    }

    public function test_weight_history_is_displayed(): void
    {
        $reptile = Reptile::factory()->create(['current_weight' => 400]);
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('Current Weight');
    }

    public function test_shedding_history_section_is_displayed(): void
    {
        $reptile = Reptile::factory()->create();
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('Shedding History');
    }

    public function test_medical_history_section_is_displayed(): void
    {
        $reptile = Reptile::factory()->create();
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('Medical History');
    }

    public function test_health_alert_history_section_is_displayed(): void
    {
        $reptile = Reptile::factory()->create();
        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('Health Alerts');
    }

    public function test_reptile_notes_observations_are_displayed(): void
    {
        $withNotes = Reptile::factory()->create(['notes' => 'Very active and handles well.']);
        $withoutNotes = Reptile::factory()->create(['notes' => null]);

        $user = $this->actingAs(User::factory()->create());

        $user->get(route('admin.reptiles.history', $withNotes))->assertSee('Very active and handles well.');
        $user->get(route('admin.reptiles.history', $withoutNotes))->assertSee('No observations recorded.');
    }

    // 16-21: strict per-reptile isolation (mandatory) -------------------------

    /**
     * The mandatory isolation test: two reptiles, each with its own
     * feeding/shedding/medical/health-alert records, verified through the
     * real ajax DataTable endpoints (feeding/shedding/medical/health-alert)
     * as well as the page itself — never mixed.
     */
    public function test_two_reptiles_histories_are_completely_isolated_from_each_other(): void
    {
        $species = Species::factory()->create(['name' => 'Python Snake']);
        $variety = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);

        $rp001 = Reptile::factory()->create(['name' => 'Royal Python 001', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);
        $rp002 = Reptile::factory()->create(['name' => 'Royal Python 002', 'species_id' => $species->id, 'species_variety_id' => $variety->id]);

        $feeding001 = FeedingRecord::factory()->create(['reptile_id' => $rp001->id, 'notes' => 'RP001 feeding note']);
        $feeding002 = FeedingRecord::factory()->create(['reptile_id' => $rp002->id, 'notes' => 'RP002 feeding note']);

        $shed001 = SheddingRecord::factory()->create(['reptile_id' => $rp001->id, 'notes' => 'RP001 shed note']);
        $shed002 = SheddingRecord::factory()->create(['reptile_id' => $rp002->id, 'notes' => 'RP002 shed note']);

        $med001 = MedicalRecord::factory()->create(['reptile_id' => $rp001->id, 'symptoms_or_condition' => 'RP001 medical condition']);
        $med002 = MedicalRecord::factory()->create(['reptile_id' => $rp002->id, 'symptoms_or_condition' => 'RP002 medical condition']);

        $alert001 = HealthAlert::factory()->create(['reptile_id' => $rp001->id, 'title' => 'RP001 alert title']);
        $alert002 = HealthAlert::factory()->create(['reptile_id' => $rp002->id, 'title' => 'RP002 alert title']);

        $user = $this->actingAs(User::factory()->create());

        // Feeding
        $feed001Data = $user->getJson(route('admin.reptiles.history.feeding-data', $rp001))->json('data');
        $this->assertCount(1, $feed001Data);
        $this->assertSame((string) $feeding001->id, (string) $feed001Data[0]['DT_RowId']);

        $feed002Data = $user->getJson(route('admin.reptiles.history.feeding-data', $rp002))->json('data');
        $this->assertCount(1, $feed002Data);
        $this->assertSame((string) $feeding002->id, (string) $feed002Data[0]['DT_RowId']);

        // Shedding
        $shed001Data = $user->getJson(route('admin.reptiles.history.shedding-data', $rp001))->json('data');
        $this->assertCount(1, $shed001Data);
        $this->assertSame((string) $shed001->id, (string) $shed001Data[0]['DT_RowId']);

        // Medical
        $med001Data = $user->getJson(route('admin.reptiles.history.medical-data', $rp001))->json('data');
        $this->assertCount(1, $med001Data);
        $this->assertSame((string) $med001->id, (string) $med001Data[0]['DT_RowId']);

        // Health Alerts
        $alert001Data = $user->getJson(route('admin.reptiles.history.health-alerts-data', $rp001))->json('data');
        $this->assertCount(1, $alert001Data);
        $this->assertSame((string) $alert001->id, (string) $alert001Data[0]['DT_RowId']);

        // The page itself, for RP001, must never mention RP002's data.
        $page001 = $user->get(route('admin.reptiles.history', $rp001));
        $page001->assertSee('RP001 alert title');
        $page001->assertDontSee('RP002 alert title');

        $page002 = $user->get(route('admin.reptiles.history', $rp002));
        $page002->assertSee('RP002 alert title');
        $page002->assertDontSee('RP001 alert title');
    }

    public function test_mismatched_nested_hierarchy_species_pages_do_not_leak_into_history(): void
    {
        // Two distinct species types, each with its own variety and reptile —
        // confirms the hierarchy pages themselves stay correctly scoped
        // (already covered in SpeciesHierarchyTest) and that each reptile's
        // History route only ever resolves that reptile's own row.
        $cornSnake = Species::factory()->create(['name' => 'Corn Snake']);
        $albino = SpeciesVariety::factory()->create(['species_id' => $cornSnake->id, 'name' => 'Albino Corn Snake']);
        $cornSnakeReptile = Reptile::factory()->create(['name' => 'Albino Corn Snake 001', 'species_id' => $cornSnake->id, 'species_variety_id' => $albino->id]);

        $pythonSnake = Species::factory()->create(['name' => 'Python Snake']);
        $royalPython = SpeciesVariety::factory()->create(['species_id' => $pythonSnake->id, 'name' => 'Royal Python']);
        $pythonReptile = Reptile::factory()->create(['name' => 'Royal Python 001', 'species_id' => $pythonSnake->id, 'species_variety_id' => $royalPython->id]);

        HealthAlert::factory()->create(['reptile_id' => $cornSnakeReptile->id, 'title' => 'Corn snake alert']);
        HealthAlert::factory()->create(['reptile_id' => $pythonReptile->id, 'title' => 'Python snake alert']);

        $user = $this->actingAs(User::factory()->create());

        $cornPage = $user->get(route('admin.reptiles.history', $cornSnakeReptile));
        $cornPage->assertSee('Corn snake alert');
        $cornPage->assertDontSee('Python snake alert');

        $pythonPage = $user->get(route('admin.reptiles.history', $pythonReptile));
        $pythonPage->assertSee('Python snake alert');
        $pythonPage->assertDontSee('Corn snake alert');
    }

    // 22: hierarchy 404 --------------------------------------------------------

    public function test_nonexistent_reptile_returns_404(): void
    {
        $response = $this->actingAs(User::factory()->create())->get('/admin/reptiles/999999/history');

        $response->assertNotFound();
    }

    // 23-24, poor-gain highlight (mandatory scenario) --------------------------

    protected function postFeedingRecord(User $user, FeedingSchedule $schedule, float $weightBefore, float $weightAfter): TestResponse
    {
        return $this->actingAs($user)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id,
            'feeding_date' => now()->toDateTimeString(),
            'quantity' => $schedule->quantity,
            'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => $weightBefore,
            'weight_after' => $weightAfter,
        ]);
    }

    public function test_latest_three_poor_gain_feeding_records_are_highlighted(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        $this->postFeedingRecord($admin, $schedule, 400, 400); // baseline (no trend)
        $this->postFeedingRecord($admin, $schedule, 400, 400); // Record 1: no_gain
        $this->postFeedingRecord($admin, $schedule, 400, 395); // Record 2: loss
        $this->postFeedingRecord($admin, $schedule, 395, 395); // Record 3: no_gain

        $latestThreeIds = FeedingRecord::where('reptile_id', $reptile->id)
            ->orderByDesc('feeding_date')->orderByDesc('id')->limit(3)->pluck('id');

        $response = $this->actingAs($admin)->getJson(route('admin.reptiles.history.feeding-data', $reptile));

        $response->assertOk();
        $rows = collect($response->json('data'))->keyBy('DT_RowId');

        foreach ($latestThreeIds as $id) {
            $this->assertSame('table-danger', $rows[(string) $id]['DT_RowClass']);
        }
    }

    public function test_latest_three_records_are_not_highlighted_when_not_all_poor_gain(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        // A normal gain streak — none of these should ever be highlighted.
        $this->postFeedingRecord($admin, $schedule, 400, 410);
        $this->postFeedingRecord($admin, $schedule, 410, 420);
        $this->postFeedingRecord($admin, $schedule, 420, 430);

        $response = $this->actingAs($admin)->getJson(route('admin.reptiles.history.feeding-data', $reptile));

        $response->assertOk();
        foreach ($response->json('data') as $row) {
            $this->assertSame('', $row['DT_RowClass']);
        }
    }

    // 25-26: weight alert display, no new alert generated ----------------------

    public function test_existing_weight_alert_message_is_displayed_when_applicable(): void
    {
        $reptile = Reptile::factory()->create();
        HealthAlert::factory()->create([
            'reptile_id' => $reptile->id,
            'status' => 'active',
            'title' => 'Weight Gain Alert',
            'message' => 'The reptile is not gaining weight properly. Please consult a veterinarian.',
        ]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('WEIGHT GAIN ALERT');
        $response->assertSee('The reptile is not gaining weight properly. Please consult a veterinarian.');
    }

    public function test_viewing_history_does_not_create_a_new_health_alert(): void
    {
        $reptile = Reptile::factory()->create();
        $this->assertDatabaseCount('health_alerts', 0);

        $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $this->assertDatabaseCount('health_alerts', 0);
    }

    // 27: prescription links use the existing secure route ---------------------

    public function test_medical_prescription_link_uses_the_existing_secure_route(): void
    {
        $reptile = Reptile::factory()->create();
        $record = MedicalRecord::factory()->create([
            'reptile_id' => $reptile->id,
            'prescription_path' => 'medical-prescriptions/some-uuid.pdf',
        ]);

        $response = $this->actingAs(User::factory()->create())->getJson(route('admin.reptiles.history.medical-data', $reptile));

        $response->assertOk();
        // assertSee() would false-negative here: JSON-encodes "/" as "\/",
        // so check the decoded payload instead of the raw response body.
        $this->assertStringContainsString(
            route('admin.medical-records.prescription', $record),
            $response->json('data.0.prescription')
        );
    }

    // 28: empty states ----------------------------------------------------------

    public function test_empty_history_sections_display_proper_empty_states(): void
    {
        $reptile = Reptile::factory()->create(['notes' => null]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertSee('No feeding records found.');
        $response->assertSee('No shedding records found.');
        $response->assertSee('No medical records found.');
        $response->assertSee('No health alerts found.');
        $response->assertSee('No observations recorded.');
    }

    // 29-30: counts and latest records -------------------------------------------

    public function test_history_counts_are_correct(): void
    {
        $reptile = Reptile::factory()->create();
        FeedingRecord::factory()->count(3)->create(['reptile_id' => $reptile->id]);
        SheddingRecord::factory()->count(2)->create(['reptile_id' => $reptile->id]);
        MedicalRecord::factory()->count(4)->create(['reptile_id' => $reptile->id]);
        HealthAlert::factory()->count(2)->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        HealthAlert::factory()->create(['reptile_id' => $reptile->id, 'status' => 'resolved']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertViewHas('counts', function ($counts) {
            return $counts['totalFeedingRecords'] === 3
                && $counts['totalSheddingRecords'] === 2
                && $counts['totalMedicalRecords'] === 4
                && $counts['totalHealthAlerts'] === 3
                && $counts['activeHealthAlerts'] === 2;
        });
    }

    public function test_latest_records_are_correct(): void
    {
        $reptile = Reptile::factory()->create();

        FeedingRecord::factory()->create(['reptile_id' => $reptile->id, 'feeding_date' => now()->subDays(5)]);
        $latestFeeding = FeedingRecord::factory()->create(['reptile_id' => $reptile->id, 'feeding_date' => now()->subDay()]);

        SheddingRecord::factory()->create(['reptile_id' => $reptile->id, 'shedding_date' => now()->subDays(10)]);
        $latestShedding = SheddingRecord::factory()->create(['reptile_id' => $reptile->id, 'shedding_date' => now()->subDays(2)]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.history', $reptile));

        $response->assertViewHas('latestRecords', function ($records) use ($latestFeeding, $latestShedding) {
            return $records['feeding']->id === $latestFeeding->id
                && $records['shedding']->id === $latestShedding->id;
        });
    }

    // 31-36: DataTables -----------------------------------------------------------

    protected function dataTableColumnsParam(array $names): array
    {
        return collect($names)->map(fn ($name) => [
            'data' => $name, 'name' => '', 'searchable' => 'true', 'orderable' => 'true',
            'search' => ['value' => '', 'regex' => 'false'],
        ])->all();
    }

    public function test_feeding_history_datatable_loads_scoped_searches_paginates_and_sorts(): void
    {
        $reptileA = Reptile::factory()->create();
        $reptileB = Reptile::factory()->create();
        FeedingRecord::factory()->count(15)->create(['reptile_id' => $reptileA->id]);
        FeedingRecord::factory()->count(3)->create(['reptile_id' => $reptileB->id]);

        $user = $this->actingAs(User::factory()->create());

        $response = $user->getJson(route('admin.reptiles.history.feeding-data', $reptileA, false).'?'.http_build_query([
            'draw' => 1, 'start' => 0, 'length' => 10,
            'columns' => $this->dataTableColumnsParam(['feeding_date', 'food_type_label', 'quantity_label', 'weight_before', 'weight_after', 'weight_after_defecation', 'effective_weight_label', 'weight_change', 'trend_badge', 'alert_badge', 'actions']),
        ]));

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 15); // scoped to reptileA only, not 18
        $this->assertCount(10, $response->json('data')); // paginated
    }

    public function test_shedding_history_datatable_is_scoped_to_the_reptile(): void
    {
        $reptileA = Reptile::factory()->create();
        $reptileB = Reptile::factory()->create();
        SheddingRecord::factory()->count(4)->create(['reptile_id' => $reptileA->id]);
        SheddingRecord::factory()->count(2)->create(['reptile_id' => $reptileB->id]);

        $response = $this->actingAs(User::factory()->create())->getJson(
            route('admin.reptiles.history.shedding-data', $reptileA, false).'?'.http_build_query([
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(['shedding_date', 'status_badge', 'notes', 'observations', 'created_by_name', 'actions']),
            ])
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 4);
    }

    public function test_medical_history_datatable_search_is_scoped_to_the_reptile(): void
    {
        $reptile = Reptile::factory()->create();
        MedicalRecord::factory()->create(['reptile_id' => $reptile->id, 'symptoms_or_condition' => 'UniqueConditionHere']);
        // Another reptile with the exact same searchable term must never surface here.
        MedicalRecord::factory()->create(['symptoms_or_condition' => 'UniqueConditionHere']);

        $response = $this->actingAs(User::factory()->create())->getJson(
            route('admin.reptiles.history.medical-data', $reptile, false).'?'.http_build_query([
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(['reptile_name', 'treatment_date', 'symptoms_or_condition', 'medicine_name', 'dosage', 'veterinarian_name', 'prescription', 'created_by_name', 'actions']),
                'search' => ['value' => 'UniqueConditionHere', 'regex' => 'false'],
            ])
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 1);
        $response->assertJsonPath('recordsFiltered', 1);
    }

    public function test_health_alert_history_datatable_sorting_works_and_is_scoped(): void
    {
        $reptile = Reptile::factory()->create();
        $older = HealthAlert::factory()->create(['reptile_id' => $reptile->id, 'triggered_at' => now()->subDays(10)]);
        $newer = HealthAlert::factory()->create(['reptile_id' => $reptile->id, 'triggered_at' => now()->subDay()]);
        HealthAlert::factory()->create(); // another reptile entirely

        $response = $this->actingAs(User::factory()->create())->getJson(
            route('admin.reptiles.history.health-alerts-data', $reptile, false).'?'.http_build_query([
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(['reptile_name', 'alert_type_label', 'title', 'severity_badge', 'status_badge', 'triggered_at', 'source_label', 'actions']),
                'order' => [['column' => 5, 'dir' => 'desc']],
            ])
        );

        $response->assertOk();
        $response->assertJsonPath('recordsTotal', 2);
        $data = $response->json('data');
        $this->assertSame((string) $newer->id, (string) $data[0]['DT_RowId']);
    }

    public function test_feeding_history_datatable_avoids_n_plus_one_queries(): void
    {
        $reptile = Reptile::factory()->create();
        FeedingRecord::factory()->count(10)->create(['reptile_id' => $reptile->id]);

        DB::enableQueryLog();

        $this->actingAs(User::factory()->create())->getJson(
            route('admin.reptiles.history.feeding-data', $reptile, false).'?'.http_build_query([
                'draw' => 1, 'start' => 0, 'length' => 10,
                'columns' => $this->dataTableColumnsParam(['feeding_date', 'food_type_label', 'quantity_label', 'weight_before', 'weight_after', 'weight_after_defecation', 'effective_weight_label', 'weight_change', 'trend_badge', 'alert_badge', 'actions']),
            ])
        )->assertOk();

        $queryCount = count(DB::getQueryLog());
        DB::disableQueryLog();

        $this->assertLessThan(15, $queryCount);
    }

    // 37 (run separately, see summary): existing suites continue passing.
}
