<?php

namespace Tests\Feature\Admin;

use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

class FeedingRecordManagementTest extends TestCase
{
    use RefreshDatabase;

    protected int $feedingDayOffset = 0;

    /**
     * An active feeding schedule for an active reptile/food type — the normal
     * starting point for "record a feeding" scenarios.
     */
    protected function activeSchedule(array $reptileOverrides = [], array $scheduleOverrides = []): FeedingSchedule
    {
        $reptile = Reptile::factory()->create(array_merge(['status' => 'active'], $reptileOverrides));
        $foodType = FoodType::factory()->create(['status' => true]);

        return FeedingSchedule::factory()->create(array_merge([
            'reptile_id' => $reptile->id,
            'food_type_id' => $foodType->id,
            'status' => 'active',
            'quantity' => 1,
            'quantity_unit' => 'piece',
            'interval_days' => 7,
            'end_date' => null,
        ], $scheduleOverrides));
    }

    protected function validPayload(FeedingSchedule $schedule, array $overrides = []): array
    {
        $this->feedingDayOffset++;

        return array_merge([
            'feeding_schedule_id' => $schedule->id,
            'feeding_date' => now()->addDays($this->feedingDayOffset)->format('Y-m-d\TH:i'),
            'quantity' => 1,
            'quantity_unit' => 'piece',
            'weight_before' => 300,
            'weight_after' => 310,
            'weight_after_defecation' => 306,
            'notes' => null,
        ], $overrides);
    }

    protected function recordFeeding(User $user, FeedingSchedule $schedule, array $overrides = []): TestResponse
    {
        return $this->actingAs($user)->post(route('admin.feeding-records.store'), $this->validPayload($schedule, $overrides));
    }

    /**
     * A payload for the normal (schedule-less) "Reptile → Add Feeding
     * Record" workflow: reptile_id/food_type_id given directly, no
     * feeding_schedule_id at all.
     */
    protected function standalonePayload(Reptile $reptile, FoodType $foodType, array $overrides = []): array
    {
        $this->feedingDayOffset++;

        return array_merge([
            'reptile_id' => $reptile->id,
            'food_type_id' => $foodType->id,
            'feeding_date' => now()->addDays($this->feedingDayOffset)->format('Y-m-d\TH:i'),
            'quantity' => 1,
            'quantity_unit' => 'piece',
            'weight_before' => 300,
            'weight_after' => 310,
            'weight_after_defecation' => 306,
            'notes' => null,
        ], $overrides);
    }

    // 1-3: access -------------------------------------------------------------

    public function test_guest_cannot_access_feeding_records(): void
    {
        $response = $this->get(route('admin.feeding-records.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_view_feeding_records(): void
    {
        // No Staff/Admin distinction exists in this app's auth implementation —
        // this exercises the same route any authenticated user would, standing
        // in for "Admin".
        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-records.index'));

        $response->assertOk();
        $response->assertViewIs('admin.feeding-records.index');
    }

    public function test_authenticated_staff_can_view_feeding_records(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-records.index'));

        $response->assertOk();
    }

    // 4-6: create ---------------------------------------------------------------

    public function test_admin_can_record_a_feeding(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->recordFeeding(User::factory()->create(), $schedule);

        $response->assertRedirect(route('admin.reptiles.show', $schedule->reptile_id));
        $response->assertSessionHas('success', 'Feeding record saved successfully.');
        $this->assertDatabaseCount('feeding_records', 1);
    }

    public function test_staff_can_record_a_feeding(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->recordFeeding(User::factory()->create(), $schedule);

        $response->assertRedirect(route('admin.reptiles.show', $schedule->reptile_id));
        $this->assertDatabaseCount('feeding_records', 1);
    }

    public function test_created_record_snapshots_reptile_and_food_type_from_the_schedule(): void
    {
        $schedule = $this->activeSchedule();

        $this->recordFeeding(User::factory()->create(), $schedule);

        $this->assertDatabaseHas('feeding_records', [
            'feeding_schedule_id' => $schedule->id,
            'reptile_id' => $schedule->reptile_id,
            'food_type_id' => $schedule->food_type_id,
        ]);
    }

    // 7-9: feeding schedule validation --------------------------------------

    public function test_a_feeding_record_can_be_created_without_a_feeding_schedule(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $foodType = FoodType::factory()->create(['status' => true]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->standalonePayload($reptile, $foodType));

        $response->assertRedirect(route('admin.reptiles.show', $reptile->id));
        $response->assertSessionHas('success', 'Feeding record saved successfully.');
        $this->assertDatabaseHas('feeding_records', [
            'reptile_id' => $reptile->id,
            'food_type_id' => $foodType->id,
            'feeding_schedule_id' => null,
        ]);
    }

    /**
     * The client no longer wants Feeding Schedules in the normal workflow —
     * confirmed by locking the sidebar's own intentional omission (see
     * admin.layouts.menu) in a test, so a future edit can't silently bring
     * it back. The module itself stays fully intact and reachable by direct
     * URL — see FeedingScheduleManagementTest — just not linked from here.
     */
    public function test_sidebar_never_links_to_feeding_schedules(): void
    {
        $response = $this->actingAs(User::factory()->create())->get(route('admin.dashboard'));

        $response->assertOk();
        // A source comment in the menu partial explains the omission and
        // mentions "Feeding Schedules" by name — only the actual link/href
        // matters here, not that comment text.
        $response->assertDontSee(route('admin.feeding-schedules.index'), false);
        $response->assertDontSee('<div data-i18n="Feeding Schedules">', false);
    }

    public function test_reptile_id_is_required_when_no_feeding_schedule_is_given(): void
    {
        $foodType = FoodType::factory()->create(['status' => true]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->standalonePayload(Reptile::factory()->create(['status' => 'active']), $foodType, ['reptile_id' => '']));

        $response->assertSessionHasErrors('reptile_id');
        $this->assertDatabaseCount('feeding_records', 0);
    }

    public function test_food_type_id_is_required_when_no_feeding_schedule_is_given(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->standalonePayload($reptile, FoodType::factory()->create(['status' => true]), ['food_type_id' => '']));

        $response->assertSessionHasErrors('food_type_id');
        $this->assertDatabaseCount('feeding_records', 0);
    }

    public function test_a_feeding_record_cannot_be_added_directly_for_an_inactive_reptile(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'inactive']);
        $foodType = FoodType::factory()->create(['status' => true]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->standalonePayload($reptile, $foodType));

        $response->assertSessionHasErrors('reptile_id');
        $this->assertDatabaseCount('feeding_records', 0);
    }

    public function test_invalid_feeding_schedule_is_rejected(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['feeding_schedule_id' => 999999]));

        $response->assertSessionHasErrors('feeding_schedule_id');
    }

    public function test_inactive_feeding_schedule_cannot_be_used_to_record_a_feeding(): void
    {
        $schedule = $this->activeSchedule([], ['status' => 'inactive']);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule));

        $response->assertSessionHasErrors('feeding_schedule_id');
        $this->assertDatabaseCount('feeding_records', 0);
    }

    public function test_feeding_schedule_for_an_inactive_reptile_is_rejected(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $foodType = FoodType::factory()->create(['status' => true]);
        $schedule = FeedingSchedule::factory()->create([
            'reptile_id' => $reptile->id, 'food_type_id' => $foodType->id, 'status' => 'active',
        ]);
        $reptile->update(['status' => 'inactive']);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule));

        $response->assertSessionHasErrors('feeding_schedule_id');
        $this->assertDatabaseCount('feeding_records', 0);
    }

    // 10-14: field validation -------------------------------------------------

    public function test_quantity_is_required(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['quantity' => '']));

        $response->assertSessionHasErrors('quantity');
    }

    public function test_quantity_must_be_greater_than_zero(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['quantity' => 0]));

        $response->assertSessionHasErrors('quantity');
    }

    public function test_feeding_date_is_required(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['feeding_date' => '']));

        $response->assertSessionHasErrors('feeding_date');
    }

    public function test_weight_before_is_required_and_must_be_greater_than_zero(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        $this->actingAs($user)
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['weight_before' => '']))
            ->assertSessionHasErrors('weight_before');

        $this->actingAs($user)
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['weight_before' => 0]))
            ->assertSessionHasErrors('weight_before');
    }

    public function test_weight_after_is_required_and_must_be_greater_than_zero(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        $this->actingAs($user)
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['weight_after' => '']))
            ->assertSessionHasErrors('weight_after');

        $this->actingAs($user)
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['weight_after' => 0]))
            ->assertSessionHasErrors('weight_after');
    }

    public function test_weight_after_defecation_is_optional(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->recordFeeding(User::factory()->create(), $schedule, ['weight_after_defecation' => null]);

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('feeding_records', ['weight_after_defecation' => null]);
    }

    public function test_invalid_weight_after_defecation_is_rejected(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-records.store'), $this->validPayload($schedule, ['weight_after_defecation' => 0]));

        $response->assertSessionHasErrors('weight_after_defecation');
    }

    public function test_weight_loss_is_a_valid_measurement(): void
    {
        $schedule = $this->activeSchedule();

        $response = $this->recordFeeding(User::factory()->create(), $schedule, [
            'weight_before' => 500, 'weight_after' => 495, 'weight_after_defecation' => null,
        ]);

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('feeding_records', ['weight_before' => 500, 'weight_after' => 495]);
    }

    // 15-17: quantity snapshot / historical integrity -------------------------

    public function test_actual_quantity_can_differ_from_the_scheduled_quantity(): void
    {
        $schedule = $this->activeSchedule([], ['quantity' => 1, 'quantity_unit' => 'piece']);

        $this->recordFeeding(User::factory()->create(), $schedule, ['quantity' => 2, 'quantity_unit' => 'piece']);

        $this->assertDatabaseHas('feeding_records', ['quantity' => 2]);
        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id, 'quantity' => 1]);
    }

    public function test_editing_a_feeding_schedule_never_changes_an_existing_feeding_record(): void
    {
        $schedule = $this->activeSchedule([], ['quantity' => 1]);
        $this->recordFeeding(User::factory()->create(), $schedule, ['quantity' => 1]);

        $schedule->update(['quantity' => 2]);

        $this->assertDatabaseHas('feeding_records', ['feeding_schedule_id' => $schedule->id, 'quantity' => 1]);
    }

    // 18-21: weight change calculation ---------------------------------------

    public function test_weight_change_is_calculated_automatically(): void
    {
        $schedule = $this->activeSchedule();

        $this->recordFeeding(User::factory()->create(), $schedule, [
            'weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306,
        ]);

        $this->assertDatabaseHas('feeding_records', ['weight_change' => 6]);
    }

    public function test_weight_change_falls_back_to_after_minus_before_without_defecation_weight(): void
    {
        $schedule = $this->activeSchedule();

        $this->recordFeeding(User::factory()->create(), $schedule, [
            'weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => null,
        ]);

        $this->assertDatabaseHas('feeding_records', ['weight_change' => 10, 'weight_after_defecation' => null]);
    }

    public function test_first_feeding_record_has_no_trend(): void
    {
        $schedule = $this->activeSchedule();

        $this->recordFeeding(User::factory()->create(), $schedule);

        $record = FeedingRecord::first();
        $this->assertNull($record->weight_trend);
    }

    public function test_gain_no_gain_and_loss_are_detected_across_records(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => 300]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 306, 'weight_after_defecation' => 306]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 306, 'weight_after' => 306, 'weight_after_defecation' => 306]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 306, 'weight_after' => 300, 'weight_after_defecation' => 300]);

        $records = FeedingRecord::orderBy('feeding_date')->get();

        $this->assertNull($records[0]->weight_trend);
        $this->assertSame('gain', $records[1]->weight_trend);
        $this->assertSame('no_gain', $records[2]->weight_trend);
        $this->assertSame('loss', $records[3]->weight_trend);
    }

    // 22-24: current weight sync ----------------------------------------------

    public function test_reptile_current_weight_is_updated_after_feeding(): void
    {
        $schedule = $this->activeSchedule();

        $this->recordFeeding(User::factory()->create(), $schedule, [
            'weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306,
        ]);

        $this->assertEquals(306, $schedule->reptile->fresh()->current_weight);
    }

    public function test_after_weight_is_used_for_current_weight_when_defecation_weight_is_unavailable(): void
    {
        $schedule = $this->activeSchedule();

        $this->recordFeeding(User::factory()->create(), $schedule, [
            'weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => null,
        ]);

        $this->assertEquals(310, $schedule->reptile->fresh()->current_weight);
    }

    // 25-28: schedule advancement ---------------------------------------------

    public function test_schedule_next_due_at_advances_from_the_actual_feeding_date(): void
    {
        $schedule = $this->activeSchedule([], ['interval_days' => 7]);
        $feedingDate = now()->addDay()->setTime(19, 15);

        $this->recordFeeding(User::factory()->create(), $schedule, ['feeding_date' => $feedingDate->format('Y-m-d\TH:i')]);

        $schedule->refresh();
        $this->assertTrue($schedule->next_due_at->equalTo($feedingDate->copy()->addDays(7)));
    }

    public function test_schedule_becomes_completed_once_next_due_at_passes_the_end_date(): void
    {
        $feedingDate = now()->addDay();
        $schedule = $this->activeSchedule([], [
            'interval_days' => 7,
            'end_date' => $feedingDate->copy()->addDays(3)->toDateString(),
        ]);

        $this->recordFeeding(User::factory()->create(), $schedule, ['feeding_date' => $feedingDate->format('Y-m-d\TH:i')]);

        $this->assertSame('completed', $schedule->fresh()->status);
    }

    public function test_schedule_stays_active_when_next_due_at_is_still_within_the_end_date(): void
    {
        $feedingDate = now()->addDay();
        $schedule = $this->activeSchedule([], [
            'interval_days' => 7,
            'end_date' => $feedingDate->copy()->addDays(10)->toDateString(),
        ]);

        $this->recordFeeding(User::factory()->create(), $schedule, ['feeding_date' => $feedingDate->format('Y-m-d\TH:i')]);

        $this->assertSame('active', $schedule->fresh()->status);
    }

    public function test_editing_first_due_at_no_longer_resets_next_due_at_once_a_feeding_has_been_recorded(): void
    {
        $schedule = $this->activeSchedule();
        $this->recordFeeding(User::factory()->create(), $schedule);
        $schedule->refresh();
        $nextDueAtAfterFeeding = $schedule->next_due_at->copy();

        $this->actingAs(User::factory()->create())->put(route('admin.feeding-schedules.update', $schedule), [
            'reptile_id' => $schedule->reptile_id,
            'food_type_id' => $schedule->food_type_id,
            'quantity' => (string) $schedule->quantity,
            'quantity_unit' => $schedule->quantity_unit,
            'interval_days' => $schedule->interval_days,
            'first_due_date' => now()->addDays(20)->toDateString(),
            'first_due_time' => '19:00',
            'start_date' => $schedule->start_date->toDateString(),
            'end_date' => null,
            'status' => $schedule->status,
            'notes' => null,
        ]);

        $schedule->refresh();
        $this->assertTrue($nextDueAtAfterFeeding->equalTo($schedule->next_due_at));
    }

    // 29-31: the three-consecutive-poor-gain alert ---------------------------

    public function test_alert_is_not_triggered_with_fewer_than_three_previous_records(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);

        $latest = FeedingRecord::orderByDesc('feeding_date')->first();
        $this->assertFalse((bool) $latest->weight_alert_triggered);
    }

    public function test_three_consecutive_poor_gain_records_trigger_the_alert_on_the_third_feeding(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        // Record 1: 300 (first record, no trend yet)
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);
        // Record 2: 300 -> no_gain
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);

        $record2 = FeedingRecord::orderByDesc('feeding_date')->first();
        $this->assertFalse((bool) $record2->weight_alert_triggered);

        // Record 3: 299 -> loss. Together with records 1-2 this completes a
        // three-record sequence with no weight gain — the alert must fire
        // immediately on this record, not wait for a 4th.
        $this->recordFeeding($user, $schedule, ['weight_before' => 299, 'weight_after' => 299, 'weight_after_defecation' => null]);

        $record3 = FeedingRecord::orderByDesc('feeding_date')->first();
        $this->assertTrue((bool) $record3->weight_alert_triggered);
        $this->assertSame(FeedingRecord::ALERT_MESSAGE, $record3->weight_alert_message);
    }

    public function test_alert_is_visible_on_the_feeding_records_index(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 299, 'weight_after' => 299, 'weight_after_defecation' => null]);

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index', ['alert' => 'alerts']));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
        $response->assertSee('Weight Alert');
    }

    // 32-34: editing ------------------------------------------------------------

    public function test_admin_can_edit_a_feeding_record(): void
    {
        $schedule = $this->activeSchedule();
        $this->recordFeeding(User::factory()->create(), $schedule);
        $record = FeedingRecord::first();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-records.edit', $record));

        $response->assertOk();
        $response->assertViewIs('admin.feeding-records.edit');
    }

    public function test_editing_weight_values_recalculates_weight_change_and_trend(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306]);
        $record = FeedingRecord::first();

        $this->actingAs($user)->put(route('admin.feeding-records.update', $record), [
            'feeding_date' => $record->feeding_date->format('Y-m-d\TH:i'),
            'quantity' => $record->quantity,
            'quantity_unit' => $record->quantity_unit,
            'weight_before' => 300,
            'weight_after' => 320,
            'weight_after_defecation' => 315,
            'notes' => null,
        ]);

        $record->refresh();
        $this->assertEquals(15, $record->weight_change);
    }

    public function test_editing_an_earlier_record_recalculates_later_records_trend(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 305, 'weight_after_defecation' => null]);

        $records = FeedingRecord::orderBy('feeding_date')->get();
        $this->assertSame('gain', $records[1]->weight_trend);

        // Correcting the first record's measurement upward changes what the
        // second record's trend should be, relative to it.
        $this->actingAs($user)->put(route('admin.feeding-records.update', $records[0]), [
            'feeding_date' => $records[0]->feeding_date->format('Y-m-d\TH:i'),
            'quantity' => $records[0]->quantity,
            'quantity_unit' => $records[0]->quantity_unit,
            'weight_before' => 300,
            'weight_after' => 310,
            'weight_after_defecation' => null,
            'notes' => null,
        ]);

        $this->assertSame('loss', $records[1]->fresh()->weight_trend);
    }

    // 35-41: filters ------------------------------------------------------------

    public function test_search_by_reptile_name_works(): void
    {
        $rockySchedule = $this->activeSchedule(['name' => 'Rocky']);
        $lunaSchedule = $this->activeSchedule(['name' => 'Luna']);
        $user = User::factory()->create();
        $this->recordFeeding($user, $rockySchedule);
        $this->recordFeeding($user, $lunaSchedule);

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index', ['search' => 'rocky']));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_search_by_food_type_works(): void
    {
        $mouseFood = FoodType::factory()->create(['name' => 'UniqueUniqueMouse']);
        $mouseSchedule = FeedingSchedule::factory()->create([
            'reptile_id' => Reptile::factory()->create(['status' => 'active'])->id,
            'food_type_id' => $mouseFood->id,
            'status' => 'active',
        ]);
        $cricketSchedule = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $mouseSchedule);
        $this->recordFeeding($user, $cricketSchedule);

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index', ['search' => 'UniqueUniqueMouse']));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_reptile_filter_works(): void
    {
        $scheduleA = $this->activeSchedule();
        $scheduleB = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $scheduleA);
        $this->recordFeeding($user, $scheduleB);

        $response = $this->actingAs($user)
            ->get(route('admin.feeding-records.index', ['reptile_id' => $scheduleA->reptile_id]));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_food_type_filter_works(): void
    {
        $scheduleA = $this->activeSchedule();
        $scheduleB = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $scheduleA);
        $this->recordFeeding($user, $scheduleB);

        $response = $this->actingAs($user)
            ->get(route('admin.feeding-records.index', ['food_type_id' => $scheduleA->food_type_id]));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_weight_trend_filter_works(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 306, 'weight_after_defecation' => null]);

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index', ['trend' => 'gain']));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_alert_filter_works(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $schedule, ['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => null]);

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index', ['alert' => 'none']));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    public function test_date_range_filter_works(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $schedule, ['feeding_date' => now()->addDays(2)->format('Y-m-d\TH:i')]);
        $this->recordFeeding($user, $schedule, ['feeding_date' => now()->addDays(40)->format('Y-m-d\TH:i')]);

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index', [
            'date_from' => now()->toDateString(),
            'date_to' => now()->addDays(10)->toDateString(),
        ]));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->total() === 1);
    }

    // 42-43: pagination -----------------------------------------------------

    public function test_pagination_works(): void
    {
        $schedule = $this->activeSchedule();
        $user = User::factory()->create();

        for ($i = 0; $i < 20; $i++) {
            $this->recordFeeding($user, $schedule);
        }

        $response = $this->actingAs($user)->get(route('admin.feeding-records.index'));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->count() === 15 && $records->hasMorePages());
    }

    public function test_pagination_preserves_query_parameters(): void
    {
        $schedule = $this->activeSchedule(['name' => 'Rocky']);
        $user = User::factory()->create();

        for ($i = 0; $i < 20; $i++) {
            $this->recordFeeding($user, $schedule);
        }

        $response = $this->actingAs($user)
            ->get(route('admin.feeding-records.index', ['search' => 'rocky', 'page' => 2]));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->currentPage() === 2 && $records->total() === 20);
        $response->assertSee('search=rocky');
    }

    // 44: reptile profile scoping ------------------------------------------

    public function test_records_from_another_reptile_are_never_included_in_a_reptiles_history(): void
    {
        $scheduleA = $this->activeSchedule();
        $scheduleB = $this->activeSchedule();
        $user = User::factory()->create();
        $this->recordFeeding($user, $scheduleA);
        $this->recordFeeding($user, $scheduleB);

        $response = $this->actingAs($user)->get(route('admin.reptiles.show', $scheduleA->reptile_id));

        $response->assertOk();
        $response->assertViewHas('feedingRecords', fn ($records) => $records->count() === 1
            && $records->first()->reptile_id === $scheduleA->reptile_id);
    }
}
