<?php

namespace Tests\Feature\Admin;

use App\Models\HealthAlert;
use App\Models\Reptile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DashboardTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_cannot_access_dashboard(): void
    {
        $response = $this->get(route('admin.dashboard'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_access_dashboard(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertOk();
    }

    public function test_dashboard_uses_the_admin_layout(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertViewIs('admin.dashboard');
        $response->assertSee('Reptile Management Dashboard');
        // Sidebar/header partials from the shared admin layout.
        $response->assertSee($user->name);
    }

    public function test_dashboard_does_not_crash_when_there_is_no_reptile_data(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertOk();
    }

    public function test_dashboard_displays_empty_states_when_no_data_exists(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertSee('No reptiles have been added yet.');
        $response->assertSee('No recent activity.');
        $response->assertSee('No alerts at this time.');
        $response->assertSee('No weight data recorded yet.');
        $response->assertSee('No growth data yet.');
    }

    public function test_dashboard_summary_cards_default_to_zero_without_reptile_data(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertViewHas('totalReptiles', 0);
        $response->assertViewHas('activeReptiles', 0);
        $response->assertViewHas('inactiveReptiles', 0);
        $response->assertViewHas('weightChecksDue', 0);
        $response->assertViewHas('growthWarnings', 0);
        $response->assertViewHas('criticalAlerts', 0);
    }

    /**
     * Feeding Schedules are intentionally no longer part of the normal
     * workflow (see menu.blade.php) — the dashboard must never surface
     * schedule-driven cards/queries, even though the FeedingSchedule module
     * itself remains fully intact and reachable by direct URL.
     */
    public function test_dashboard_never_shows_feeding_schedule_cards(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertOk();
        $response->assertDontSee('Feeding Due Today');
        $response->assertDontSee('Overdue Feedings');
        $response->assertDontSee('Upcoming Feedings');
        $response->assertDontSee("Today's Feeding");
        $response->assertViewMissing('feedingDueToday');
        $response->assertViewMissing('overdueFeedings');
        $response->assertViewMissing('upcomingFeedings');
        $response->assertViewMissing('feedingSummary');
        $response->assertViewMissing('upcomingFeedingsList');
        $response->assertViewMissing('overdueFeedingsList');
    }

    public function test_dashboard_alert_links_to_its_reptiles_details_page(): void
    {
        $user = User::factory()->create();
        $reptile = Reptile::factory()->create(['name' => 'Spike']);
        HealthAlert::factory()->create(['reptile_id' => $reptile->id]);

        $response = $this->actingAs($user)->get(route('admin.dashboard'));

        $response->assertSee('Spike: '.\App\Models\FeedingRecord::ALERT_MESSAGE);
        $response->assertSee(route('admin.reptiles.show', $reptile), false);
    }
}
