<?php

namespace Tests\Feature\Admin;

use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FeedingScheduleManagementTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Build a valid store/update payload. Every scenario in this suite either
     * uses these defaults directly or overrides exactly the field it's testing.
     */
    protected function validPayload(array $overrides = []): array
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $foodType = FoodType::factory()->create(['status' => true]);

        return array_merge([
            'reptile_id' => $reptile->id,
            'food_type_id' => $foodType->id,
            'quantity' => 1,
            'quantity_unit' => 'piece',
            'interval_days' => 7,
            'first_due_date' => now()->addDay()->toDateString(),
            'first_due_time' => '19:00',
            'start_date' => now()->toDateString(),
            'end_date' => null,
            'status' => 'active',
            'notes' => null,
        ], $overrides);
    }

    // 1-3: access -----------------------------------------------------------

    public function test_guest_cannot_access_feeding_schedules(): void
    {
        $response = $this->get(route('admin.feeding-schedules.index'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_can_view_schedules(): void
    {
        // No Staff/Admin distinction exists in the current auth implementation
        // (Module 01: a single authenticated-user type) — this exercises the
        // same route as any authenticated user would, standing in for "Admin".
        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-schedules.index'));

        $response->assertOk();
        $response->assertViewIs('admin.feeding-schedules.index');
    }

    public function test_authenticated_staff_can_view_schedules(): void
    {
        // See note above: "Staff" is exercised via the same generic authenticated user.
        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-schedules.index'));

        $response->assertOk();
    }

    // 4-5: create (Admin/Staff) ----------------------------------------------

    public function test_admin_can_create_a_schedule(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload());

        $response->assertRedirect(route('admin.feeding-schedules.index'));
        $response->assertSessionHas('success', 'Feeding schedule created successfully.');
        $this->assertDatabaseCount('feeding_schedules', 1);
    }

    public function test_staff_can_create_a_schedule(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload());

        $response->assertRedirect(route('admin.feeding-schedules.index'));
        $this->assertDatabaseCount('feeding_schedules', 1);
    }

    // 6-8: reptile validation -------------------------------------------------

    public function test_reptile_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['reptile_id' => '']));

        $response->assertSessionHasErrors('reptile_id');
    }

    public function test_invalid_reptile_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['reptile_id' => 999999]));

        $response->assertSessionHasErrors('reptile_id');
    }

    public function test_inactive_reptile_cannot_receive_a_new_active_schedule(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'inactive']);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['reptile_id' => $reptile->id]));

        $response->assertSessionHasErrors('reptile_id');
        $this->assertDatabaseCount('feeding_schedules', 0);
    }

    // 9-13: food type validation ----------------------------------------------

    public function test_food_type_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['food_type_id' => '']));

        $response->assertSessionHasErrors('food_type_id');
    }

    public function test_invalid_food_type_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['food_type_id' => 999999]));

        $response->assertSessionHasErrors('food_type_id');
    }

    public function test_inactive_food_type_cannot_be_used_for_an_active_schedule(): void
    {
        $foodType = FoodType::factory()->create(['status' => false]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['food_type_id' => $foodType->id]));

        $response->assertSessionHasErrors('food_type_id');
        $this->assertDatabaseCount('feeding_schedules', 0);
    }

    public function test_parent_food_type_cannot_be_selected(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        FoodType::factory()->create(['name' => 'Adult', 'parent_id' => $mouse->id, 'status' => true]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['food_type_id' => $mouse->id]));

        $response->assertSessionHasErrors('food_type_id');
        $this->assertDatabaseCount('feeding_schedules', 0);
    }

    public function test_leaf_food_type_can_be_selected(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'Mouse', 'status' => true]);
        $adult = FoodType::factory()->create(['name' => 'Adult', 'parent_id' => $mouse->id, 'status' => true]);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['food_type_id' => $adult->id]));

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('feeding_schedules', ['food_type_id' => $adult->id]);
    }

    // 14-16: quantity/unit -----------------------------------------------------

    public function test_quantity_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['quantity' => '']));

        $response->assertSessionHasErrors('quantity');
    }

    public function test_quantity_must_be_greater_than_zero(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['quantity' => 0]));

        $response->assertSessionHasErrors('quantity');
    }

    public function test_invalid_quantity_unit_is_rejected(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['quantity_unit' => 'stone']));

        $response->assertSessionHasErrors('quantity_unit');
    }

    // 17-18: interval -----------------------------------------------------------

    public function test_interval_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['interval_days' => '']));

        $response->assertSessionHasErrors('interval_days');
    }

    public function test_interval_must_be_at_least_one_day(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['interval_days' => 0]));

        $response->assertSessionHasErrors('interval_days');
    }

    // 19-21: dates ----------------------------------------------------------

    public function test_first_due_date_time_is_required(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload([
                'first_due_date' => '',
                'first_due_time' => '',
            ]));

        $response->assertSessionHasErrors(['first_due_date', 'first_due_time']);
    }

    public function test_new_active_schedule_cannot_have_a_past_first_due_at(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload([
                'first_due_date' => now()->subDay()->toDateString(),
                'first_due_time' => '19:00',
            ]));

        $response->assertSessionHasErrors('first_due_date');
        $this->assertDatabaseCount('feeding_schedules', 0);
    }

    public function test_end_date_cannot_be_before_start_date(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload([
                'start_date' => now()->toDateString(),
                'end_date' => now()->subDay()->toDateString(),
            ]));

        $response->assertSessionHasErrors('end_date');
    }

    // 22-25: editing ----------------------------------------------------------

    public function test_admin_can_edit_schedule(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-schedules.edit', $schedule));

        $response->assertOk();
        $response->assertViewIs('admin.feeding-schedules.edit');
    }

    public function test_staff_can_edit_schedule(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-schedules.edit', $schedule));

        $response->assertOk();
    }

    public function test_editing_notes_does_not_change_next_due_at(): void
    {
        $schedule = FeedingSchedule::factory()->create();
        $originalNextDueAt = $schedule->next_due_at->copy();

        $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['notes' => 'Feed in the evening after handling.'])
        );

        $schedule->refresh();
        $this->assertTrue($originalNextDueAt->equalTo($schedule->next_due_at));
        $this->assertSame('Feed in the evening after handling.', $schedule->notes);
    }

    public function test_editing_quantity_does_not_change_next_due_at(): void
    {
        $schedule = FeedingSchedule::factory()->create(['quantity' => 1]);
        $originalNextDueAt = $schedule->next_due_at->copy();

        $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['quantity' => 2])
        );

        $schedule->refresh();
        $this->assertTrue($originalNextDueAt->equalTo($schedule->next_due_at));
        $this->assertEquals(2, $schedule->quantity);
    }

    // 26-31: activation/deactivation -------------------------------------------

    public function test_admin_can_deactivate_schedule(): void
    {
        $schedule = FeedingSchedule::factory()->create(['status' => 'active']);

        $response = $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['status' => 'inactive'])
        );

        $response->assertSessionHas('success', 'Feeding schedule updated successfully.');
        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id, 'status' => 'inactive']);
    }

    public function test_staff_can_deactivate_schedule(): void
    {
        $schedule = FeedingSchedule::factory()->create(['status' => 'active']);

        $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['status' => 'inactive'])
        );

        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id, 'status' => 'inactive']);
    }

    public function test_schedule_can_be_reactivated_when_valid(): void
    {
        $schedule = FeedingSchedule::factory()->inactive()->create();

        $response = $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['status' => 'active'])
        );

        $response->assertSessionDoesntHaveErrors();
        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id, 'status' => 'active']);
    }

    public function test_reactivation_fails_for_inactive_reptile(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'inactive']);
        $schedule = FeedingSchedule::factory()->inactive()->create(['reptile_id' => $reptile->id]);

        $response = $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['status' => 'active'])
        );

        $response->assertSessionHasErrors('reptile_id');
        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id, 'status' => 'inactive']);
    }

    public function test_reactivation_fails_for_inactive_food(): void
    {
        $foodType = FoodType::factory()->create(['status' => false]);
        $schedule = FeedingSchedule::factory()->inactive()->create(['food_type_id' => $foodType->id]);

        $response = $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['status' => 'active'])
        );

        $response->assertSessionHasErrors('food_type_id');
        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id, 'status' => 'inactive']);
    }

    public function test_duplicate_active_schedule_for_same_reptile_is_rejected(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.store'), $this->validPayload(['reptile_id' => $reptile->id]));

        $response->assertSessionHasErrors('reptile_id');
        $this->assertDatabaseCount('feeding_schedules', 1);
    }

    // 32-41: search & filters --------------------------------------------------

    public function test_search_by_reptile_name_works(): void
    {
        $rocky = Reptile::factory()->create(['name' => 'Rocky']);
        $luna = Reptile::factory()->create(['name' => 'Luna']);
        FeedingSchedule::factory()->create(['reptile_id' => $rocky->id]);
        FeedingSchedule::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['search' => 'rocky']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_search_by_reptile_code_works(): void
    {
        $rocky = Reptile::factory()->create(['reptile_code' => 'REP-000001']);
        $luna = Reptile::factory()->create(['reptile_code' => 'REP-000002']);
        FeedingSchedule::factory()->create(['reptile_id' => $rocky->id]);
        FeedingSchedule::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['search' => 'REP-000001']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_search_by_food_type_works(): void
    {
        $mouse = FoodType::factory()->create(['name' => 'UniqueMouseFood']);
        $cricket = FoodType::factory()->create(['name' => 'UniqueCricketFood']);
        FeedingSchedule::factory()->create(['food_type_id' => $mouse->id]);
        FeedingSchedule::factory()->create(['food_type_id' => $cricket->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['search' => 'UniqueMouseFood']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_reptile_filter_works(): void
    {
        $rocky = Reptile::factory()->create();
        $luna = Reptile::factory()->create();
        FeedingSchedule::factory()->create(['reptile_id' => $rocky->id]);
        FeedingSchedule::factory()->create(['reptile_id' => $luna->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['reptile_id' => $rocky->id]));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_food_filter_works(): void
    {
        $mouseFood = FoodType::factory()->create();
        $cricketFood = FoodType::factory()->create();
        FeedingSchedule::factory()->create(['food_type_id' => $mouseFood->id]);
        FeedingSchedule::factory()->create(['food_type_id' => $cricketFood->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['food_type_id' => $mouseFood->id]));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_status_filter_works(): void
    {
        FeedingSchedule::factory()->create(['status' => 'active']);
        FeedingSchedule::factory()->inactive()->create();

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['status' => 'inactive']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_upcoming_filter_works(): void
    {
        FeedingSchedule::factory()->create(['next_due_at' => now()->addDays(5), 'status' => 'active']);
        FeedingSchedule::factory()->create(['next_due_at' => now()->subHour(), 'status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['due' => 'upcoming']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_due_today_filter_works(): void
    {
        FeedingSchedule::factory()->create(['next_due_at' => now()->addHours(2), 'status' => 'active']);
        FeedingSchedule::factory()->create(['next_due_at' => now()->addDays(5), 'status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['due' => 'due_today']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_overdue_filter_works(): void
    {
        FeedingSchedule::factory()->create(['next_due_at' => now()->subHour(), 'status' => 'active']);
        FeedingSchedule::factory()->create(['next_due_at' => now()->addDays(5), 'status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['due' => 'overdue']));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    public function test_combined_filters_work(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);
        FeedingSchedule::factory()->create([
            'reptile_id' => $reptile->id, 'status' => 'active', 'next_due_at' => now()->subHour(),
        ]);
        FeedingSchedule::factory()->create([
            'reptile_id' => $reptile->id, 'status' => 'inactive', 'next_due_at' => now()->subHour(),
        ]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-schedules.index', [
            'search' => 'rocky',
            'reptile_id' => $reptile->id,
            'status' => 'active',
            'due' => 'overdue',
        ]));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->total() === 1);
    }

    // 42-43: pagination ---------------------------------------------------------

    public function test_pagination_works(): void
    {
        FeedingSchedule::factory()->count(20)->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.feeding-schedules.index'));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->count() === 15 && $schedules->hasMorePages());
    }

    public function test_pagination_preserves_query_parameters(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Rocky']);
        FeedingSchedule::factory()->count(20)->create(['reptile_id' => $reptile->id]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.index', ['search' => 'rocky', 'page' => 2]));

        $response->assertOk();
        $response->assertViewHas('feedingSchedules', fn ($schedules) => $schedules->currentPage() === 2 && $schedules->total() === 20);
        $response->assertSee('search=rocky');
    }

    // 44-45: historical integrity ------------------------------------------------

    public function test_inactive_schedules_remain_stored(): void
    {
        $schedule = FeedingSchedule::factory()->create(['status' => 'active']);

        $this->actingAs(User::factory()->create())->put(
            route('admin.feeding-schedules.update', $schedule),
            $this->scheduleUpdatePayload($schedule, ['status' => 'inactive'])
        );

        $this->assertDatabaseHas('feeding_schedules', ['id' => $schedule->id]);
    }

    public function test_deactivated_schedules_are_not_counted_as_active_upcoming_or_overdue(): void
    {
        $schedule = FeedingSchedule::factory()->inactive()->create(['next_due_at' => now()->subHour()]);

        $this->assertNull($schedule->dueStatus());
        $this->assertSame(0, FeedingSchedule::overdue()->count());
        $this->assertSame(0, FeedingSchedule::upcoming()->count());
        $this->assertSame(0, FeedingSchedule::dueToday()->count());
    }

    /**
     * A full update payload seeded from the schedule's current values, with overrides applied.
     */
    protected function scheduleUpdatePayload(FeedingSchedule $schedule, array $overrides = []): array
    {
        return array_merge([
            'reptile_id' => $schedule->reptile_id,
            'food_type_id' => $schedule->food_type_id,
            'quantity' => (string) $schedule->quantity,
            'quantity_unit' => $schedule->quantity_unit,
            'interval_days' => $schedule->interval_days,
            'first_due_date' => $schedule->first_due_at->toDateString(),
            'first_due_time' => $schedule->first_due_at->format('H:i'),
            'start_date' => $schedule->start_date->toDateString(),
            'end_date' => optional($schedule->end_date)->toDateString(),
            'status' => $schedule->status,
            'notes' => $schedule->notes,
        ], $overrides);
    }
}
