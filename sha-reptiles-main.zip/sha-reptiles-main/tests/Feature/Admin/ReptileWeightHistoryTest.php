<?php

namespace Tests\Feature\Admin;

use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\Reptile;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

/**
 * Weight History — a dedicated, read-only page for one reptile's own weight
 * measurements. Purely an aggregation view over Module 7's existing
 * feeding_records data: no new table, no new weight calculation, no new
 * "poor gain" rule. Reuses FeedingHistoryDataTable and
 * ReptileHistoryService::getHighlightedFeedingRecordIds() exactly as Module
 * 11's Complete History page already does.
 */
class ReptileWeightHistoryTest extends TestCase
{
    use RefreshDatabase;

    protected function postFeedingRecord(User $user, FeedingSchedule $schedule, float $weightBefore, float $weightAfter): TestResponse
    {
        return $this->actingAs($user)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id,
            'feeding_date' => now()->toDateTimeString(),
            'quantity' => $schedule->quantity,
            'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => $weightBefore,
            'weight_after' => $weightAfter,
        ]);
    }

    public function test_guest_cannot_access_weight_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_access_weight_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->admin()->create())->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertOk();
        $response->assertViewIs('admin.reptiles.weight-history');
    }

    public function test_staff_can_access_weight_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertOk();
    }

    public function test_reptile_identity_and_current_weight_are_displayed(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Albino Corn Snake 001', 'current_weight' => 302, 'weight_unit' => 'g']);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertOk();
        $response->assertSee('Albino Corn Snake 001');
        $response->assertSee($reptile->reptile_code);
        $response->assertSee('302');
    }

    public function test_category_species_and_variety_are_displayed(): void
    {
        $category = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $species = Species::factory()->create(['name' => 'Corn Snake', 'category_id' => $category->id]);
        $reptile = Reptile::factory()->create(['species_id' => $species->id]);

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertOk();
        $response->assertSee('Snake');
        $response->assertSee('Corn Snake');
    }

    public function test_back_to_reptile_details_link_is_present(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertOk();
        $response->assertSee(route('admin.reptiles.show', $reptile), false);
    }

    public function test_weight_history_table_uses_the_same_scoped_ajax_endpoint_as_complete_history(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->create())->get(route('admin.reptiles.weight-history', $reptile));

        $response->assertOk();
        // No new ajax route was introduced — the embedded DataTable points at
        // the existing, already reptile-scoped Module 11 endpoint (rendered
        // JSON-escaped inside the DataTable's inline init script).
        $escapedAjaxUrl = str_replace('/', '\\/', route('admin.reptiles.history.feeding-data', $reptile));
        $this->assertStringContainsString($escapedAjaxUrl, $response->getContent());
    }

    public function test_weight_and_trend_data_matches_the_underlying_feeding_records(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        $this->postFeedingRecord($admin, $schedule, 300, 305); // baseline: first record, no trend
        $this->postFeedingRecord($admin, $schedule, 305, 310); // gain

        $response = $this->actingAs($admin)->getJson(route('admin.reptiles.history.feeding-data', $reptile));

        $response->assertOk();
        $rows = collect($response->json('data'));

        $this->assertSame(2, $rows->count());
        $this->assertTrue($rows->contains(fn ($row) => str_contains($row['weight_change'], '+5')));
    }

    public function test_latest_three_poor_gain_feeding_records_are_highlighted(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        $this->postFeedingRecord($admin, $schedule, 400, 400); // baseline (no trend)
        $this->postFeedingRecord($admin, $schedule, 400, 400); // no_gain
        $this->postFeedingRecord($admin, $schedule, 400, 395); // loss
        $this->postFeedingRecord($admin, $schedule, 395, 395); // no_gain

        $latestThreeIds = FeedingRecord::where('reptile_id', $reptile->id)
            ->orderByDesc('feeding_date')->orderByDesc('id')->limit(3)->pluck('id');

        // The page itself shows the same warning banner Complete History does.
        $pageResponse = $this->actingAs($admin)->get(route('admin.reptiles.weight-history', $reptile));
        $pageResponse->assertOk();
        $pageResponse->assertSee(\App\Models\FeedingRecord::ALERT_MESSAGE);

        $response = $this->actingAs($admin)->getJson(route('admin.reptiles.history.feeding-data', $reptile));
        $response->assertOk();
        $rows = collect($response->json('data'))->keyBy('DT_RowId');

        foreach ($latestThreeIds as $id) {
            $this->assertSame('table-danger', $rows[(string) $id]['DT_RowClass']);
        }
    }

    public function test_weight_history_never_shows_another_reptiles_records(): void
    {
        $reptileA = Reptile::factory()->create(['status' => 'active']);
        $reptileB = Reptile::factory()->create(['status' => 'active']);
        $scheduleA = FeedingSchedule::factory()->create(['reptile_id' => $reptileA->id, 'status' => 'active']);
        $scheduleB = FeedingSchedule::factory()->create(['reptile_id' => $reptileB->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        $this->postFeedingRecord($admin, $scheduleA, 100, 105);
        $this->postFeedingRecord($admin, $scheduleB, 200, 205);

        $response = $this->actingAs($admin)->getJson(route('admin.reptiles.history.feeding-data', $reptileA));

        $response->assertOk();
        $rows = collect($response->json('data'));

        $this->assertSame(1, $rows->count());
        $this->assertSame(
            FeedingRecord::where('reptile_id', $reptileA->id)->value('id'),
            (int) $rows->first()['DT_RowId']
        );
    }

    public function test_nonexistent_reptile_returns_404(): void
    {
        $response = $this->actingAs(User::factory()->create())->get('/admin/reptiles/999999/weight-history');

        $response->assertNotFound();
    }
}
