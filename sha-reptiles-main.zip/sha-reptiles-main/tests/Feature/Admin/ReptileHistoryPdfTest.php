<?php

namespace Tests\Feature\Admin;

use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\HealthAlert;
use App\Models\MedicalRecord;
use App\Models\Reptile;
use App\Models\SheddingRecord;
use App\Models\Species;
use App\Models\SpeciesCategory;
use App\Models\SpeciesVariety;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Testing\TestResponse;
use Smalot\PdfParser\Parser as PdfParser;
use Tests\TestCase;

/**
 * Module 12 — PDF/Print of one reptile's Complete History. A read-only,
 * server-generated PDF built from the exact same ReptileHistoryService
 * (Module 11) that renders admin.reptiles.history — no second history
 * implementation, no new tables, no data mutation.
 */
class ReptileHistoryPdfTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Extracts the plain text of a generated PDF response so assertions can
     * check its actual rendered content rather than only its HTTP status —
     * dompdf's output is a real (optionally compressed) PDF, so assertSee()
     * against the raw response body would not reliably find anything.
     */
    protected function pdfText(TestResponse $response): string
    {
        return (new PdfParser)->parseContent($response->getContent())->getText();
    }

    // 1-3: access ---------------------------------------------------------

    public function test_guest_cannot_generate_pdf(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_generate_pdf(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->admin()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
    }

    public function test_staff_can_generate_pdf(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->create(['role' => 'staff']))
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
    }

    // 4-6: response shape ---------------------------------------------------

    public function test_pdf_response_is_successful_with_correct_content_type(): void
    {
        $reptile = Reptile::factory()->create();

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $response->assertHeader('content-type', 'application/pdf');
        $this->assertStringStartsWith('%PDF-', $response->getContent());
    }

    public function test_pdf_filename_is_generated_safely_from_the_reptile_name(): void
    {
        $reptile = Reptile::factory()->create(['name' => 'Royal Python 001']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $response->assertHeader('content-disposition');
        $this->assertStringContainsString(
            'royal-python-001-complete-history.pdf',
            $response->headers->get('content-disposition')
        );
    }

    // 7-19: content ----------------------------------------------------------

    public function test_pdf_contains_reptile_identification_and_basic_information(): void
    {
        $category = SpeciesCategory::factory()->create(['name' => 'Snake']);
        $species = Species::factory()->create(['name' => 'Python Snake', 'category_id' => $category->id]);
        $variety = SpeciesVariety::factory()->create(['species_id' => $species->id, 'name' => 'Royal Python']);
        $reptile = Reptile::factory()->create([
            'name' => 'Royal Python 001',
            'species_id' => $species->id,
            'species_variety_id' => $variety->id,
            'current_weight' => 450,
            'weight_unit' => 'g',
        ]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $text = $this->pdfText($response);

        $this->assertStringContainsString('REPTILE COMPLETE HISTORY', $text);
        $this->assertStringContainsString('Royal Python 001', $text);
        $this->assertStringContainsString($reptile->reptile_code, $text);
        $this->assertStringContainsString('Snake', $text);
        $this->assertStringContainsString('Python Snake', $text);
        $this->assertStringContainsString('Royal Python', $text);
        $this->assertStringContainsString('450', $text);
    }

    public function test_pdf_contains_all_history_sections_and_summary_counts(): void
    {
        $reptile = Reptile::factory()->create(['notes' => 'Very active and handles well.']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id]);

        FeedingRecord::factory()->create(['reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'notes' => 'Ate the whole mouse']);
        SheddingRecord::factory()->create(['reptile_id' => $reptile->id, 'notes' => 'Clean shed']);
        MedicalRecord::factory()->create(['reptile_id' => $reptile->id, 'symptoms_or_condition' => 'Mild respiratory infection']);
        HealthAlert::factory()->create(['reptile_id' => $reptile->id, 'title' => 'Weight Gain Alert', 'status' => 'active']);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $text = $this->pdfText($response);

        $this->assertStringContainsString('History Summary', $text);
        $this->assertStringContainsString('Weight History', $text);
        $this->assertStringContainsString('Feeding History', $text);
        $this->assertStringContainsString('Shedding History', $text);
        $this->assertStringContainsString('Medical History', $text);
        $this->assertStringContainsString('Health Alert History', $text);
        $this->assertStringContainsString('Important Observations', $text);
        $this->assertStringContainsString('Ate the whole mouse', $text);
        $this->assertStringContainsString('Clean shed', $text);
        $this->assertStringContainsString('Mild respiratory infection', $text);
        $this->assertStringContainsString('Weight Gain Alert', $text);
        $this->assertStringContainsString('Very active and handles well.', $text);

        // Footer: dynamic animal name + real "Page X of Y" (never hard-coded).
        $this->assertStringContainsString('Reptile Management System', $text);
        $this->assertStringContainsString('Animal: '.$reptile->name, $text);
        $this->assertMatchesRegularExpression('/Page \d+ of \d+/', $text);
    }

    public function test_pdf_displays_the_exact_weight_alert_message_when_the_poor_gain_rule_is_met(): void
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);
        $admin = User::factory()->admin()->create();

        // A baseline record first (no previous record, so no trend at all),
        // then three real, consecutive no_gain/loss records — mirrors
        // ReptileHistoryTest::test_latest_three_poor_gain_feeding_records_are_highlighted().
        $this->actingAs($admin)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id, 'feeding_date' => now()->subDays(4)->toDateTimeString(),
            'quantity' => $schedule->quantity, 'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => 400, 'weight_after' => 400,
        ]);
        $this->actingAs($admin)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id, 'feeding_date' => now()->subDays(3)->toDateTimeString(),
            'quantity' => $schedule->quantity, 'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => 400, 'weight_after' => 400,
        ]);
        $this->actingAs($admin)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id, 'feeding_date' => now()->subDays(2)->toDateTimeString(),
            'quantity' => $schedule->quantity, 'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => 400, 'weight_after' => 395,
        ]);
        $this->actingAs($admin)->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id, 'feeding_date' => now()->subDay()->toDateTimeString(),
            'quantity' => $schedule->quantity, 'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => 395, 'weight_after' => 395,
        ]);

        $response = $this->actingAs($admin)->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $text = $this->pdfText($response);

        $this->assertStringContainsString('WARNING', $text);
        $this->assertStringContainsString(FeedingRecord::ALERT_MESSAGE, $text);
    }

    public function test_pdf_indicates_prescription_attachment_state_without_exposing_the_file_path(): void
    {
        $reptile = Reptile::factory()->create();
        MedicalRecord::factory()->create([
            'reptile_id' => $reptile->id,
            'prescription_path' => 'medical-prescriptions/some-uuid.pdf',
        ]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $text = $this->pdfText($response);

        $this->assertStringContainsString('Attached', $text);
        $this->assertStringNotContainsString('medical-prescriptions/some-uuid.pdf', $text);
    }

    // 20-25: strict per-reptile isolation (mandatory) -------------------------

    public function test_pdf_content_is_completely_isolated_between_two_reptiles(): void
    {
        $rp001 = Reptile::factory()->create(['name' => 'Royal Python 001']);
        $rp002 = Reptile::factory()->create(['name' => 'Royal Python 002']);

        FeedingRecord::factory()->create(['reptile_id' => $rp001->id, 'notes' => 'Feeding A']);
        FeedingRecord::factory()->create(['reptile_id' => $rp002->id, 'notes' => 'Feeding B']);

        SheddingRecord::factory()->create(['reptile_id' => $rp001->id, 'notes' => 'Shedding A']);
        SheddingRecord::factory()->create(['reptile_id' => $rp002->id, 'notes' => 'Shedding B']);

        MedicalRecord::factory()->create(['reptile_id' => $rp001->id, 'symptoms_or_condition' => 'Medical A condition']);
        MedicalRecord::factory()->create(['reptile_id' => $rp002->id, 'symptoms_or_condition' => 'Medical B condition']);

        HealthAlert::factory()->create(['reptile_id' => $rp001->id, 'title' => 'Alert A title']);
        HealthAlert::factory()->create(['reptile_id' => $rp002->id, 'title' => 'Alert B title']);

        $user = $this->actingAs(User::factory()->create());

        $pdf001 = $this->pdfText($user->get(route('admin.reptiles.history.pdf', $rp001)));
        $this->assertStringContainsString('Feeding A', $pdf001);
        $this->assertStringContainsString('Shedding A', $pdf001);
        $this->assertStringContainsString('Medical A condition', $pdf001);
        $this->assertStringContainsString('Alert A title', $pdf001);
        $this->assertStringNotContainsString('Feeding B', $pdf001);
        $this->assertStringNotContainsString('Shedding B', $pdf001);
        $this->assertStringNotContainsString('Medical B condition', $pdf001);
        $this->assertStringNotContainsString('Alert B title', $pdf001);

        $pdf002 = $this->pdfText($user->get(route('admin.reptiles.history.pdf', $rp002)));
        $this->assertStringContainsString('Feeding B', $pdf002);
        $this->assertStringContainsString('Shedding B', $pdf002);
        $this->assertStringContainsString('Medical B condition', $pdf002);
        $this->assertStringContainsString('Alert B title', $pdf002);
        $this->assertStringNotContainsString('Feeding A', $pdf002);
        $this->assertStringNotContainsString('Shedding A', $pdf002);
        $this->assertStringNotContainsString('Medical A condition', $pdf002);
        $this->assertStringNotContainsString('Alert A title', $pdf002);
    }

    // 26: hierarchy / 404 ------------------------------------------------------

    public function test_nonexistent_reptile_returns_404_for_pdf(): void
    {
        $response = $this->actingAs(User::factory()->create())
            ->get('/admin/reptiles/999999/history/pdf');

        $response->assertNotFound();
    }

    // 27: legacy/unassigned reptiles --------------------------------------------

    public function test_legacy_reptile_without_category_or_variety_can_still_generate_a_pdf(): void
    {
        $reptile = Reptile::factory()->create(['species_variety_id' => null]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $text = $this->pdfText($response);

        $this->assertStringContainsString('Not assigned', $text);
    }

    // 28: empty history ----------------------------------------------------------

    public function test_reptile_with_no_history_can_still_generate_a_pdf(): void
    {
        $reptile = Reptile::factory()->create(['notes' => null]);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();
        $text = $this->pdfText($response);

        $this->assertStringContainsString('No feeding records recorded.', $text);
        $this->assertStringContainsString('No shedding records recorded.', $text);
        $this->assertStringContainsString('No medical records recorded.', $text);
        $this->assertStringContainsString('No health alerts recorded.', $text);
        $this->assertStringContainsString('Not recorded', $text);
    }

    // 30-32: read-only ------------------------------------------------------------

    public function test_generating_a_pdf_never_modifies_any_database_records(): void
    {
        $reptile = Reptile::factory()->create();
        $feeding = FeedingRecord::factory()->create(['reptile_id' => $reptile->id]);
        $shedding = SheddingRecord::factory()->create(['reptile_id' => $reptile->id]);
        $medical = MedicalRecord::factory()->create(['reptile_id' => $reptile->id]);
        $alert = HealthAlert::factory()->create(['reptile_id' => $reptile->id, 'status' => 'active']);

        $this->assertDatabaseCount('health_alerts', 1);

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.reptiles.history.pdf', $reptile));

        $response->assertOk();

        $this->assertDatabaseCount('health_alerts', 1);
        $this->assertDatabaseHas('feeding_records', ['id' => $feeding->id, 'updated_at' => $feeding->updated_at]);
        $this->assertDatabaseHas('shedding_records', ['id' => $shedding->id, 'updated_at' => $shedding->updated_at]);
        $this->assertDatabaseHas('medical_records', ['id' => $medical->id, 'updated_at' => $medical->updated_at]);
        $this->assertDatabaseHas('health_alerts', ['id' => $alert->id, 'status' => 'active', 'updated_at' => $alert->updated_at]);
    }
}
