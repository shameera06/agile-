<?php

namespace Tests\Feature\Admin;

use App\Models\FeedingSchedule;
use App\Models\FeedingScheduleAdjustment;
use App\Models\Reptile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FeedingScheduleAdjustmentTest extends TestCase
{
    use RefreshDatabase;

    /**
     * A valid "Adjust Next Feeding" payload for the given schedule.
     */
    protected function adjustmentPayload(FeedingSchedule $schedule, array $overrides = []): array
    {
        $newNextDueAt = $schedule->next_due_at->copy()->addDays(3);

        return array_merge([
            'adjusted_next_due_date' => $newNextDueAt->toDateString(),
            'adjusted_next_due_time' => $newNextDueAt->format('H:i'),
            'reason' => 'digestion_delay',
            'notes' => 'Additional digestion time required.',
        ], $overrides);
    }

    // 1-3: access -------------------------------------------------------------

    public function test_guest_cannot_access_adjust_form(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->get(route('admin.feeding-schedules.adjust-next-feeding', $schedule));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_adjust_a_feeding_schedule_if_authorized(): void
    {
        // No Staff/Admin distinction exists in the current auth implementation
        // for this module (route sits only behind `auth`, same as the rest of
        // Feeding Schedules) — see FeedingScheduleManagementTest for the same note.
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.adjust-next-feeding.store', $schedule), $this->adjustmentPayload($schedule));

        $response->assertRedirect(route('admin.feeding-schedules.index'));
        $response->assertSessionHas('success', 'Next feeding adjusted successfully.');
    }

    public function test_staff_can_adjust_only_if_existing_permissions_allow(): void
    {
        // Today, Staff and Admin share identical permissions for this module
        // (see UpdateFeedingScheduleRequest::authorize() => true and the route
        // group in routes/web.php) — this exercises the same route a Staff
        // user would use, matching the existing schedule-edit tests' convention.
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())
            ->post(route('admin.feeding-schedules.adjust-next-feeding.store', $schedule), $this->adjustmentPayload($schedule));

        $response->assertSessionDoesntHaveErrors();
    }

    public function test_unauthorized_user_cannot_adjust(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->post(route('admin.feeding-schedules.adjust-next-feeding.store', $schedule), $this->adjustmentPayload($schedule));

        $response->assertRedirect(route('admin.login'));
        $this->assertDatabaseCount('feeding_schedule_adjustments', 0);
    }

    // 4: current next_due_at is displayed --------------------------------------

    public function test_current_next_due_at_is_displayed_on_the_adjust_form(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())
            ->get(route('admin.feeding-schedules.adjust-next-feeding', $schedule));

        $response->assertOk();
        $response->assertViewIs('admin.feeding-schedules.adjust');
        $response->assertSee($schedule->next_due_at->format('d M Y'));
    }

    // 5: new next_due_at can be saved -------------------------------------------

    public function test_new_next_due_at_can_be_saved(): void
    {
        $schedule = FeedingSchedule::factory()->create();
        $newNextDueAt = $schedule->next_due_at->copy()->addDays(3);

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, [
                'adjusted_next_due_date' => $newNextDueAt->toDateString(),
                'adjusted_next_due_time' => $newNextDueAt->format('H:i'),
            ])
        );

        $schedule->refresh();
        $this->assertTrue($newNextDueAt->equalTo($schedule->next_due_at));
    }

    // 6-7: reason validation ------------------------------------------------------

    public function test_adjustment_reason_is_required(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, ['reason' => ''])
        );

        $response->assertSessionHasErrors('reason');
        $this->assertDatabaseCount('feeding_schedule_adjustments', 0);
    }

    public function test_invalid_adjustment_reason_is_rejected(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, ['reason' => 'not_a_real_reason'])
        );

        $response->assertSessionHasErrors('reason');
    }

    // 8: notes can be saved ---------------------------------------------------

    public function test_adjustment_notes_can_be_saved(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, ['notes' => 'Reptile has not defecated yet.'])
        );

        $this->assertDatabaseHas('feeding_schedule_adjustments', [
            'feeding_schedule_id' => $schedule->id,
            'notes' => 'Reptile has not defecated yet.',
        ]);
    }

    // 9-10: adjustment history --------------------------------------------------

    public function test_adjustment_history_is_created(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $this->assertDatabaseCount('feeding_schedule_adjustments', 1);
        $this->assertDatabaseHas('feeding_schedule_adjustments', [
            'feeding_schedule_id' => $schedule->id,
            'reptile_id' => $schedule->reptile_id,
            'reason' => 'digestion_delay',
        ]);
    }

    public function test_original_next_due_at_is_preserved_in_adjustment_history(): void
    {
        $schedule = FeedingSchedule::factory()->create();
        $originalNextDueAt = $schedule->next_due_at->copy();

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $adjustment = FeedingScheduleAdjustment::sole();
        $this->assertTrue($originalNextDueAt->equalTo($adjustment->original_next_due_at));
    }

    public function test_current_next_due_at_becomes_the_adjusted_date(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $adjustment = FeedingScheduleAdjustment::sole();
        $schedule->refresh();
        $this->assertTrue($adjustment->adjusted_next_due_at->equalTo($schedule->next_due_at));
    }

    // 11: multiple adjustments ----------------------------------------------------

    public function test_multiple_adjustments_are_all_recorded_and_the_latest_wins(): void
    {
        $schedule = FeedingSchedule::factory()->create();
        $user = User::factory()->create();

        $firstNewDate = $schedule->next_due_at->copy()->addDays(2);
        $this->actingAs($user)->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, [
                'adjusted_next_due_date' => $firstNewDate->toDateString(),
                'adjusted_next_due_time' => $firstNewDate->format('H:i'),
                'reason' => 'digestion_delay',
            ])
        );

        $schedule->refresh();
        $secondNewDate = $schedule->next_due_at->copy()->addDays(2);
        $this->actingAs($user)->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, [
                'adjusted_next_due_date' => $secondNewDate->toDateString(),
                'adjusted_next_due_time' => $secondNewDate->format('H:i'),
                'reason' => 'not_defecated',
            ])
        );

        $this->assertDatabaseCount('feeding_schedule_adjustments', 2);
        $schedule->refresh();
        $this->assertTrue($secondNewDate->equalTo($schedule->next_due_at));

        $history = FeedingScheduleAdjustment::where('feeding_schedule_id', $schedule->id)
            ->orderBy('id')
            ->get();
        $this->assertSame('digestion_delay', $history->first()->reason);
        $this->assertSame('not_defecated', $history->last()->reason);
    }

    // 12-16: schedule/weight/health isolation ---------------------------------------

    public function test_feeding_interval_is_not_permanently_changed_by_an_adjustment(): void
    {
        $schedule = FeedingSchedule::factory()->create(['interval_days' => 7]);

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $schedule->refresh();
        $this->assertSame(7, $schedule->interval_days);
    }

    public function test_adjustment_does_not_create_a_feeding_record(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $this->assertDatabaseCount('feeding_records', 0);
    }

    public function test_adjustment_does_not_create_a_health_alert(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $this->assertDatabaseCount('health_alerts', 0);
    }

    public function test_adjustment_does_not_change_reptile_weight(): void
    {
        $reptile = Reptile::factory()->create(['current_weight' => 100]);
        $schedule = FeedingSchedule::factory()->create(['reptile_id' => $reptile->id]);

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        $this->assertEquals(100, $reptile->fresh()->current_weight);
    }

    public function test_actual_feeding_after_an_adjustment_still_uses_feeding_date_plus_interval(): void
    {
        // Confirms Module 07's existing next-feeding calculation
        // (FeedingRecordController::advanceSchedule) is untouched: it derives
        // next_due_at from the ACTUAL feeding date + interval_days, never from
        // whatever next_due_at happened to hold before the feeding (adjusted or not).
        $schedule = FeedingSchedule::factory()->create(['interval_days' => 7]);

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule)
        );

        // Truncated to the minute: the form only ever submits minute precision
        // (an <input type="datetime-local">/"Y-m-d\TH:i" value), and the DB
        // column itself drops sub-second precision — matching that shape keeps
        // the equalTo() comparison below meaningful.
        $feedingDate = now(config('app.timezone'))->startOfMinute();

        $response = $this->actingAs(User::factory()->create())->post(route('admin.feeding-records.store'), [
            'feeding_schedule_id' => $schedule->id,
            'feeding_date' => $feedingDate->format('Y-m-d\TH:i'),
            'quantity' => $schedule->quantity,
            'quantity_unit' => $schedule->quantity_unit,
            'weight_before' => 100,
            'weight_after' => 100,
        ]);
        $response->assertSessionDoesntHaveErrors();

        $schedule->refresh();
        $expectedNextDueAt = $feedingDate->copy()->addDays(7);
        $this->assertTrue($expectedNextDueAt->equalTo($schedule->next_due_at));
    }

    // 17-18: data isolation & validation -------------------------------------------

    public function test_reptile_a_cannot_have_its_schedule_adjusted_through_reptile_bs_request(): void
    {
        $scheduleA = FeedingSchedule::factory()->create();
        $scheduleB = FeedingSchedule::factory()->create();
        $originalNextDueAtB = $scheduleB->next_due_at->copy();

        // Even though the payload is built from schedule A's own dates, posting
        // it against schedule B's URL can only ever move schedule B — there is
        // no reptile_id/schedule_id field in the payload to spoof.
        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $scheduleA),
            $this->adjustmentPayload($scheduleA)
        );

        $scheduleB->refresh();
        $this->assertTrue($originalNextDueAtB->equalTo($scheduleB->next_due_at));
        $this->assertDatabaseHas('feeding_schedule_adjustments', ['feeding_schedule_id' => $scheduleA->id]);
        $this->assertDatabaseMissing('feeding_schedule_adjustments', ['feeding_schedule_id' => $scheduleB->id]);
    }

    public function test_adjustment_requires_a_valid_date_and_time(): void
    {
        $schedule = FeedingSchedule::factory()->create();

        $response = $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, [
                'adjusted_next_due_date' => '',
                'adjusted_next_due_time' => '',
            ])
        );

        $response->assertSessionHasErrors(['adjusted_next_due_date', 'adjusted_next_due_time']);
        $this->assertDatabaseCount('feeding_schedule_adjustments', 0);
    }

    // 19: the "upcoming" scope reflects the adjusted next_due_at ---------------------

    /**
     * The dashboard no longer surfaces FeedingSchedule-driven cards (Feeding
     * Schedules are hidden from the normal workflow — see DashboardService),
     * so this now asserts directly against the FeedingSchedule::upcoming()
     * scope the adjustment feeds into, rather than the removed
     * DashboardService::getUpcomingFeedings().
     */
    public function test_upcoming_scope_uses_the_adjusted_next_due_at(): void
    {
        $schedule = FeedingSchedule::factory()->create(['next_due_at' => now()->addDays(5)]);
        $adjustedNextDueAt = now()->addDays(10);

        $this->actingAs(User::factory()->create())->post(
            route('admin.feeding-schedules.adjust-next-feeding.store', $schedule),
            $this->adjustmentPayload($schedule, [
                'adjusted_next_due_date' => $adjustedNextDueAt->toDateString(),
                'adjusted_next_due_time' => $adjustedNextDueAt->format('H:i'),
            ])
        );

        $upcoming = FeedingSchedule::upcoming()->get();

        $this->assertTrue($upcoming->contains(fn ($row) => $row->id === $schedule->id));
        // The adjust form only captures date + time-to-the-minute, so compare
        // at minute precision rather than the full (seconds-bearing) instant.
        $this->assertEquals(
            $adjustedNextDueAt->format('Y-m-d H:i'),
            $schedule->fresh()->next_due_at->format('Y-m-d H:i')
        );
    }
}
