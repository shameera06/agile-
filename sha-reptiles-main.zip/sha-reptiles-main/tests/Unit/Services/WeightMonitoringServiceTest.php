<?php

namespace Tests\Unit\Services;

use App\Models\FeedingRecord;
use App\Models\FeedingSchedule;
use App\Models\FoodType;
use App\Models\Reptile;
use App\Services\WeightMonitoringService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WeightMonitoringServiceTest extends TestCase
{
    use RefreshDatabase;

    protected WeightMonitoringService $service;

    protected function setUp(): void
    {
        parent::setUp();

        $this->service = new WeightMonitoringService;
    }

    /**
     * Build an in-memory (never persisted) FeedingRecord for testing the pure
     * calculation methods, which never need to hit the database.
     */
    protected function record(array $attributes = []): FeedingRecord
    {
        return new FeedingRecord(array_merge([
            'weight_before' => 300,
            'weight_after' => 310,
            'weight_after_defecation' => 306,
        ], $attributes));
    }

    // getEffectiveWeight() -------------------------------------------------

    public function test_effective_weight_prefers_after_defecation(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306]);

        $this->assertSame(306.0, $this->service->getEffectiveWeight($record));
    }

    public function test_effective_weight_falls_back_to_after_when_defecation_missing(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => null]);

        $this->assertSame(310.0, $this->service->getEffectiveWeight($record));
    }

    public function test_effective_weight_falls_back_to_before_as_final_fallback(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => null, 'weight_after_defecation' => null]);

        $this->assertSame(300.0, $this->service->getEffectiveWeight($record));
    }

    // calculateWeightChange() ------------------------------------------------

    public function test_weight_change_uses_net_post_defecation_change_when_available(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306]);

        $this->assertSame(6.0, $this->service->calculateWeightChange($record));
    }

    public function test_weight_change_falls_back_to_after_minus_before_when_defecation_missing(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => null]);

        $this->assertSame(10.0, $this->service->calculateWeightChange($record));
    }

    public function test_weight_change_can_be_negative(): void
    {
        $record = $this->record(['weight_before' => 500, 'weight_after' => 495, 'weight_after_defecation' => null]);

        $this->assertSame(-5.0, $this->service->calculateWeightChange($record));
    }

    public function test_weight_change_can_be_zero(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => 300, 'weight_after_defecation' => 300]);

        $this->assertSame(0.0, $this->service->calculateWeightChange($record));
    }

    // calculateImmediateWeightChange() --------------------------------------

    public function test_immediate_weight_change_is_after_minus_before(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306]);

        $this->assertSame(10.0, $this->service->calculateImmediateWeightChange($record));
    }

    public function test_immediate_weight_change_is_null_without_after_weight(): void
    {
        $record = $this->record(['weight_before' => 300, 'weight_after' => null, 'weight_after_defecation' => null]);

        $this->assertNull($this->service->calculateImmediateWeightChange($record));
    }

    // determineWeightTrend() -------------------------------------------------

    public function test_first_record_has_no_trend(): void
    {
        $record = $this->record();

        $this->assertNull($this->service->determineWeightTrend($record, null));
    }

    public function test_trend_is_gain_when_effective_weight_increased(): void
    {
        $previous = $this->record(['weight_after_defecation' => 305]);
        $current = $this->record(['weight_after_defecation' => 307]);

        $this->assertSame('gain', $this->service->determineWeightTrend($current, $previous));
    }

    public function test_trend_is_no_gain_when_effective_weight_is_unchanged(): void
    {
        $previous = $this->record(['weight_after_defecation' => 305]);
        $current = $this->record(['weight_after_defecation' => 305]);

        $this->assertSame('no_gain', $this->service->determineWeightTrend($current, $previous));
    }

    public function test_trend_is_loss_when_effective_weight_decreased(): void
    {
        $previous = $this->record(['weight_after_defecation' => 305]);
        $current = $this->record(['weight_after_defecation' => 302]);

        $this->assertSame('loss', $this->service->determineWeightTrend($current, $previous));
    }

    // hasThreeConsecutivePoorGainRecords() / shouldTriggerWeightAlert() ------

    protected function reptileWithSchedule(): array
    {
        $reptile = Reptile::factory()->create(['status' => 'active']);
        $foodType = FoodType::factory()->create(['status' => true]);
        $schedule = FeedingSchedule::factory()->create([
            'reptile_id' => $reptile->id,
            'food_type_id' => $foodType->id,
        ]);

        return [$reptile, $foodType, $schedule];
    }

    protected function makeRecord(Reptile $reptile, FeedingSchedule $schedule, FoodType $foodType, string $trend, string $feedingDate): FeedingRecord
    {
        return FeedingRecord::create([
            'reptile_id' => $reptile->id,
            'feeding_schedule_id' => $schedule->id,
            'food_type_id' => $foodType->id,
            'feeding_date' => $feedingDate,
            'quantity' => 1,
            'quantity_unit' => 'piece',
            'weight_before' => 300,
            'weight_after' => 300,
            'weight_after_defecation' => 300,
            'weight_trend' => $trend,
        ]);
    }

    public function test_fewer_than_three_previous_records_does_not_trigger_alert(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        $this->makeRecord($reptile, $schedule, $foodType, 'no_gain', '2026-09-01');
        $this->makeRecord($reptile, $schedule, $foodType, 'loss', '2026-09-08');

        $this->assertFalse($this->service->shouldTriggerWeightAlert($reptile->id));
    }

    public function test_three_consecutive_poor_gain_records_trigger_the_alert(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        $this->makeRecord($reptile, $schedule, $foodType, 'no_gain', '2026-09-01');
        $this->makeRecord($reptile, $schedule, $foodType, 'loss', '2026-09-08');
        $this->makeRecord($reptile, $schedule, $foodType, 'no_gain', '2026-09-15');

        $this->assertTrue($this->service->shouldTriggerWeightAlert($reptile->id));
    }

    public function test_three_records_containing_a_gain_do_not_trigger_the_alert(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        $this->makeRecord($reptile, $schedule, $foodType, 'gain', '2026-09-01');
        $this->makeRecord($reptile, $schedule, $foodType, 'loss', '2026-09-08');
        $this->makeRecord($reptile, $schedule, $foodType, 'no_gain', '2026-09-15');

        $this->assertFalse($this->service->shouldTriggerWeightAlert($reptile->id));
    }

    public function test_alert_check_excludes_the_given_record_id(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        $this->makeRecord($reptile, $schedule, $foodType, 'no_gain', '2026-09-01');
        $this->makeRecord($reptile, $schedule, $foodType, 'loss', '2026-09-08');
        $this->makeRecord($reptile, $schedule, $foodType, 'no_gain', '2026-09-15');
        $excluded = $this->makeRecord($reptile, $schedule, $foodType, 'gain', '2026-09-22');

        // Excluding the newest (gain) record leaves exactly the three poor-gain
        // records above as "the previous three".
        $this->assertTrue($this->service->shouldTriggerWeightAlert($reptile->id, $excluded->id));
    }

    public function test_records_from_another_reptile_are_never_included(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();
        [$otherReptile, $otherFoodType, $otherSchedule] = $this->reptileWithSchedule();

        $this->makeRecord($otherReptile, $otherSchedule, $otherFoodType, 'no_gain', '2026-09-01');
        $this->makeRecord($otherReptile, $otherSchedule, $otherFoodType, 'loss', '2026-09-08');
        $this->makeRecord($otherReptile, $otherSchedule, $otherFoodType, 'no_gain', '2026-09-15');

        // This reptile has no records of its own — the other reptile's poor-gain
        // history must never count towards its alert.
        $this->assertFalse($this->service->shouldTriggerWeightAlert($reptile->id));
    }

    // recalculateReptileWeightHistory() --------------------------------------

    public function test_recalculate_history_matches_the_three_consecutive_poor_gain_scenario(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        // Record 1: 300 (no previous record => trend stays null)
        $r1 = FeedingRecord::create([
            'reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'food_type_id' => $foodType->id,
            'feeding_date' => '2026-09-01', 'quantity' => 1, 'quantity_unit' => 'piece',
            'weight_before' => 300, 'weight_after' => 300,
        ]);
        // Record 2: 300 -> no_gain
        $r2 = FeedingRecord::create([
            'reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'food_type_id' => $foodType->id,
            'feeding_date' => '2026-09-08', 'quantity' => 1, 'quantity_unit' => 'piece',
            'weight_before' => 300, 'weight_after' => 300,
        ]);
        // Record 3: 299 -> loss
        $r3 = FeedingRecord::create([
            'reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'food_type_id' => $foodType->id,
            'feeding_date' => '2026-09-15', 'quantity' => 1, 'quantity_unit' => 'piece',
            'weight_before' => 299, 'weight_after' => 299,
        ]);
        $this->service->recalculateReptileWeightHistory($reptile->id);

        $this->assertNull($r1->fresh()->weight_trend);
        $this->assertSame('no_gain', $r2->fresh()->weight_trend);
        $this->assertSame('loss', $r3->fresh()->weight_trend);

        // Records 1-3 (300, 300, 299) never gain across the sequence — record
        // 1 has no trend of its own (it's the baseline), but that doesn't
        // disqualify it. The alert must fire immediately on record 3, not
        // wait for a 4th record.
        $this->assertTrue((bool) $r3->fresh()->weight_alert_triggered);
        $this->assertSame(WeightMonitoringService::ALERT_MESSAGE, $r3->fresh()->weight_alert_message);

        // Record 4: 299 -> no_gain. Records 2-4 (no_gain/loss/no_gain) are
        // still all poor gain, so the alert stays triggered.
        $r4 = FeedingRecord::create([
            'reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'food_type_id' => $foodType->id,
            'feeding_date' => '2026-09-22', 'quantity' => 1, 'quantity_unit' => 'piece',
            'weight_before' => 299, 'weight_after' => 299,
        ]);

        $this->service->recalculateReptileWeightHistory($reptile->id);

        $this->assertSame('no_gain', $r4->fresh()->weight_trend);
        $this->assertTrue((bool) $r4->fresh()->weight_alert_triggered);

        // The reptile's current_weight tracks the latest record's effective weight.
        $this->assertEquals(299, $reptile->fresh()->current_weight);
    }

    public function test_recalculate_history_updates_reptile_current_weight_with_defecation_priority(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        FeedingRecord::create([
            'reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'food_type_id' => $foodType->id,
            'feeding_date' => '2026-09-10 19:15:00', 'quantity' => 1, 'quantity_unit' => 'piece',
            'weight_before' => 300, 'weight_after' => 310, 'weight_after_defecation' => 306,
        ]);

        $this->service->recalculateReptileWeightHistory($reptile->id);

        $this->assertEquals(306, $reptile->fresh()->current_weight);
    }

    public function test_alert_triggers_on_the_third_feeding_record_when_weight_never_increases(): void
    {
        [$reptile, $foodType, $schedule] = $this->reptileWithSchedule();

        foreach (['2026-09-01', '2026-09-08', '2026-09-15'] as $i => $feedingDate) {
            $record = FeedingRecord::create([
                'reptile_id' => $reptile->id, 'feeding_schedule_id' => $schedule->id, 'food_type_id' => $foodType->id,
                'feeding_date' => $feedingDate, 'quantity' => 1, 'quantity_unit' => 'piece',
                'weight_before' => 500, 'weight_after' => 500,
            ]);

            if ($i === 2) {
                $thirdRecord = $record;
            }
        }

        $this->service->recalculateReptileWeightHistory($reptile->id);

        $this->assertTrue((bool) $thirdRecord->fresh()->weight_alert_triggered);
    }
}
